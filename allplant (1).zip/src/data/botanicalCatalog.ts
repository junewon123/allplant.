import type {
  PlantCategory,
  PlantProfile,
  PlantRecommendation,
  PlantSeason,
  RecommendationResponse,
} from '../types/plant';
import { FOLIAGE_AND_PALM_PLANTS } from './catalogFoliageAndPalms';
import { HERBS_SUCCULENTS_FLOWERS } from './catalogHerbsSucculentsFlowers';
import { PLANT_SPECIES_PHOTOS } from './plantPhotos';
import { TRAIT_SPECIAL_COLOR_PLANTS } from './traitColorPlants';

export const CATEGORY_VISUALS: Record<
  PlantCategory,
  { imageUrl: string; caption: string }
> = {
  '관엽식물': {
    imageUrl: '/src/assets/images/cat_foliage_monstera_1795403759928.jpg',
    caption: 'Fig. 02 — 트로피컬 관엽 표본: 찢어진 잎과 잎맥 무늬의 입체적 구조',
  },
  '허브·방향식물': {
    imageUrl: '/src/assets/images/cat_fragrant_lavender_1795403759069.jpg',
    caption: 'Fig. 03 — 방향·허브 표본: 라벤더 이삭과 스타 자스민의 정유 성분',
  },
  '다육·선인장': {
    imageUrl: '/src/assets/images/cat_succulent_echeveria_1795403759080.jpg',
    caption: 'Fig. 04 — 건조지 다육 표본: 분백 파우더 잎과 로제트 수분 저장 조직',
  },
  '꽃·관화식물': {
    imageUrl: '/src/assets/images/cat_flowering_camellia_1795403759985.jpg',
    caption: 'Fig. 05 — 관화 표본: 동백과 치자꽃의 윤기 있는 상록 잎과 겹꽃 화관',
  },
  '공기정화·야자': {
    imageUrl: '/src/assets/images/hero_botanical_conservatory_1795403760157.jpg',
    caption: 'Fig. 06 — 온실 공기정화 표본: 증산 작용과 실내 미세먼지 저감 수종',
  },
};

const EXTRA_POPULAR_PLANTS: PlantProfile[] = [
  {
    id: 'olea-europaea',
    nameKo: '올리브나무',
    nameEn: 'Olive Tree',
    scientificName: 'Olea europaea',
    family: '물푸레나무과 (Oleaceae)',
    category: '관엽식물',
    origin: '지중해 연안 · 그리스 · 스페인',
    difficulty: '보통',
    summary:
      '은빛이 감도는 가늘고 길쭉한 올리브그린 잎과 고풍스러운 목질 수형이 매력적인 지중해 대표 반려나무입니다.',
    imageUrl: CATEGORY_VISUALS['관엽식물'].imageUrl,
    characteristics: {
      appearance:
        '가늘고 뾰족한 버들잎 같은 상록 잎이 촘촘히 달리며, 잎 앞면은 차분한 회녹색, 뒷면은 은백색 광택이 돕니다.',
      colorPalette: ['#6B7F6E', '#94A39B', '#CBD5E1'],
      colorDescription: '차분한 올리브 세이지 그린 앞면과 은빛 뒷면',
      scent: '특별한 향이 강하지 않은 맑은 나무 내음입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '실내 화분 60cm~1.8m, 천천히 단단하게 목질화됨',
      bloomingSeason: '초여름(5~6월) 야외 환경에서 작은 크림색 꽃이 핍니다.',
      petSafety: '강아지와 고양이에게 독성이 없는 안전한 식물입니다.',
    },
    careGuide: {
      watering:
        '건조에 강한 편이나 화분에서 키울 땐 겉흙이 3~4cm 마르면 흠뻑 줍니다. 과습 시 잎이 마르지 않은 채 떨어질 수 있습니다.',
      wateringCycle: '봄~가을 4~7일에 1회 · 겨울 10~14일에 1회',
      sunlight:
        '하루 최소 5~6시간 이상의 강한 직사광선과 사방이 트인 통풍이 필수입니다. 빛이 부족하면 잎이 우수수 떨어집니다.',
      temperature: '15~25°C 적정 · 내한성이 있어 영하권 직전(0~5°C)까지도 베란다 월동 가능',
      humidity: '35~50%의 건조하고 바람이 잘 통하는 환경을 좋아합니다.',
      soil: '물빠짐이 아주 좋은 마사토·펄라이트 비율이 높은 사질토(상토 5 : 마사토·펄라이트 5)가 적합합니다.',
      fertilizer: '봄~가을 2개월에 1회 완효성 비료를 소량 줍니다.',
      pruningAndRepotting:
        '봄철에 복잡하게 얽힌 안쪽 잔가지를 솎아주어야 통풍이 원활해집니다.',
      commonIssues:
        '실내 깊숙한 곳에 두어 빛과 바람이 부족해지면 잎이 바스락거리며 떨어지므로 반드시 가장 밝은 창가에 두세요.',
    },
    funFact:
      '수천 년을 사는 장수목이며, 비둘기가 물고 온 올리브 가지는 고대부터 평화의 상징으로 여겨졌습니다.',
  },
  {
    id: 'dracaena-trifasciata-moonshine',
    nameKo: '산세베리아 문샤인',
    nameEn: 'Moonshine Snake Plant',
    scientificName: 'Dracaena trifasciata Moonshine',
    family: '비짜루과 (Asparagaceae)',
    category: '다육·선인장',
    origin: '서아프리카 원예 품종',
    difficulty: '초보자 추천',
    summary:
      '달빛을 머금은 듯 은은한 은청색·파스텔 민트빛 칼날 잎이 깔끔하게 솟아오르며, 밤에 산소를 방출하는 모던한 공기정화 식물입니다.',
    imageUrl: CATEGORY_VISUALS['다육·선인장'].imageUrl,
    characteristics: {
      appearance:
        '폭이 넓고 뾰족한 다육질 잎이 장미꽃다발처럼 겹쳐 올라오며, 기존 호랑이 무늬 대신 매끈한 은녹색 빛을 띱니다.',
      colorPalette: ['#94A39B', '#CBD5E1', '#6B8E78'],
      colorDescription: '달빛 같은 은청록·파스텔 민트 그레이',
      scent: '향기가 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '높이 25~50cm, 단정하게 자람',
      bloomingSeason: '관엽 수형을 감상하며 드물게 향기로운 흰 꽃대가 올라옵니다.',
      petSafety: '사포닌 성분이 있어 반려동물이 씹지 않도록 주의합니다.',
    },
    careGuide: {
      watering:
        '흙 속까지 완전히 마른 뒤 월 1~2회만 줍니다. 겨울철에는 한 달 이상 물을 끊어도 거뜬합니다.',
      wateringCycle: '봄~가을 2~3주에 1회 · 겨울 4주에 1회',
      sunlight:
        '반음지에서도 잘 살지만, 밝은 간접광을 받을수록 특유의 은빛 문샤인 색감이 선명하게 유지됩니다.',
      temperature: '15~28°C 적정 · 겨울철 10°C 이상 실내 보호',
      humidity: '건조한 실내 환경에 매우 강합니다.',
      soil: '배수가 빠른 다육·선인장 전용 마사토 혼합토를 사용합니다.',
      fertilizer: '봄철 연 1~2회 아주 묽은 액비면 충분합니다.',
      pruningAndRepotting:
        '옆으로 새 촉(자구)이 솟아나 화분이 꽉 찼을 때 봄에 나누어 심습니다.',
      commonIssues:
        '과습 시 뿌리 밑둥이 물러지므로 물 주기를 최대한 아끼는 것이 핵심입니다.',
    },
    funFact:
      '일반 산세베리아와 마찬가지로 밤에 기공을 열어 이산화탄소를 흡수하고 산소를 내뿜어 침실용으로 인기입니다.',
  },
  {
    id: 'paeonia-lactiflora',
    nameKo: '작약 (피오니)',
    nameEn: 'Chinese Peony',
    scientificName: 'Paeonia lactiflora',
    family: '작약과 (Paeoniaceae)',
    category: '꽃·관화식물',
    origin: '한국 · 중국 · 시베리아',
    difficulty: '보통',
    summary:
      '겹겹이 풍성하게 말린 비단결 같은 분홍·순백의 대륜 꽃을 피우며, 우아하고 맑은 장미·꿀 계열의 고급스러운 봄 향기를 선사합니다.',
    imageUrl: CATEGORY_VISUALS['꽃·관화식물'].imageUrl,
    characteristics: {
      appearance:
        '깊게 갈라진 진녹색 잎 위로 둥글고 탐스러운 구슬 모양 꽃봉오리가 맺혔다가 수십 장의 꽃잎이 겹쳐 화려하게 피어납니다.',
      colorPalette: ['#F472B6', '#FBCFE8', '#FFFFFF'],
      colorDescription: '연분홍·산호·진홍·순백색 등 풍성한 꽃잎',
      scent: '장미와 시트러스, 맑은 꿀 내음을 섞은 듯 우아하고 달콤한 고급 플로럴 향입니다.',
      scentIntensity: '은은함~강함',
      sizeAndGrowth: '키 50~90cm의 다년생 초본',
      bloomingSeason: '늦봄(5~6월)',
      petSafety: '페오놀 성분이 있어 반려동물이 섭취하지 않도록 주의합니다.',
    },
    careGuide: {
      watering:
        '봄철 싹이 올라와 꽃이 필 때는 겉흙이 마르면 듬뿍 주고, 겨울 지상부가 마른 휴면기엔 건조하게 관리합니다.',
      wateringCycle: '봄~가을 3~5일에 1회 · 겨울 2주에 1회',
      sunlight: '하루 5시간 이상의 충분한 햇빛을 받아야 꽃눈이 튼튼하게 맺힙니다.',
      temperature: '서늘하고 사계절 기온 차가 뚜렷한 환경 선호 · 겨울 추위(노지 월동)를 겪어야 봄에 개화',
      humidity: '40~60% 쾌적한 통풍 환경 선호',
      soil: '배수가 잘되고 비옥한 깊은 화분이나 정원 흙(상토 6 : 마사토 4)이 좋습니다.',
      fertilizer: '꽃이 진 직후와 가을에 완효성 유기질 비료를 주어 뿌리를 살찌웁니다.',
      pruningAndRepotting:
        '작약은 뿌리를 옮겨 심는 것을 싫어하므로 깊은 화분에 한 번 심으면 3~4년 이상 그대로 두세요.',
      commonIssues:
        '통풍이 안 되는 고온다습한 곳에선 잎에 회색곰팡이병이 올 수 있으므로 바람이 통하는 베란다·정원이 좋습니다.',
    },
    funFact:
      '5월의 신부 부케로 가장 사랑받는 꽃이며, "수줍음"과 "행복한 결혼"이라는 꽃말을 가지고 있습니다.',
  },
  {
    id: 'helianthus-annuus',
    nameKo: '미니 해바라기',
    nameEn: 'Dwarf Sunflower',
    scientificName: 'Helianthus annuus',
    family: '국화과 (Asteraceae)',
    category: '꽃·관화식물',
    origin: '북아메리카',
    difficulty: '초보자 추천',
    summary:
      '태양처럼 눈부신 황금빛 노란 꽃잎과 짙은 갈색 꽃심이 선명한 대비를 이루며, 작은 화분에서도 씨앗부터 빠르게 키워 볼 수 있습니다.',
    imageUrl: CATEGORY_VISUALS['꽃·관화식물'].imageUrl,
    characteristics: {
      appearance:
        '보송보송한 잔털이 있는 굵은 줄기 끝에 해처럼 둥글고 선명한 노란 꽃잎이 펼쳐집니다.',
      colorPalette: ['#FACC15', '#EAB308', '#451A03'],
      colorDescription: '선명한 해바라기 황금 노랑 꽃잎과 진갈색 중앙',
      scent: '특별한 향수 향보다는 고소한 해바라기 씨와 맑은 풀 내음이 납니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '미니 품종 기준 키 25~50cm, 발아 후 60일 내외로 개화',
      bloomingSeason: '여름~초가을(6~9월)',
      petSafety: '강아지와 고양이에게 독성이 없는 안전한 식물입니다.',
    },
    careGuide: {
      watering:
        '성장이 매우 빠르고 잎이 넓어 물 소모가 많습니다. 겉흙이 마르면 매일 또는 2일에 1회 듬뿍 주세요.',
      wateringCycle: '봄~여름 1~2일에 1회',
      sunlight: '하루 6시간 이상의 직사광선이 필수입니다. 햇빛이 부족하면 줄기가 약하게 웃자랍니다.',
      temperature: '18~28°C의 따뜻한 봄·여름 환경 선호',
      humidity: '일반 실외·베란다 환경에 잘 적응합니다.',
      soil: '배수가 잘되는 비옥한 원예 상토 + 펄라이트(8:2)를 씁니다.',
      fertilizer: '본잎이 4장 이상 자라면 2주 간격으로 개화용 액비를 줍니다.',
      pruningAndRepotting:
        '직근성 뿌리라 옮겨 심기를 싫어하므로 처음부터 적당한 크기의 화분에 심으세요.',
      commonIssues:
        '통풍이 부족하면 흰가루병이 생길 수 있으므로 바람이 통하는 창가·발코니에서 키우세요.',
    },
    funFact:
      '어린 해바라기는 아침엔 동쪽을 보고 저녁엔 서쪽을 따라 고개를 돌리는 "굴광성"을 보이지만, 활짝 핀 후엔 동쪽을 향해 고정됩니다.',
  },
  {
    id: 'citrus-japonica',
    nameKo: '금귤나무 (낑깡)',
    nameEn: 'Kumquat Tree',
    scientificName: 'Citrus japonica',
    family: '운향과 (Rutaceae)',
    category: '꽃·관화식물',
    origin: '동아시아 · 중국 남부',
    difficulty: '보통',
    summary:
      '윤기 나는 진초록 잎 사이로 향기로운 하얀 꽃이 피고, 뒤이어 보석처럼 주황빛으로 익는 귀여운 열매를 감상하고 수확까지 할 수 있습니다.',
    imageUrl: CATEGORY_VISUALS['꽃·관화식물'].imageUrl,
    characteristics: {
      appearance:
        '단단한 목질 가지에 광택 있는 긴 타원형 잎이 달리며, 작은 순백색 꽃 후 한입 크기의 황금·주황색 타원형 열매가 주렁주렁 열립니다.',
      colorPalette: ['#F97316', '#FFFFFF', '#166534'],
      colorDescription: '선명한 귤빛 주황 열매, 순백 꽃, 짙은 초록 잎',
      scent: '꽃이 필 때 네롤리 계열의 달콤한 시트러스 꽃향기가 나고, 잎과 열매 껍질에서는 상큼한 감귤 향이 납니다.',
      scentIntensity: '은은함~강함 (개화 시 진한 시트러스 향)',
      sizeAndGrowth: '화분 기준 50~130cm',
      bloomingSeason: '초여름(6~7월) 개화 후 가을~겨울 열매 성숙',
      petSafety: '감귤류 정유와 구연산은 반려동물에게 배탈을 일으킬 수 있어 열매 섭취를 피합니다.',
    },
    careGuide: {
      watering:
        '열매가 자라는 시기엔 수분 소모가 크므로 겉흙이 마르면 흠뻑 줍니다. 물이 너무 마르면 잎이 말리고 열매가 떨어집니다.',
      wateringCycle: '봄~가을 3~5일에 1회 · 겨울 7~10일에 1회',
      sunlight: '하루 5시간 이상의 직사광선과 통풍이 필수입니다.',
      temperature: '15~26°C 적정 · 겨울철 0~5°C 이상의 서늘한 베란다 월동 가능',
      humidity: '50% 내외가 좋으며 겨울 실내 난방 시 건조로 인한 응애에 주의합니다.',
      soil: '배수가 잘되는 약산성 상토 6 : 마사토·펄라이트 4 혼합토를 씁니다.',
      fertilizer: '봄~가을에 과수용·개화결실용 비료를 월 1~2회 충분히 줍니다.',
      pruningAndRepotting:
        '가시가 있는 품종도 있으므로 손 조심하며, 2년에 한 번 이른 봄에 분갈이합니다.',
      commonIssues:
        '건조한 실내에서 깍지벌레나 응애가 잘 생기므로 통풍과 주기적 잎 세척이 중요합니다.',
    },
    funFact:
      '금귤은 다른 귤과 달리 껍질이 달고 향긋해서 껍질째 통으로 먹을 수 있는 귀여운 실내 과실수입니다.',
  },
  {
    id: 'mentha-suaveolens',
    nameKo: '애플민트',
    nameEn: 'Apple Mint',
    scientificName: 'Mentha suaveolens',
    family: '꿀풀과 (Lamiaceae)',
    category: '허브·방향식물',
    origin: '남부 · 서부 유럽 · 지중해',
    difficulty: '초보자 추천',
    summary:
      '벨벳처럼 보송보송한 둥근 연초록 잎을 만지면 사과의 달콤함과 민트의 청량함이 섞인 상쾌한 향기가 퍼지는 순한 허브입니다.',
    imageUrl: IMG_HERB_REF(),
    characteristics: {
      appearance:
        '하얀 솜털이 보송하게 난 둥글고 주름진 잎들이 네모난 줄기에 마주 달리며 사랑스러운 인상을 줍니다.',
      colorPalette: ['#22C55E', '#86EFAC', '#F3F4F6'],
      colorDescription: '보송한 솜털 덕분에 부드럽게 보이는 밝은 연초록색',
      scent: '페퍼민트보다 맵지 않고 풋사과처럼 달콤하고 부드러운 박하 향이 납니다.',
      scentIntensity: '강함',
      sizeAndGrowth: '키 30~60cm, 생명력이 강해 풍성히 자람',
      bloomingSeason: '여름(7~9월) 연분홍·흰색 이삭 꽃',
      petSafety: '소량의 멘톨 성분이 있어 반려동물 다량 섭취만 피하면 됩니다.',
    },
    careGuide: {
      watering:
        '물을 좋아하는 허브라 겉흙이 마르기 시작하면 듬뿍 주세요. 물이 부족하면 잎이 금방 시듭니다.',
      wateringCycle: '봄~여름 1~3일에 1회 · 겨울 4~6일에 1회',
      sunlight: '반양지~양지에서 튼튼하게 자라며 통풍이 좋을수록 향이 맑아집니다.',
      temperature: '15~25°C 적정 · 노지 월동 가능',
      humidity: '50~65% 선호',
      soil: '보수력이 좋은 원예용 상토에 단독 화분으로 심어 관리하세요.',
      fertilizer: '봄~가을 월 1회 식용 허브용 유기질 비료를 줍니다.',
      pruningAndRepotting:
        '줄기 끝을 자주 따서 차나 디저트에 활용하면 옆 가지가 풍성하게 자랍니다.',
      commonIssues:
        '잎에 솜털이 있어 잎 위로 물을 오래 고이게 하기보단 흙 위로 주는 것이 좋습니다.',
    },
    funFact:
      '사과와 박하를 섞은 듯 부드러운 향 덕분에 모히토 칵테일이나 허브티, 디저트 가니시로 가장 인기가 많습니다.',
  },
];

function IMG_HERB_REF() {
  return CATEGORY_VISUALS['허브·방향식물'].imageUrl;
}

export const BOTANICAL_CATALOG: PlantProfile[] = [
  ...FOLIAGE_AND_PALM_PLANTS,
  ...HERBS_SUCCULENTS_FLOWERS,
  ...EXTRA_POPULAR_PLANTS,
].map((plant) => ({
  ...plant,
  imageUrl: PLANT_SPECIES_PHOTOS[plant.id] || plant.imageUrl,
}));

export const TRAIT_RECOMMENDATION_CATALOG: PlantProfile[] = [
  ...BOTANICAL_CATALOG,
  ...TRAIT_SPECIAL_COLOR_PLANTS,
];

const NAME_ALIASES: Record<string, string> = {
  몬스테라: '몬스테라 델리시오사',
  알보몬스테라: '몬스테라 델리시오사',
  무늬몬스테라: '몬스테라 델리시오사',
  아단소니: '몬스테라 델리시오사',
  라벤더: '잉글리시 라벤더',
  자스민: '아라비안 자스민',
  자스민꽃: '아라비안 자스민',
  말리화: '아라비안 자스민',
  바질: '스위트 바질',
  민트: '페퍼민트',
  박하: '페퍼민트',
  스피어민트: '페퍼민트',
  고무나무: '인도고무나무',
  멜라니고무나무: '인도고무나무',
  버건디고무나무: '인도고무나무',
  떡갈잎고무나무: '떡갈고무나무',
  떡갈나무: '떡갈고무나무',
  뱅갈: '뱅갈고무나무',
  극락조: '여인초',
  극락조화: '여인초',
  포토스: '스킨답서스',
  산세베리아: '산세베리아 문샤인',
  문샤인: '산세베리아 문샤인',
  스투키: '스투키',
  실린드리카: '스투키',
  자미오쿨카스: '금전수',
  돈나무: '금전수',
  다육: '에케베리아 라우이',
  다육이: '에케베리아 라우이',
  라우이: '에케베리아 라우이',
  에케베리아: '에케베리아 라우이',
  선인장: '백도선',
  토끼귀선인장: '백도선',
  장미: '미니장미',
  동백: '동백나무',
  동백꽃: '동백나무',
  치자: '치자나무',
  치자꽃: '치자나무',
  만리향: '은목서',
  올리브: '올리브나무',
  유칼립투스: '유칼립투스 폴리안',
  폴리안: '유칼립투스 폴리안',
  칼라데아: '칼라데아 오르비폴리아',
  오르비폴리아: '칼라데아 오르비폴리아',
  마코야나: '칼라데아 마코야나',
  공작야자: '칼라데아 마코야나',
  필레아: '필레아 페페로미오이데스',
  페페로미오이데스: '필레아 페페로미오이데스',
  알로에: '알로에 베라',
  바이올렛: '아프리칸 바이올렛',
  세인트폴리아: '아프리칸 바이올렛',
  해바라기: '미니 해바라기',
  낑깡: '금귤나무',
  금귤: '금귤나무',
  백리향: '타임',
  카밀레: '캐모마일',
  호접란: '호접란',
  서양란: '호접란',
  팔레놉시스: '호접란',
  고사리: '보스턴고사리',
  피오니: '작약',
  작약꽃: '작약',
  골드크레스트: '율마',
  맛상게아나: '행운목',
  드라세나: '행운목',
  버킨: '필로덴드론 버킨',
  필로덴드론: '필로덴드론 버킨',
  프라이덱: '알로카시아 프라이덱',
  그린벨벳: '알로카시아 프라이덱',
  알로카시아: '알로카시아 프라이덱',
  블랙벨벳: '알로카시아 블랙 벨벳',
  트로픽스노우: '디펜바키아',
  스노우사파이어: '아글라오네마',
  펠라고니움: '제라늄',
  네모필라: '네모필라',
  베이비블루아이즈: '네모필라',
  물망초: '물망초',
  포겟미낫: '물망초',
  플럼바고: '플럼바고',
  갯질경이: '플럼바고',
  블랙배트: '블랙 배트 플라워',
  타카: '블랙 배트 플라워',
  레이븐금전수: '블랙 레이븐 금전수',
  레이븐zz: '블랙 레이븐 금전수',
  블랙금전수: '블랙 레이븐 금전수',
  흑법사: '흑법사',
  블랙로즈: '흑법사',
  흑룡: '흑룡',
  블랙몬도그라스: '흑룡',
  아레카: '아레카야자',
  테이블: '테이블야자',
  스파트: '스파트필름',
  호야: '호야 카노사',
};

function normalizePlantText(text: string): string {
  return text
    .toLowerCase()
    .replace(/\([^)]*\)/g, '')
    .replace(/[\s·\-_]/g, '')
    .trim();
}

export function findBestCatalogPlantMatch(query: string): PlantProfile | null {
  const raw = query.trim();
  if (!raw) return null;

  const normalized = normalizePlantText(raw);
  const aliased = NAME_ALIASES[normalized];
  const targetNorm = aliased ? normalizePlantText(aliased) : normalized;

  // 1. Exact or alias match on Korean, English, or Scientific name
  for (const plant of TRAIT_RECOMMENDATION_CATALOG) {
    const koNorm = normalizePlantText(plant.nameKo);
    const enNorm = normalizePlantText(plant.nameEn);
    const sciNorm = normalizePlantText(plant.scientificName);

    if (
      koNorm === targetNorm ||
      enNorm === targetNorm ||
      sciNorm === targetNorm
    ) {
      return plant;
    }
  }

  // 2. Partial substring match (at least 2 chars)
  if (targetNorm.length >= 2) {
    for (const plant of TRAIT_RECOMMENDATION_CATALOG) {
      const koNorm = normalizePlantText(plant.nameKo);
      const enNorm = normalizePlantText(plant.nameEn);
      const sciNorm = normalizePlantText(plant.scientificName);
      if (
        koNorm.includes(targetNorm) ||
        targetNorm.includes(koNorm) ||
        enNorm.includes(targetNorm) ||
        sciNorm.includes(targetNorm)
      ) {
        return plant;
      }
    }
  }

  return null;
}

interface TraitRule {
  id: string;
  group: 'color' | 'scent' | 'appearance' | 'env' | 'theme';
  keywords: string[];
  exactTokens?: string[];
  shouldTrigger?: (lowerText: string, compactText: string) => boolean;
  label: string;
  match: (plant: PlantProfile) => boolean;
  weight: number;
}

const HAS_SCENT_NEGATION = (compactText: string) =>
  /(무향|냄새없|냄새안|향없|향이없|향안|향기없|향기가없|향기안)/.test(compactText);

function isFloweringPlant(p: PlantProfile): boolean {
  if (p.category === '꽃·관화식물') return true;
  if (p.category === '다육·선인장') return false;
  const text = `${p.characteristics.appearance} ${p.characteristics.bloomingSeason} ${p.summary}`;
  if (/드물게|거의 피지|관엽 잎을 주로|관엽 무늬를|사계절 내내 잎/.test(text)) {
    return false;
  }
  return /꽃이|꽃송이|꽃볼|개화|꽃잎|꽃대|불염포|꽃포|이삭 꽃|별 꽃/.test(text);
}

const TRAIT_RULES: TraitRule[] = [
  // Colors (match strictly against colorDescription + color-named Korean names)
  {
    id: 'color-purple',
    group: 'color',
    keywords: ['보라', '바이올렛', '라벤더색', '자주', '연보라', '퍼플'],
    label: '보라색 색조',
    weight: 6,
    match: (p) =>
      /보라|바이올렛|자주|라벤더/.test(
        `${p.characteristics.colorDescription} ${p.nameKo}`
      ),
  },
  {
    id: 'color-white',
    group: 'color',
    keywords: ['하얀', '하양', '흰', '백색', '순백', '화이트', '아이보리', '크림', '은백'],
    label: '순백 · 하얀 꽃 색감',
    weight: 6,
    match: (p) =>
      /하얀|흰|백색|순백|은백|유백|아이보리|크림/.test(p.characteristics.colorDescription),
  },
  {
    id: 'color-pink',
    group: 'color',
    keywords: ['분홍', '핑크', '살구', '산호', '로즈핑크', '장미빛'],
    label: '분홍빛 색감',
    weight: 6,
    match: (p) =>
      /분홍|핑크|산호|살구/.test(p.characteristics.colorDescription),
  },
  {
    id: 'color-red',
    group: 'color',
    keywords: ['빨강', '빨간', '붉은', '다홍', '진홍', '레드', '버건디', '적색'],
    label: '붉은 · 다홍빛 색감',
    weight: 6,
    match: (p) =>
      /빨강|빨간|붉은|다홍|진홍|버건디|적색/.test(
        `${p.characteristics.colorDescription} ${p.nameKo}`
      ),
  },
  {
    id: 'color-skyblue',
    group: 'color',
    keywords: ['하늘색', '하늘빛', '스카이블루', '베이비 블루', '연청색', '하늘'],
    label: '맑은 하늘색 꽃 색감',
    weight: 8,
    match: (p) =>
      /하늘색|하늘빛|연청색|스카이블루|베이비 블루|파스텔 블루/.test(
        `${p.characteristics.colorDescription} ${p.summary}`
      ),
  },
  {
    id: 'color-blue',
    group: 'color',
    keywords: ['파랑', '파란', '청색', '푸른', '블루', '연청'],
    label: '푸른 · 하늘빛 색감',
    weight: 6,
    match: (p) =>
      /파랑|파란|하늘색|하늘빛|연청색|연청빛|스카이블루|블루/.test(
        `${p.characteristics.colorDescription} ${p.summary}`
      ),
  },
  {
    id: 'color-black',
    group: 'color',
    keywords: ['검은', '검정', '검은색', '검정색', '흑색', '블랙', '까만', '까망', '흑빛'],
    label: '칠흑 같은 검은색 · 블랙 톤',
    weight: 8,
    match: (p) =>
      /검은|검정|흑색|흑자색|칠흑|블랙|까만|검붉은/.test(
        `${p.characteristics.colorDescription} ${p.nameKo} ${p.summary}`
      ),
  },
  {
    id: 'color-yellow',
    group: 'color',
    keywords: ['노랑', '노란', '황금', '레몬색', '주황', '귤', '오렌지색', '옐로우'],
    label: '노랑 · 주황빛 색감',
    weight: 6,
    match: (p) =>
      /노랑|노란|황금|주황|귤|개나리/.test(p.characteristics.colorDescription),
  },
  {
    id: 'color-silver',
    group: 'color',
    keywords: ['은청', '은빛', '회녹', '파스텔', '파우더', '분백', '회색'],
    label: '은청색 · 은빛 톤',
    weight: 5,
    match: (p) =>
      /은청|은빛|회녹|분백|문샤인|파우더|은무늬/.test(
        `${p.characteristics.colorDescription} ${p.nameKo}`
      ),
  },
  {
    id: 'color-green',
    group: 'color',
    keywords: ['초록', '녹색', '진녹', '연두', '에메랄드', '연초록', '그린'],
    label: '싱그러운 초록빛',
    weight: 2,
    match: (p) =>
      /초록|녹색|진녹|연두|에메랄드|그린/.test(p.characteristics.colorDescription),
  },
  {
    id: 'color-variegated',
    group: 'color',
    keywords: ['무늬', '줄무늬', '얼룩', '핀스트라이프', '호랑이', '투톤'],
    label: '잎 무늬 · 줄무늬',
    weight: 5,
    match: (p) =>
      /무늬|줄무늬|얼룩|대리석|스트라이프|테두리/.test(
        `${p.characteristics.colorDescription} ${p.characteristics.appearance} ${p.summary}`
      ),
  },

  // Scents
  {
    id: 'scent-none',
    group: 'scent',
    keywords: ['무향', '냄새 없', '냄새가 없', '향 없', '향이 없', '향기 없', '향기가 없', '냄새 안', '향 안'],
    label: '향이 거의 없는 무향',
    weight: 7,
    match: (p) => p.characteristics.scentIntensity === '거의 없음',
  },
  {
    id: 'scent-sweet',
    group: 'scent',
    keywords: ['달콤', '달달', '꿀', '초콜릿', '복숭아', '살구', '사과', '과일향', '바닐라'],
    label: '달콤한 과일 · 꽃향기',
    weight: 6,
    match: (p) =>
      /달콤|달달|꿀|초콜릿|복숭아|살구|사과|바닐라|청사과/.test(p.characteristics.scent),
  },
  {
    id: 'scent-herb',
    group: 'scent',
    keywords: ['허브', '아로마', '스파이시', '로즈마리', '라벤더', '바질', '타임'],
    label: '상쾌한 허브 아로마',
    weight: 5,
    match: (p) =>
      p.category === '허브·방향식물' ||
      /허브|아로마|스파이시/.test(p.characteristics.scent),
  },
  {
    id: 'scent-citrus',
    group: 'scent',
    keywords: ['시트러스', '레몬', '감귤', '오렌지향', '상큼', '귤향'],
    label: '상큼한 시트러스 · 레몬 향',
    weight: 6,
    match: (p) =>
      /시트러스|레몬|감귤|네롤리|상큼/.test(p.characteristics.scent),
  },
  {
    id: 'scent-mint',
    group: 'scent',
    keywords: ['멘톨', '박하', '민트', '피톤치드', '청량', '솔잎', '숲향', '시원한 향'],
    label: '시원한 숲 · 멘톨 향',
    weight: 6,
    match: (p) =>
      /멘톨|박하|시원|숲|피톤치드|청량|솔잎|시네올/.test(p.characteristics.scent),
  },
  {
    id: 'scent-mild',
    group: 'scent',
    keywords: ['은은한 향', '은은한 꽃향', '약한 향', '은은하게'],
    shouldTrigger: (_lower, compact) =>
      !HAS_SCENT_NEGATION(compact) &&
      /(은은한향|은은한꽃향|은은한허브|은은하게|약한향)/.test(compact),
    label: '은은하고 부담 없는 향기',
    weight: 4,
    match: (p) => /은은/.test(p.characteristics.scentIntensity),
  },
  {
    id: 'scent-strong',
    group: 'scent',
    keywords: ['진한 향', '강한 향', '향이 진', '향이 강', '향기가 강', '향기가 진', '만리향'],
    shouldTrigger: (_lower, compact) =>
      !HAS_SCENT_NEGATION(compact) &&
      /(진한향|강한향|향기강|향기가강|향기진|향기가진|향이강|향이진|만리향)/.test(compact),
    label: '멀리 퍼지는 진한 향기',
    weight: 6,
    match: (p) => /강함/.test(p.characteristics.scentIntensity),
  },
  {
    id: 'scent-floral',
    group: 'scent',
    keywords: ['꽃향', '플로럴', '향기', '향수', '향긋', '좋은 냄새', '냄새', '발향'],
    shouldTrigger: (_lower, compact) => !HAS_SCENT_NEGATION(compact),
    label: '향기로운 발향 특성',
    weight: 3,
    match: (p) => p.characteristics.scentIntensity !== '거의 없음',
  },
  {
    id: 'scent-night',
    group: 'scent',
    keywords: ['밤에', '저녁에', '야간'],
    label: '밤에 짙어지는 향기',
    weight: 6,
    match: (p) => /밤|저녁|야간/.test(p.characteristics.scent),
  },

  // Appearance
  {
    id: 'app-fenestrated',
    group: 'appearance',
    keywords: ['구멍', '찢어', '천공', '갈라진'],
    label: '구멍 뚫리고 찢어진 잎',
    weight: 8,
    match: (p) =>
      /구멍|천공|찢어/.test(`${p.characteristics.appearance} ${p.summary}`),
  },
  {
    id: 'app-round',
    group: 'appearance',
    keywords: ['둥근', '동그란', '동글', '동전', '원형', '하트'],
    label: '둥글고 부드러운 잎 형태',
    weight: 5,
    match: (p) =>
      /둥근|동그|동글|동전|원형|하트/.test(
        `${p.characteristics.appearance} ${p.summary}`
      ),
  },
  {
    id: 'app-spiky',
    group: 'appearance',
    keywords: ['가시', '따가', '선인장'],
    label: '가시 · 다육 선인장 특징',
    weight: 7,
    match: (p) =>
      p.id === 'opuntia-microdasys' ||
      /가시|선인장/.test(`${p.characteristics.appearance} ${p.summary} ${p.nameKo}`),
  },
  {
    id: 'app-needle',
    group: 'appearance',
    keywords: ['가늘', '뾰족', '바늘', '침엽', '기둥', '원통', '칼날'],
    label: '가늘고 뾰족한 실루엣',
    weight: 5,
    match: (p) =>
      /가늘|뾰족|바늘|침엽|원통|칼날|원뿔|수직/.test(
        `${p.characteristics.appearance} ${p.summary}`
      ),
  },
  {
    id: 'app-succulent',
    group: 'appearance',
    keywords: ['로제트', '다육', '통통', '도톰'],
    label: '통통한 다육 질감',
    weight: 5,
    match: (p) =>
      p.category === '다육·선인장' ||
      /로제트|다육|통통|도톰/.test(p.characteristics.appearance),
  },
  {
    id: 'app-vine',
    group: 'appearance',
    keywords: ['덩굴', '늘어지', '늘어', '행잉', '공중'],
    label: '늘어지는 덩굴 수형',
    weight: 7,
    match: (p) =>
      /덩굴|늘어지|흘러내리|행잉|아치를 그리며/.test(
        `${p.characteristics.appearance} ${p.characteristics.sizeAndGrowth} ${p.summary}`
      ),
  },
  {
    id: 'app-flower',
    group: 'appearance',
    keywords: ['꽃', '개화', '꽃송이', '꽃볼', '겹꽃'],
    label: '아름다운 꽃 감상',
    weight: 4,
    match: isFloweringPlant,
  },
  {
    id: 'app-fruit',
    group: 'appearance',
    keywords: ['열매', '과실', '과일나무'],
    label: '열매 감상 · 수확',
    weight: 8,
    match: (p) => /열매|귤빛|과실/.test(`${p.characteristics.appearance} ${p.summary}`),
  },
  {
    id: 'app-large',
    group: 'appearance',
    keywords: ['큰 잎', '큰잎', '큰 초록', '큰 식물', '큰 나무', '크고', '넓은 잎', '넓은잎', '대형', '키 큰', '키큰', '이국적', '거실용'],
    label: '큼직하고 이국적인 수형',
    weight: 5,
    match: (p) =>
      /크고|큼직|넓은|바이올린|바나나|대형|1~2m|1.2~2.5m|80cm~1.8m/.test(
        `${p.characteristics.appearance} ${p.characteristics.sizeAndGrowth} ${p.summary}`
      ),
  },
  {
    id: 'app-small',
    group: 'appearance',
    keywords: ['작은', '미니', '아담', '아기자기', '귀여운', '책상', '테이블', '선반', '콤팩트'],
    label: '책상 · 선반용 아담한 크기',
    weight: 5,
    match: (p) =>
      /아담|테이블|선반|책상|콤팩트|미니|15~30cm|20~50cm|25~45cm|10~25cm|15~25cm/.test(
        `${p.characteristics.sizeAndGrowth} ${p.summary}`
      ),
  },
  {
    id: 'app-tree',
    group: 'appearance',
    keywords: ['나무', '목질', '목본', '목대'],
    label: '목질 줄기 나무형',
    weight: 5,
    match: (p) =>
      /나무|목질|관목|소교목|수관|목대/.test(
        `${p.characteristics.appearance} ${p.summary} ${p.nameKo}`
      ),
  },
  {
    id: 'app-glossy',
    group: 'appearance',
    keywords: ['광택', '윤기', '반짝', '가죽질'],
    label: '윤기 나는 광택 잎',
    weight: 4,
    match: (p) =>
      /광택|윤기|가죽질|반짝/.test(`${p.characteristics.appearance} ${p.summary}`),
  },
  {
    id: 'app-fuzzy',
    group: 'appearance',
    keywords: ['솜털', '보송', '벨벳', '부드러운 잎'],
    label: '보송보송한 솜털 · 벨벳 질감',
    weight: 6,
    match: (p) =>
      /솜털|보송|벨벳/.test(
        `${p.characteristics.appearance} ${p.characteristics.colorDescription} ${p.summary}`
      ),
  },

  // Environment / Difficulty / Safety / Lifestyle
  {
    id: 'env-easy',
    group: 'env',
    keywords: ['초보', '쉬운', '쉬움', '키우기 쉬', '잘 안 죽', '잘안죽', '입문', '튼튼', '잘 자라'],
    label: '초보자 추천 난이도',
    weight: 4,
    match: (p) => p.difficulty === '초보자 추천',
  },
  {
    id: 'env-dry',
    group: 'env',
    keywords: ['물 적', '물적', '건조', '가끔 물', '물 안', '물안', '물 자주 안', '바쁜'],
    label: '건조에 강한 적은 물주기',
    weight: 5,
    match: (p) =>
      p.category === '다육·선인장' ||
      /2~3주|한 달|월 1|건조에 강|물 주기를 줄|마른 뒤/.test(
        `${p.careGuide.watering} ${p.careGuide.wateringCycle}`
      ),
  },
  {
    id: 'env-moist',
    group: 'env',
    keywords: ['물 좋아', '물좋아', '물 많이', '물많이', '촉촉', '습한 흙'],
    label: '수분을 좋아하는 촉촉한 환경',
    weight: 5,
    match: (p) =>
      /촉촉|물마름에 약|수분|물 주는 양|다습/.test(
        `${p.careGuide.watering} ${p.careGuide.wateringCycle} ${p.summary}`
      ),
  },
  {
    id: 'env-hydro',
    group: 'env',
    keywords: ['수경', '물꽂이', '수경재배'],
    label: '수경재배 · 물꽂이 가능',
    weight: 7,
    match: (p) =>
      /수경|물꽂이/.test(
        `${p.summary} ${p.careGuide.watering} ${p.careGuide.soil} ${p.nameKo}`
      ),
  },
  {
    id: 'env-shade',
    group: 'env',
    keywords: ['반음지', '어두운', '어두워', '그늘', '형광등', '사무실', '원룸', '빛 적', '빛이 적', '빛 없', '햇빛 없'],
    label: '반음지 · 적은 빛 적응력',
    weight: 5,
    match: (p) =>
      /반음지|형광등|어두운|적은 빛/.test(p.careGuide.sunlight),
  },
  {
    id: 'env-sun',
    group: 'env',
    keywords: ['햇빛', '양지', '창가', '직사광선', '베란다'],
    shouldTrigger: (_lower, compact) => !/(햇빛없|햇빛이없)/.test(compact),
    label: '햇빛 잘 드는 창가 · 베란다 적합',
    weight: 4,
    match: (p) => /직사광선|양지|창가|베란다/.test(p.careGuide.sunlight),
  },
  {
    id: 'env-pet',
    group: 'env',
    keywords: ['반려동물', '고양이', '강아지', '독성 없', '독성없', '안전', '무독성'],
    label: '반려동물 안전(무독성)',
    weight: 6,
    match: (p) =>
      /독성이 없|안전한|무독성|독성이 전혀|독성이 보고되지/.test(
        p.characteristics.petSafety
      ),
  },
  {
    id: 'env-air',
    group: 'env',
    keywords: ['공기정화', '공기 정화', '가습', '정화', '침실', '미세먼지'],
    label: '뛰어난 공기정화 능력',
    weight: 5,
    match: (p) =>
      p.category === '공기정화·야자' ||
      /공기정화|포름알데히드|산소|가습/.test(
        `${p.summary} ${p.funFact} ${p.careGuide.humidity}`
      ),
  },
  {
    id: 'env-gift',
    group: 'env',
    keywords: ['선물', '집들이', '개업', '승진', '크리스마스', '연말', '기념일'],
    label: '선물 · 기념일 인기 식물',
    weight: 5,
    match: (p) =>
      /선물|개업|집들이|승진|행운|행복|크리스마스|연말|산타/.test(
        `${p.summary} ${p.funFact}`
      ),
  },
  {
    id: 'env-interior',
    group: 'env',
    keywords: ['인테리어', '플랜테리어', '카페', '모던', '감성', '유럽', '지중해'],
    label: '감각적인 플랜테리어 포인트',
    weight: 3,
    match: (p) =>
      p.category === '관엽식물' ||
      /인테리어|카페|지중해|조형|수형|감성|우아/.test(
        `${p.summary} ${p.characteristics.appearance} ${p.funFact}`
      ),
  },
  {
    id: 'env-tropical',
    group: 'env',
    keywords: ['열대', '정글', '휴양지', '트로피컬'],
    label: '이국적인 열대 정원 분위기',
    weight: 4,
    match: (p) =>
      /열대|중남미|아마존|트로피컬|이국/.test(
        `${p.origin} ${p.summary} ${p.characteristics.appearance}`
      ),
  },
  {
    id: 'env-culinary',
    group: 'env',
    keywords: ['요리', '식용', '허브티', '차로', '음식', '먹을'],
    label: '요리 · 허브티 활용 가능',
    weight: 6,
    match: (p) =>
      p.category === '허브·방향식물' &&
      /요리|허브티|차|샐러드|파스타|티|식용/.test(`${p.summary} ${p.funFact}`),
  },
  {
    id: 'env-humidity',
    group: 'env',
    keywords: ['욕실', '화장실', '습기', '습한 환경', '공중습도'],
    label: '높은 습도를 좋아하는 식물',
    weight: 5,
    match: (p) =>
      /높은 습도|습도 60|습도 70|습한|분무|열대우림/.test(
        `${p.careGuide.humidity} ${p.summary}`
      ),
  },

  // Broad Moods, Rooms, Benefits, Occasions & Plant Bridges (so any keyword yields fitting plants)
  {
    id: 'theme-healing',
    group: 'theme',
    keywords: ['힐링', '편안', '치유', '휴식', '안정', '위로', '스트레스', '여유', '차분', '평온'],
    label: '마음이 편안해지는 힐링 감성',
    weight: 5,
    match: (p) =>
      p.category === '허브·방향식물' ||
      [
        'lavandula-angustifolia',
        'matricaria-chamomilla',
        'melissa-officinalis',
        'dypsis-lutescens',
        'spathiphyllum-wallisii',
        'dracaena-fragrans',
        'olea-europaea',
      ].includes(p.id),
  },
  {
    id: 'theme-luxury',
    group: 'theme',
    keywords: ['고급', '우아', '세련', '럭셔리', '화려', '멋진', '품격', '호텔', '고귀'],
    label: '고급스럽고 우아한 포인트',
    weight: 5,
    match: (p) =>
      [
        'phalaenopsis-orchid',
        'strelitzia-nicolai',
        'paeonia-lactiflora',
        'ficus-lyrata',
        'alocasia-frydek',
        'tacca-chantrieri',
        'hydrangea-macrophylla',
        'camellia-japonica',
      ].includes(p.id),
  },
  {
    id: 'theme-unique',
    group: 'theme',
    keywords: ['독특', '신비', '특이', '개성', '희귀', '신기', '이색', '기묘', '매혹'],
    label: '개성 있고 신비로운 매력',
    weight: 5,
    match: (p) =>
      [
        'tacca-chantrieri',
        'opuntia-microdasys',
        'dracaena-angolensis',
        'monstera-deliciosa',
        'aeonium-arboreum-zwartkop',
        'alocasia-reginula',
        'strelitzia-nicolai',
        'hoya-carnosa',
      ].includes(p.id),
  },
  {
    id: 'theme-cute',
    group: 'theme',
    keywords: ['귀여', '아기자기', '앙증', '러블리', '사랑스러', '예쁜', '예쁘'],
    label: '아기자기하고 사랑스러운 매력',
    weight: 4,
    match: (p) =>
      [
        'pilea-peperomioides',
        'echeveria-laui',
        'hoya-carnosa',
        'nemophila-menziesii',
        'myosotis-sylvatica',
        'mentha-suaveolens',
        'opuntia-microdasys',
        'rosa-miniature',
      ].includes(p.id),
  },
  {
    id: 'theme-modern',
    group: 'theme',
    keywords: ['모던', '미니멀', '심플', '깔끔', '단정', '시크', '도시', '빈티지', '레트로'],
    label: '깔끔하고 감각적인 공간 연출',
    weight: 5,
    match: (p) =>
      [
        'dracaena-angolensis',
        'dracaena-trifasciata-moonshine',
        'zamioculcas-zamiifolia-raven',
        'ficus-elastica',
        'ficus-benghalensis',
        'olea-europaea',
        'eucalyptus-polyanthemos',
        'philodendron-birkin',
      ].includes(p.id),
  },
  {
    id: 'theme-romantic',
    group: 'theme',
    keywords: ['낭만', '로맨틱', '감동', '사랑', '설렘', '웨딩', '결혼', '신혼', '부케', '프로포즈', '고백'],
    label: '로맨틱 · 기념일에 어울리는 화초',
    weight: 5,
    match: (p) =>
      [
        'paeonia-lactiflora',
        'rosa-miniature',
        'freesia-refracta',
        'myosotis-sylvatica',
        'delphinium-elatum',
        'hydrangea-macrophylla',
        'lavandula-angustifolia',
        'jasminum-sambac',
      ].includes(p.id),
  },
  {
    id: 'theme-sleep',
    group: 'theme',
    keywords: ['불면', '숙면', '수면', '안방', '침대', '수험생'],
    exactTokens: ['잠', '밤'],
    label: '숙면과 밤 공기에 좋은 침실 식물',
    weight: 6,
    match: (p) =>
      [
        'dracaena-trifasciata-moonshine',
        'dracaena-angolensis',
        'lavandula-angustifolia',
        'matricaria-chamomilla',
        'jasminum-sambac',
        'melissa-officinalis',
        'spathiphyllum-wallisii',
      ].includes(p.id),
  },
  {
    id: 'theme-desk',
    group: 'theme',
    keywords: ['집중', '공부', '독서', '서재', '작업', '컴퓨터', '모니터', '전자파', '회사', '오피스', '업무', '책'],
    label: '책상 · 서재 · 집중력에 좋은 식물',
    weight: 5,
    match: (p) =>
      [
        'salvia-rosmarinus',
        'mentha-piperita',
        'dracaena-angolensis',
        'chamaedorea-elegans',
        'pilea-peperomioides',
        'echeveria-laui',
        'dracaena-trifasciata-moonshine',
      ].includes(p.id),
  },
  {
    id: 'theme-livingroom',
    group: 'theme',
    keywords: ['소파', '넓은 방', '현관', '복도', '입구', '매장', '가게'],
    exactTokens: ['방', '집'],
    label: '집 · 거실 · 공간 인테리어 맞춤',
    weight: 4,
    match: (p) =>
      [
        'monstera-deliciosa',
        'strelitzia-nicolai',
        'ficus-lyrata',
        'ficus-elastica',
        'dypsis-lutescens',
        'pachira-aquatica',
        'zamioculcas-zamiifolia',
        'chamaedorea-elegans',
      ].includes(p.id),
  },
  {
    id: 'theme-kitchen',
    group: 'theme',
    keywords: ['주방', '부엌', '식탁', '요리', '향신료'],
    label: '주방 창가 · 키친 가든 맞춤',
    weight: 5,
    match: (p) =>
      [
        'ocimum-basilicum',
        'salvia-rosmarinus',
        'thymus-vulgaris',
        'mentha-suaveolens',
        'mentha-piperita',
        'pilea-peperomioides',
        'kalanchoe-blossfeldiana',
      ].includes(p.id),
  },
  {
    id: 'theme-wealth',
    group: 'theme',
    keywords: ['재물', '금전', '부자', '사업', '대박', '성공', '풍수', '번창', '행운', '복', '새해', '부귀'],
    exactTokens: ['돈', '복'],
    label: '재물운 · 행운을 부르는 풍수 식물',
    weight: 6,
    match: (p) =>
      [
        'zamioculcas-zamiifolia',
        'zamioculcas-zamiifolia-raven',
        'crassula-ovata',
        'pachira-aquatica',
        'dracaena-fragrans',
        'nemophila-menziesii',
        'eucalyptus-polyanthemos',
      ].includes(p.id),
  },
  {
    id: 'theme-bug',
    group: 'theme',
    keywords: ['모기', '벌레', '해충', '파리', '방충', '퇴치', '벌레퇴치'],
    label: '천연 방충 · 모기 기피 효과',
    weight: 7,
    match: (p) =>
      [
        'salvia-rosmarinus',
        'lavandula-angustifolia',
        'pelargonium-hortorum',
        'mentha-piperita',
        'melissa-officinalis',
        'eucalyptus-polyanthemos',
        'thymus-vulgaris',
      ].includes(p.id),
  },
  {
    id: 'theme-humidify',
    group: 'theme',
    keywords: ['가습', '비염', '코막힘', '호흡', '맑은 공기', '먼지'],
    label: '천연 가습 · 쾌적한 실내 환경',
    weight: 5,
    match: (p) =>
      [
        'nephrolepis-exaltata',
        'dypsis-lutescens',
        'chamaedorea-elegans',
        'spathiphyllum-wallisii',
        'dracaena-fragrans',
        'eucalyptus-polyanthemos',
      ].includes(p.id),
  },
  {
    id: 'theme-occasion',
    group: 'theme',
    keywords: ['어버이', '엄마', '아빠', '부모님', '스승', '감사', '생일', '졸업', '축하', '효도'],
    label: '감사 · 축하 선물 추천 화분',
    weight: 5,
    match: (p) =>
      [
        'phalaenopsis-orchid',
        'kalanchoe-blossfeldiana',
        'rosa-miniature',
        'freesia-refracta',
        'hydrangea-macrophylla',
        'camellia-japonica',
        'paeonia-lactiflora',
      ].includes(p.id),
  },
  {
    id: 'theme-christmas',
    group: 'theme',
    keywords: ['크리스마스', '성탄', '트리', '겨울장식', '눈꽃', '연말파티'],
    exactTokens: ['눈'],
    label: '크리스마스 · 겨울 감성 연출',
    weight: 6,
    match: (p) =>
      [
        'cupressus-macrocarpa-goldcrest',
        'camellia-japonica',
        'anthurium-andraeanum',
        'kalanchoe-blossfeldiana',
        'olea-europaea',
        'spathiphyllum-wallisii',
      ].includes(p.id),
  },
  {
    id: 'theme-nightsky',
    group: 'theme',
    keywords: ['우주', '밤하늘', '달빛', '야경', '은하', '별빛', '별모양'],
    exactTokens: ['별', '달'],
    label: '별빛 · 달빛 감성의 신비로운 식물',
    weight: 6,
    match: (p) =>
      [
        'hoya-carnosa',
        'dracaena-trifasciata-moonshine',
        'jasminum-sambac',
        'aeonium-arboreum-zwartkop',
        'nemophila-menziesii',
        'delphinium-elatum',
      ].includes(p.id),
  },
  {
    id: 'theme-forest',
    group: 'theme',
    keywords: ['캠핑', '피톤치드', '자연', '등산', '숲속', '산림욕', '나무향'],
    exactTokens: ['숲', '산'],
    label: '상쾌한 숲 · 피톤치드 분위기',
    weight: 5,
    match: (p) =>
      [
        'cupressus-macrocarpa-goldcrest',
        'eucalyptus-polyanthemos',
        'salvia-rosmarinus',
        'nephrolepis-exaltata',
        'dypsis-lutescens',
        'epipremnum-aureum',
      ].includes(p.id),
  },
  {
    id: 'theme-sea',
    group: 'theme',
    keywords: ['바다', '해변', '여행', '휴가', '휴양', '오션', '청량감'],
    label: '푸른 바다 · 휴양지 무드',
    weight: 5,
    match: (p) =>
      [
        'nemophila-menziesii',
        'myosotis-sylvatica',
        'plumbago-auriculata',
        'dypsis-lutescens',
        'monstera-deliciosa',
        'strelitzia-nicolai',
      ].includes(p.id),
  },
  {
    id: 'theme-tea',
    group: 'theme',
    keywords: ['커피', '티타임', '디저트', '향차', '허브차', '차향', '오후'],
    exactTokens: ['차'],
    label: '티타임 · 카페와 어울리는 향긋한 식물',
    weight: 5,
    match: (p) =>
      [
        'matricaria-chamomilla',
        'mentha-piperita',
        'mentha-suaveolens',
        'melissa-officinalis',
        'salvia-rosmarinus',
        'osmanthus-fragrans',
        'lavandula-angustifolia',
      ].includes(p.id),
  },
  {
    id: 'theme-sun',
    group: 'theme',
    keywords: ['태양', '열정', '에너지', '활력', '아침', '긍정', '화사', '밝은'],
    exactTokens: ['불', '해'],
    label: '햇살처럼 밝고 화사한 에너지',
    weight: 5,
    match: (p) =>
      [
        'helianthus-annuus',
        'anthurium-andraeanum',
        'camellia-japonica',
        'pelargonium-hortorum',
        'citrus-japonica',
        'rosa-miniature',
        'freesia-refracta',
      ].includes(p.id),
  },
  {
    id: 'theme-rain',
    group: 'theme',
    keywords: ['장마', '빗물', '비오는', '물방울', '이슬', '싱그러운'],
    exactTokens: ['비', '물'],
    label: '빗방울·물과 잘 어울리는 싱그러운 식물',
    weight: 4,
    match: (p) =>
      [
        'nephrolepis-exaltata',
        'epipremnum-aureum',
        'pilea-peperomioides',
        'monstera-deliciosa',
        'spathiphyllum-wallisii',
        'hydrangea-macrophylla',
      ].includes(p.id),
  },
  {
    id: 'theme-music',
    group: 'theme',
    keywords: ['음악', '노래', '예술', '그림', '영화', '감성적', '분위기 있'],
    exactTokens: ['시'],
    label: '예술적이고 서정적인 공간 감성',
    weight: 4,
    match: (p) =>
      [
        'philodendron-birkin',
        'phalaenopsis-orchid',
        'tacca-chantrieri',
        'olea-europaea',
        'lavandula-angustifolia',
        'eucalyptus-polyanthemos',
      ].includes(p.id),
  },

  // Common Korean Plant Bridges (for outdoor/seasonal species outside the 66 catalog)
  {
    id: 'bridge-cherry',
    group: 'theme',
    keywords: ['벚꽃', '사쿠라', '꽃놀이', '봄꽃'],
    label: '벚꽃처럼 화사한 봄 개화 감성',
    weight: 7,
    match: (p) =>
      [
        'paeonia-lactiflora',
        'tulipa-gesneriana',
        'camellia-japonica',
        'hyacinthus-orientalis',
        'hydrangea-macrophylla',
        'kalanchoe-blossfeldiana',
      ].includes(p.id),
  },
  {
    id: 'bridge-plum',
    group: 'theme',
    keywords: ['매화', '매실', '목련', '백목련'],
    label: '고아한 향기 꽃나무 감성',
    weight: 7,
    match: (p) =>
      [
        'osmanthus-fragrans',
        'murraya-paniculata',
        'camellia-japonica',
        'gardenia-jasminoides',
        'jasminum-sambac',
      ].includes(p.id),
  },
  {
    id: 'bridge-forsythia',
    group: 'theme',
    keywords: ['개나리', '유채', '수선화'],
    label: '개나리·수선화처럼 화사한 노랑·봄꽃',
    weight: 7,
    match: (p) =>
      [
        'freesia-refracta',
        'helianthus-annuus',
        'kalanchoe-blossfeldiana',
        'citrus-japonica',
        'tulipa-gesneriana',
      ].includes(p.id),
  },
  {
    id: 'bridge-azalea',
    group: 'theme',
    keywords: ['진달래', '철쭉', '영산홍', '모란'],
    label: '진달래·모란처럼 풍성한 분홍·자주 꽃',
    weight: 7,
    match: (p) =>
      [
        'paeonia-lactiflora',
        'camellia-japonica',
        'hydrangea-macrophylla',
        'pelargonium-hortorum',
        'saintpaulia-ionantha',
      ].includes(p.id),
  },
  {
    id: 'bridge-chrysanthemum',
    group: 'theme',
    keywords: ['국화', '코스모스', '데이지', '마가렛', '가을꽃', '들꽃'],
    label: '국화·코스모스처럼 청초한 꽃 감성',
    weight: 7,
    match: (p) =>
      [
        'matricaria-chamomilla',
        'helianthus-annuus',
        'kalanchoe-blossfeldiana',
        'myosotis-sylvatica',
        'nemophila-menziesii',
        'pelargonium-hortorum',
      ].includes(p.id),
  },
  {
    id: 'bridge-lily',
    group: 'theme',
    keywords: ['백합', '은방울', '칼라', '릴리', '붓꽃', '아이리스', '카네이션'],
    label: '백합·은방울꽃처럼 기품 있는 관화식물',
    weight: 7,
    match: (p) =>
      [
        'spathiphyllum-wallisii',
        'phalaenopsis-orchid',
        'delphinium-elatum',
        'jasminum-sambac',
        'tulipa-gesneriana',
        'paeonia-lactiflora',
      ].includes(p.id),
  },
  {
    id: 'bridge-pine',
    group: 'theme',
    keywords: ['소나무', '전나무', '측백', '편백', '분재'],
    label: '소나무·분재처럼 사계절 푸른 상록 수형',
    weight: 7,
    match: (p) =>
      [
        'cupressus-macrocarpa-goldcrest',
        'olea-europaea',
        'salvia-rosmarinus',
        'dracaena-angolensis',
        'crassula-ovata',
      ].includes(p.id),
  },
  {
    id: 'bridge-bamboo',
    group: 'theme',
    keywords: ['대나무', '개운죽', '야자수', '야자', '관음죽', '종려'],
    label: '대나무·야자처럼 시원하게 뻗는 수형',
    weight: 7,
    match: (p) =>
      [
        'dypsis-lutescens',
        'chamaedorea-elegans',
        'pachira-aquatica',
        'dracaena-angolensis',
        'dracaena-fragrans',
      ].includes(p.id),
  },
  {
    id: 'bridge-lotus',
    group: 'theme',
    keywords: ['연꽃', '수련', '물식물', '수생'],
    label: '연꽃·수생식물처럼 물과 친한 청초함',
    weight: 7,
    match: (p) =>
      [
        'spathiphyllum-wallisii',
        'pilea-peperomioides',
        'epipremnum-aureum',
        'monstera-deliciosa',
        'hedera-helix',
      ].includes(p.id),
  },
  {
    id: 'bridge-orchid',
    group: 'theme',
    keywords: ['난초', '동양란', '서양란', '심비디움', '풍란'],
    exactTokens: ['난'],
    label: '난초처럼 우아하고 단정한 관상미',
    weight: 7,
    match: (p) =>
      [
        'phalaenopsis-orchid',
        'ophiopogon-planiscapus-nigrescens',
        'spathiphyllum-wallisii',
        'anthurium-andraeanum',
      ].includes(p.id),
  },
];

export function getCurrentSeason(date: Date = new Date()): PlantSeason {
  const month = date.getMonth() + 1;
  if (month >= 3 && month <= 5) return '봄';
  if (month >= 6 && month <= 8) return '여름';
  if (month >= 9 && month <= 11) return '가을';
  return '겨울';
}

interface SeasonProfile {
  label: string;
  peakIds: string[];
  goodIds: string[];
  avoidIds: string[];
}

const SEASON_PROFILES: Record<PlantSeason, SeasonProfile> = {
  봄: {
    label: '봄철 개화 · 활발한 성장기 추천',
    peakIds: [
      'tulipa-gesneriana',
      'freesia-refracta',
      'hyacinthus-orientalis',
      'paeonia-lactiflora',
      'lavandula-angustifolia',
      'matricaria-chamomilla',
      'thymus-vulgaris',
      'salvia-rosmarinus',
      'camellia-japonica',
      'hydrangea-macrophylla',
      'echeveria-laui',
      'nemophila-menziesii',
      'myosotis-sylvatica',
      'delphinium-elatum',
      'aeonium-arboreum-zwartkop',
    ],
    goodIds: [
      'murraya-paniculata',
      'rosa-miniature',
      'pelargonium-hortorum',
      'jasminum-sambac',
      'hoya-carnosa',
      'ocimum-basilicum',
      'melissa-officinalis',
      'mentha-suaveolens',
      'spathiphyllum-wallisii',
      'saintpaulia-ionantha',
      'anthurium-andraeanum',
      'monstera-deliciosa',
      'pilea-peperomioides',
      'ficus-elastica',
      'ficus-lyrata',
      'ficus-benghalensis',
      'dypsis-lutescens',
      'plumbago-auriculata',
      'zamioculcas-zamiifolia-raven',
      'alocasia-reginula',
      'ophiopogon-planiscapus-nigrescens',
    ],
    avoidIds: [],
  },
  여름: {
    label: '여름철 개화 · 고온기 생육 추천',
    peakIds: [
      'jasminum-sambac',
      'helianthus-annuus',
      'gardenia-jasminoides',
      'hydrangea-macrophylla',
      'ocimum-basilicum',
      'mentha-piperita',
      'mentha-suaveolens',
      'melissa-officinalis',
      'hoya-carnosa',
      'citrus-japonica',
      'olea-europaea',
      'plumbago-auriculata',
      'tacca-chantrieri',
      'alocasia-reginula',
    ],
    goodIds: [
      'lavandula-angustifolia',
      'strelitzia-nicolai',
      'monstera-deliciosa',
      'epipremnum-aureum',
      'spathiphyllum-wallisii',
      'dypsis-lutescens',
      'anthurium-andraeanum',
      'alocasia-frydek',
      'philodendron-birkin',
      'pachira-aquatica',
      'opuntia-microdasys',
      'aloe-vera',
      'murraya-paniculata',
      'rosa-miniature',
      'zamioculcas-zamiifolia-raven',
      'ophiopogon-planiscapus-nigrescens',
    ],
    avoidIds: [
      'cupressus-macrocarpa-goldcrest',
      'tulipa-gesneriana',
      'hyacinthus-orientalis',
      'freesia-refracta',
    ],
  },
  가을: {
    label: '가을철 개화 · 선선한 계절 추천',
    peakIds: [
      'osmanthus-fragrans',
      'citrus-japonica',
      'cupressus-macrocarpa-goldcrest',
      'eucalyptus-polyanthemos',
      'pelargonium-hortorum',
      'rosa-miniature',
      'echeveria-laui',
      'crassula-ovata',
      'phalaenopsis-orchid',
      'hedera-helix',
      'plumbago-auriculata',
      'aeonium-arboreum-zwartkop',
      'ophiopogon-planiscapus-nigrescens',
    ],
    goodIds: [
      'murraya-paniculata',
      'spathiphyllum-wallisii',
      'saintpaulia-ionantha',
      'anthurium-andraeanum',
      'dracaena-trifasciata-moonshine',
      'dracaena-angolensis',
      'zamioculcas-zamiifolia',
      'zamioculcas-zamiifolia-raven',
      'ficus-elastica',
      'ficus-benghalensis',
      'chamaedorea-elegans',
      'nephrolepis-exaltata',
      'opuntia-microdasys',
    ],
    avoidIds: ['tulipa-gesneriana', 'hyacinthus-orientalis', 'freesia-refracta'],
  },
  겨울: {
    label: '겨울철 개화 · 실내 월동 적합 추천',
    peakIds: [
      'camellia-japonica',
      'kalanchoe-blossfeldiana',
      'phalaenopsis-orchid',
      'hyacinthus-orientalis',
      'salvia-rosmarinus',
      'crassula-ovata',
      'cupressus-macrocarpa-goldcrest',
      'citrus-japonica',
      'saintpaulia-ionantha',
      'anthurium-andraeanum',
      'zamioculcas-zamiifolia-raven',
      'ophiopogon-planiscapus-nigrescens',
    ],
    goodIds: [
      'freesia-refracta',
      'hedera-helix',
      'olea-europaea',
      'dracaena-trifasciata-moonshine',
      'dracaena-angolensis',
      'zamioculcas-zamiifolia',
      'chamaedorea-elegans',
      'dracaena-fragrans',
      'aloe-vera',
      'epipremnum-aureum',
      'aeonium-arboreum-zwartkop',
    ],
    avoidIds: ['ocimum-basilicum', 'helianthus-annuus'],
  },
};

function detectSeasonFromInput(
  seasonInput?: string,
  description?: string
): PlantSeason | null {
  const candidates: PlantSeason[] = ['봄', '여름', '가을', '겨울'];
  if (seasonInput) {
    const trimmed = seasonInput.trim() as PlantSeason;
    if (candidates.includes(trimmed)) return trimmed;
  }
  if (description) {
    for (const s of candidates) {
      if (description.includes(s)) return s;
    }
  }
  return null;
}

function stripKoreanParticles(token: string): string {
  return token
    .replace(/(에서|으로|처럼|같은|하고|이랑|에게|한테|보다|까지|부터)$/g, '')
    .replace(/(은|는|이|가|을|를|의|에|로|와|과|도|만)$/g, '');
}

function extractKoreanBigrams(text: string): string[] {
  const clean = text.replace(/[^가-힣a-z0-9]/gi, '').toLowerCase();
  const bigrams: string[] = [];
  for (let i = 0; i < clean.length - 1; i++) {
    bigrams.push(clean.slice(i, i + 2));
  }
  return Array.from(new Set(bigrams));
}

const NON_EXCLUSIVE_GROUP_WORDS = new Set(['선인장', '다육', '다육이']);

interface ExternalPlantSimilarityProfile {
  displayName: string;
  aliases: string[];
  reasonLabel: string;
  preferredIds: string[];
  categories: PlantProfile['category'][];
  traitRuleIds: string[];
}

const EXTERNAL_PLANT_SIMILARITY_PROFILES: ExternalPlantSimilarityProfile[] = [
  {
    displayName: '해피트리',
    aliases: ['해피트리', '행복나무', '녹보수', '황칠나무', '홍콩야자', '쉐플레라'],
    reasonLabel: '풍성한 초록 목질 수형과 실내 플랜테리어 감성',
    preferredIds: ['pachira-aquatica', 'ficus-benghalensis', 'ficus-lyrata', 'ficus-elastica', 'dracaena-fragrans', 'olea-europaea'],
    categories: ['관엽식물'],
    traitRuleIds: ['color-green', 'app-tree', 'app-glossy', 'env-air', 'env-interior'],
  },
  {
    displayName: '벤자민고무나무',
    aliases: ['벤자민고무나무', '인삼벤자민', '벤자민'],
    reasonLabel: '단단한 목질 줄기와 우아한 관엽 잎',
    preferredIds: ['ficus-benghalensis', 'ficus-elastica', 'ficus-lyrata', 'pachira-aquatica', 'olea-europaea', 'eucalyptus-polyanthemos'],
    categories: ['관엽식물'],
    traitRuleIds: ['color-green', 'app-tree', 'app-glossy', 'env-air'],
  },
  {
    displayName: '싱고니움',
    aliases: ['싱고니움', '무늬싱고니움'],
    reasonLabel: '하트·화살촉 모양의 천남성과 관엽 잎과 순한 실내 적응력',
    preferredIds: ['philodendron-birkin', 'epipremnum-aureum', 'alocasia-frydek', 'spathiphyllum-wallisii', 'aglaonema-commutatum', 'dieffenbachia'],
    categories: ['관엽식물'],
    traitRuleIds: ['color-variegated', 'color-green', 'env-shade', 'env-easy', 'env-hydro'],
  },
  {
    displayName: '페페로미아',
    aliases: ['페페로미아', '수박페페', '아몬드페페', '청페페', '홀리페페', '오르바페페'],
    reasonLabel: '도톰하고 동글동글한 아담한 관엽 잎과 아기자기한 크기',
    preferredIds: ['pilea-peperomioides', 'hoya-carnosa', 'epipremnum-aureum', 'crassula-ovata', 'goeppertia-orbifolia', 'saintpaulia-ionantha'],
    categories: ['관엽식물', '다육·선인장'],
    traitRuleIds: ['app-round', 'app-small', 'app-glossy', 'env-easy', 'env-pet'],
  },
  {
    displayName: '틸란드시아',
    aliases: ['틸란드시아', '이오난사', '수염틸란드시아', '공중식물', '에어플랜트'],
    reasonLabel: '흙 관리 부담이 적고 은빛·독특한 실루엣이 돋보이는 실내 식물',
    preferredIds: ['dracaena-angolensis', 'dracaena-trifasciata-moonshine', 'echeveria-laui', 'nephrolepis-exaltata', 'hedera-helix', 'hoya-carnosa'],
    categories: ['다육·선인장', '관엽식물'],
    traitRuleIds: ['color-silver', 'app-needle', 'app-small', 'env-dry', 'env-easy'],
  },
  {
    displayName: '박쥐란',
    aliases: ['박쥐란', '비프루카툼', '플라티세리움', '사슴뿔고사리'],
    reasonLabel: '개성 있는 잎 형태와 습도·반음지를 좋아하는 착생·고사리 감성',
    preferredIds: ['nephrolepis-exaltata', 'alocasia-frydek', 'monstera-deliciosa', 'hoya-carnosa', 'phalaenopsis-orchid', 'hedera-helix'],
    categories: ['관엽식물'],
    traitRuleIds: ['env-humidity', 'env-shade', 'env-tropical', 'theme-unique'],
  },
  {
    displayName: '디시디아',
    aliases: ['디시디아', '립살리스', '행잉식물', '청옥', '루비네크리스'],
    reasonLabel: '공중에 걸어 늘어뜨리기 좋은 도톰한 덩굴·행잉 수형',
    preferredIds: ['hoya-carnosa', 'epipremnum-aureum', 'hedera-helix', 'nephrolepis-exaltata', 'crassula-ovata', 'pilea-peperomioides'],
    categories: ['관엽식물', '다육·선인장'],
    traitRuleIds: ['app-vine', 'app-succulent', 'env-easy'],
  },
  {
    displayName: '관음죽',
    aliases: ['관음죽', '야자나무', '대나무', '개운죽', '종려죽', '야자수'],
    reasonLabel: '대나무·야자처럼 길쭉하고 시원하게 뻗는 공기정화 잎',
    preferredIds: ['dypsis-lutescens', 'chamaedorea-elegans', 'dracaena-fragrans', 'pachira-aquatica', 'dracaena-angolensis', 'strelitzia-nicolai'],
    categories: ['공기정화·야자', '관엽식물'],
    traitRuleIds: ['app-needle', 'env-air', 'env-pet', 'env-shade'],
  },
  {
    displayName: '하월시아',
    aliases: ['하월시아', '리톱스', '코노피튬', '옵투사', '십이지권', '백은황'],
    reasonLabel: '아담한 로제트 수형과 물을 적게 주는 다육질 매력',
    preferredIds: ['echeveria-laui', 'aloe-vera', 'crassula-ovata', 'aeonium-arboreum-zwartkop', 'dracaena-trifasciata-moonshine', 'opuntia-microdasys'],
    categories: ['다육·선인장'],
    traitRuleIds: ['app-succulent', 'app-small', 'env-dry', 'env-easy'],
  },
  {
    displayName: '커피나무',
    aliases: ['커피나무', '레몬나무', '라임나무', '유자나무', '귤나무', '감귤나무'],
    reasonLabel: '윤기 나는 짙은 초록 잎과 시트러스·흰 꽃의 싱그러움',
    preferredIds: ['citrus-japonica', 'gardenia-jasminoides', 'murraya-paniculata', 'osmanthus-fragrans', 'ficus-elastica', 'camellia-japonica'],
    categories: ['꽃·관화식물', '허브·방향식물'],
    traitRuleIds: ['app-glossy', 'app-tree', 'app-fruit', 'color-green', 'color-white'],
  },
  {
    displayName: '무화과나무',
    aliases: ['무화과나무', '무화과', '아보카도', '아보카도나무', '올리브트리'],
    reasonLabel: '큼직한 관상용 잎과 단정한 나무 수형',
    preferredIds: ['ficus-lyrata', 'ficus-elastica', 'ficus-benghalensis', 'olea-europaea', 'pachira-aquatica', 'citrus-japonica'],
    categories: ['관엽식물'],
    traitRuleIds: ['app-tree', 'app-large', 'color-green', 'env-sun'],
  },
  {
    displayName: '장미허브',
    aliases: ['장미허브', '향기제라늄', '구문초', '애플제라늄', '로즈제라늄'],
    reasonLabel: '보송보송한 잎에서 은은하고 달콤한 허브 향기가 나는 허브류',
    preferredIds: ['mentha-suaveolens', 'pelargonium-hortorum', 'melissa-officinalis', 'mentha-piperita', 'salvia-rosmarinus', 'lavandula-angustifolia'],
    categories: ['허브·방향식물', '꽃·관화식물'],
    traitRuleIds: ['app-fuzzy', 'scent-herb', 'scent-citrus', 'scent-sweet', 'env-sun'],
  },
  {
    displayName: '천리향',
    aliases: ['천리향', '서향', '백서향', '야래향', '월계수'],
    reasonLabel: '밤낮으로 멀리 퍼지는 진하고 매혹적인 꽃향기',
    preferredIds: ['osmanthus-fragrans', 'jasminum-sambac', 'gardenia-jasminoides', 'murraya-paniculata', 'hyacinthus-orientalis', 'hoya-carnosa'],
    categories: ['꽃·관화식물', '허브·방향식물'],
    traitRuleIds: ['scent-strong', 'scent-floral', 'scent-night', 'color-white'],
  },
  {
    displayName: '벚꽃',
    aliases: ['벚꽃', '벚나무', '사쿠라', '왕벚나무'],
    reasonLabel: '봄바람에 화사하게 피어나는 연분홍·순백의 꽃잎 감성',
    preferredIds: ['paeonia-lactiflora', 'tulipa-gesneriana', 'camellia-japonica', 'hydrangea-macrophylla', 'hyacinthus-orientalis', 'kalanchoe-blossfeldiana'],
    categories: ['꽃·관화식물'],
    traitRuleIds: ['color-pink', 'color-white', 'app-flower', 'theme-romantic'],
  },
  {
    displayName: '매화',
    aliases: ['매화', '매실나무', '목련', '백목련', '자목련'],
    reasonLabel: '이른 계절 고아하게 피어나는 꽃과 맑은 플로럴 향기',
    preferredIds: ['osmanthus-fragrans', 'camellia-japonica', 'gardenia-jasminoides', 'murraya-paniculata', 'jasminum-sambac', 'paeonia-lactiflora'],
    categories: ['꽃·관화식물'],
    traitRuleIds: ['color-white', 'color-pink', 'scent-floral', 'app-flower'],
  },
  {
    displayName: '개나리',
    aliases: ['개나리', '수선화', '유채꽃', '유채', '프리지아꽃'],
    reasonLabel: '햇살처럼 맑고 화사한 노란빛 봄 개화 특성',
    preferredIds: ['freesia-refracta', 'helianthus-annuus', 'kalanchoe-blossfeldiana', 'tulipa-gesneriana', 'citrus-japonica', 'matricaria-chamomilla'],
    categories: ['꽃·관화식물'],
    traitRuleIds: ['color-yellow', 'app-flower', 'theme-sun'],
  },
  {
    displayName: '진달래',
    aliases: ['진달래', '철쭉', '영산홍', '모란', '아잘레아'],
    reasonLabel: '풍성한 분홍·다홍빛 꽃송이와 봄·가을 관상 매력',
    preferredIds: ['paeonia-lactiflora', 'camellia-japonica', 'hydrangea-macrophylla', 'pelargonium-hortorum', 'saintpaulia-ionantha', 'rosa-miniature'],
    categories: ['꽃·관화식물'],
    traitRuleIds: ['color-pink', 'color-red', 'app-flower'],
  },
  {
    displayName: '국화',
    aliases: ['국화', '소국', '코스모스', '데이지', '마가렛', '샤스타데이지', '구절초', '과꽃'],
    reasonLabel: '청초하고 단정한 방사형 꽃잎과 산뜻한 계절 꽃 감성',
    preferredIds: ['matricaria-chamomilla', 'helianthus-annuus', 'kalanchoe-blossfeldiana', 'nemophila-menziesii', 'myosotis-sylvatica', 'pelargonium-hortorum'],
    categories: ['꽃·관화식물', '허브·방향식물'],
    traitRuleIds: ['app-flower', 'color-white', 'color-yellow', 'env-sun'],
  },
  {
    displayName: '백합',
    aliases: ['백합', '릴리', '칼라', '칼라릴리', '은방울꽃', '아마릴리스'],
    reasonLabel: '우아하고 기품 있는 화형과 맑은 꽃향기',
    preferredIds: ['spathiphyllum-wallisii', 'phalaenopsis-orchid', 'jasminum-sambac', 'gardenia-jasminoides', 'tulipa-gesneriana', 'paeonia-lactiflora'],
    categories: ['꽃·관화식물'],
    traitRuleIds: ['color-white', 'app-flower', 'scent-floral', 'theme-luxury'],
  },
  {
    displayName: '카네이션',
    aliases: ['카네이션', '라넌큘러스', '거베라', '다알리아', '글라디올러스', '스토크', '비단향꽃무', '알스트로메리아'],
    reasonLabel: '겹겹이 풍성한 꽃잎과 선물용·기념일용 화사한 꽃다발 매력',
    preferredIds: ['paeonia-lactiflora', 'rosa-miniature', 'hydrangea-macrophylla', 'pelargonium-hortorum', 'kalanchoe-blossfeldiana', 'tulipa-gesneriana'],
    categories: ['꽃·관화식물'],
    traitRuleIds: ['app-flower', 'color-pink', 'color-red', 'env-gift', 'theme-occasion'],
  },
  {
    displayName: '시클라멘',
    aliases: ['시클라멘', '베고니아', '엔젤윙베고니아', '렉스베고니아', '프리뮬라'],
    reasonLabel: '실내 밝은 창가에서 오래 감상하는 화사한 실내 꽃·무늬 잎 화초',
    preferredIds: ['saintpaulia-ionantha', 'kalanchoe-blossfeldiana', 'anthurium-andraeanum', 'phalaenopsis-orchid', 'pelargonium-hortorum', 'camellia-japonica'],
    categories: ['꽃·관화식물'],
    traitRuleIds: ['app-flower', 'color-pink', 'color-red', 'app-small', 'env-interior'],
  },
  {
    displayName: '라일락',
    aliases: ['라일락', '수수꽃다리', '등나무', '아이리스', '붓꽃', '아네모네', '수레국화', '루피너스'],
    reasonLabel: '연보라·하늘빛의 매혹적인 꽃송이와 우아한 봄·초여름 향기',
    preferredIds: ['hyacinthus-orientalis', 'lavandula-angustifolia', 'delphinium-elatum', 'hydrangea-macrophylla', 'saintpaulia-ionantha', 'plumbago-auriculata'],
    categories: ['꽃·관화식물', '허브·방향식물'],
    traitRuleIds: ['color-purple', 'color-skyblue', 'app-flower', 'scent-floral'],
  },
  {
    displayName: '안개꽃',
    aliases: ['안개꽃', '스타티스', '미스티블루', '유칼립투스시네레아'],
    reasonLabel: '잔잔하고 몽글몽글한 작은 꽃·여린 잎의 부케 감성',
    preferredIds: ['eucalyptus-polyanthemos', 'matricaria-chamomilla', 'myosotis-sylvatica', 'nemophila-menziesii', 'hydrangea-macrophylla', 'murraya-paniculata'],
    categories: ['꽃·관화식물', '허브·방향식물'],
    traitRuleIds: ['color-white', 'color-silver', 'app-small', 'theme-romantic'],
  },
  {
    displayName: '포인세티아',
    aliases: ['포인세티아', '아마릴리스', '크리스마스선인장', '게발선인장', '호랑가시나무'],
    reasonLabel: '붉고 선명한 겨울·연말 감성과 화려한 실내 관상 포인트',
    preferredIds: ['anthurium-andraeanum', 'camellia-japonica', 'kalanchoe-blossfeldiana', 'cupressus-macrocarpa-goldcrest', 'rosa-miniature', 'citrus-japonica'],
    categories: ['꽃·관화식물'],
    traitRuleIds: ['color-red', 'theme-christmas', 'app-flower'],
  },
  {
    displayName: '소나무',
    aliases: ['소나무', '해송', '전나무', '측백나무', '편백나무', '문그로우', '코니카', '에메랄드그린', '분재'],
    reasonLabel: '사계절 푸른 침엽과 고풍스러운 상록 수형',
    preferredIds: ['cupressus-macrocarpa-goldcrest', 'olea-europaea', 'salvia-rosmarinus', 'eucalyptus-polyanthemos', 'crassula-ovata', 'dracaena-angolensis'],
    categories: ['허브·방향식물', '관엽식물'],
    traitRuleIds: ['app-needle', 'app-tree', 'theme-forest'],
  },
  {
    displayName: '연꽃',
    aliases: ['연꽃', '수련', '물배추', '부레옥잠', '마리모', '수생식물'],
    reasonLabel: '물과 친하고 둥글고 청초한 잎·수경재배 호환성',
    preferredIds: ['pilea-peperomioides', 'spathiphyllum-wallisii', 'epipremnum-aureum', 'monstera-deliciosa', 'hedera-helix', 'hydrangea-macrophylla'],
    categories: ['관엽식물', '꽃·관화식물'],
    traitRuleIds: ['env-hydro', 'app-round', 'theme-rain'],
  },
  {
    displayName: '파리지옥',
    aliases: ['파리지옥', '네펜데스', '끈끈이주걱', '벌레잡이식물', '식충식물', '사라세니아'],
    reasonLabel: '높은 공중습도와 개성 있고 신비로운 형태가 매력적인 특이 식물',
    preferredIds: ['tacca-chantrieri', 'alocasia-reginula', 'nephrolepis-exaltata', 'alocasia-frydek', 'opuntia-microdasys', 'aeonium-arboreum-zwartkop'],
    categories: ['관엽식물', '꽃·관화식물'],
    traitRuleIds: ['theme-unique', 'env-humidity'],
  },
  {
    displayName: '크로톤',
    aliases: ['크로톤', '콜레우스', '아칼리파', '드라세나마지나타', '마지나타', '유카', '소철'],
    reasonLabel: '화려한 잎 색감·무늬 또는 힘차게 뻗는 관엽 실루엣',
    preferredIds: ['dracaena-fragrans', 'calathea-makoyana', 'philodendron-birkin', 'aglaonema-commutatum', 'dieffenbachia', 'strelitzia-nicolai'],
    categories: ['관엽식물'],
    traitRuleIds: ['color-variegated', 'app-needle', 'app-tree', 'env-interior'],
  },
  {
    displayName: '오레가노',
    aliases: ['오레가노', '파슬리', '고수', '실란트로', '루꼴라', '딜', '세이지', '차이브', '마조람', '고추냉이', '허브'],
    reasonLabel: '요리와 차에 활용하기 좋은 상쾌한 주방·베란다 허브 특성',
    preferredIds: ['ocimum-basilicum', 'thymus-vulgaris', 'salvia-rosmarinus', 'mentha-piperita', 'mentha-suaveolens', 'melissa-officinalis'],
    categories: ['허브·방향식물'],
    traitRuleIds: ['scent-herb', 'env-culinary', 'theme-kitchen', 'env-sun'],
  },
];

const CURATED_SIMILAR_NEIGHBORS: Record<string, string[]> = {
  'monstera-deliciosa': ['philodendron-birkin', 'alocasia-frydek', 'epipremnum-aureum', 'strelitzia-nicolai', 'spathiphyllum-wallisii', 'ficus-lyrata'],
  'pilea-peperomioides': ['hoya-carnosa', 'crassula-ovata', 'epipremnum-aureum', 'goeppertia-orbifolia', 'eucalyptus-polyanthemos', 'mentha-suaveolens'],
  'goeppertia-orbifolia': ['calathea-makoyana', 'philodendron-birkin', 'aglaonema-commutatum', 'dieffenbachia', 'spathiphyllum-wallisii', 'alocasia-frydek'],
  'calathea-makoyana': ['goeppertia-orbifolia', 'aglaonema-commutatum', 'philodendron-birkin', 'dieffenbachia', 'alocasia-frydek', 'nephrolepis-exaltata'],
  'ficus-elastica': ['ficus-lyrata', 'ficus-benghalensis', 'zamioculcas-zamiifolia', 'zamioculcas-zamiifolia-raven', 'pachira-aquatica', 'olea-europaea'],
  'ficus-lyrata': ['ficus-elastica', 'ficus-benghalensis', 'strelitzia-nicolai', 'monstera-deliciosa', 'pachira-aquatica', 'alocasia-frydek'],
  'ficus-benghalensis': ['ficus-elastica', 'ficus-lyrata', 'pachira-aquatica', 'olea-europaea', 'dracaena-fragrans', 'zamioculcas-zamiifolia'],
  'strelitzia-nicolai': ['monstera-deliciosa', 'ficus-lyrata', 'dypsis-lutescens', 'alocasia-frydek', 'pachira-aquatica', 'chamaedorea-elegans'],
  'epipremnum-aureum': ['hedera-helix', 'hoya-carnosa', 'philodendron-birkin', 'monstera-deliciosa', 'spathiphyllum-wallisii', 'aglaonema-commutatum'],
  'spathiphyllum-wallisii': ['anthurium-andraeanum', 'phalaenopsis-orchid', 'philodendron-birkin', 'aglaonema-commutatum', 'epipremnum-aureum', 'gardenia-jasminoides'],
  'zamioculcas-zamiifolia': ['zamioculcas-zamiifolia-raven', 'dracaena-trifasciata-moonshine', 'dracaena-angolensis', 'ficus-elastica', 'crassula-ovata', 'pachira-aquatica'],
  'zamioculcas-zamiifolia-raven': ['zamioculcas-zamiifolia', 'alocasia-reginula', 'aeonium-arboreum-zwartkop', 'ophiopogon-planiscapus-nigrescens', 'dracaena-trifasciata-moonshine', 'ficus-elastica'],
  'dypsis-lutescens': ['chamaedorea-elegans', 'nephrolepis-exaltata', 'strelitzia-nicolai', 'dracaena-fragrans', 'pachira-aquatica', 'spathiphyllum-wallisii'],
  'chamaedorea-elegans': ['dypsis-lutescens', 'nephrolepis-exaltata', 'dracaena-fragrans', 'spathiphyllum-wallisii', 'epipremnum-aureum', 'pachira-aquatica'],
  'hoya-carnosa': ['epipremnum-aureum', 'hedera-helix', 'pilea-peperomioides', 'jasminum-sambac', 'crassula-ovata', 'phalaenopsis-orchid'],
  'pachira-aquatica': ['ficus-benghalensis', 'ficus-elastica', 'dracaena-fragrans', 'zamioculcas-zamiifolia', 'olea-europaea', 'dypsis-lutescens'],
  'dracaena-fragrans': ['dracaena-trifasciata-moonshine', 'dracaena-angolensis', 'pachira-aquatica', 'dypsis-lutescens', 'chamaedorea-elegans', 'dieffenbachia'],
  'nephrolepis-exaltata': ['chamaedorea-elegans', 'dypsis-lutescens', 'hedera-helix', 'epipremnum-aureum', 'calathea-makoyana', 'goeppertia-orbifolia'],
  'hedera-helix': ['epipremnum-aureum', 'hoya-carnosa', 'nephrolepis-exaltata', 'pilea-peperomioides', 'philodendron-birkin', 'spathiphyllum-wallisii'],
  'anthurium-andraeanum': ['spathiphyllum-wallisii', 'phalaenopsis-orchid', 'kalanchoe-blossfeldiana', 'camellia-japonica', 'philodendron-birkin', 'alocasia-frydek'],
  'aglaonema-commutatum': ['dieffenbachia', 'philodendron-birkin', 'calathea-makoyana', 'goeppertia-orbifolia', 'spathiphyllum-wallisii', 'epipremnum-aureum'],
  'philodendron-birkin': ['monstera-deliciosa', 'aglaonema-commutatum', 'dieffenbachia', 'goeppertia-orbifolia', 'alocasia-frydek', 'epipremnum-aureum'],
  'alocasia-frydek': ['alocasia-reginula', 'philodendron-birkin', 'monstera-deliciosa', 'calathea-makoyana', 'dieffenbachia', 'anthurium-andraeanum'],
  'alocasia-reginula': ['alocasia-frydek', 'zamioculcas-zamiifolia-raven', 'ophiopogon-planiscapus-nigrescens', 'aeonium-arboreum-zwartkop', 'tacca-chantrieri', 'philodendron-birkin'],
  'dieffenbachia': ['aglaonema-commutatum', 'philodendron-birkin', 'calathea-makoyana', 'goeppertia-orbifolia', 'monstera-deliciosa', 'dracaena-fragrans'],
  'olea-europaea': ['eucalyptus-polyanthemos', 'salvia-rosmarinus', 'ficus-benghalensis', 'citrus-japonica', 'cupressus-macrocarpa-goldcrest', 'lavandula-angustifolia'],
  'lavandula-angustifolia': ['salvia-rosmarinus', 'thymus-vulgaris', 'hyacinthus-orientalis', 'saintpaulia-ionantha', 'delphinium-elatum', 'matricaria-chamomilla'],
  'jasminum-sambac': ['murraya-paniculata', 'gardenia-jasminoides', 'osmanthus-fragrans', 'hoya-carnosa', 'spathiphyllum-wallisii', 'phalaenopsis-orchid'],
  'salvia-rosmarinus': ['lavandula-angustifolia', 'thymus-vulgaris', 'ocimum-basilicum', 'mentha-piperita', 'cupressus-macrocarpa-goldcrest', 'olea-europaea'],
  'ocimum-basilicum': ['mentha-suaveolens', 'mentha-piperita', 'melissa-officinalis', 'salvia-rosmarinus', 'thymus-vulgaris', 'matricaria-chamomilla'],
  'mentha-piperita': ['mentha-suaveolens', 'melissa-officinalis', 'ocimum-basilicum', 'salvia-rosmarinus', 'thymus-vulgaris', 'matricaria-chamomilla'],
  'mentha-suaveolens': ['mentha-piperita', 'melissa-officinalis', 'ocimum-basilicum', 'thymus-vulgaris', 'matricaria-chamomilla', 'salvia-rosmarinus'],
  'melissa-officinalis': ['mentha-suaveolens', 'mentha-piperita', 'ocimum-basilicum', 'cupressus-macrocarpa-goldcrest', 'matricaria-chamomilla', 'thymus-vulgaris'],
  'eucalyptus-polyanthemos': ['olea-europaea', 'dracaena-trifasciata-moonshine', 'cupressus-macrocarpa-goldcrest', 'salvia-rosmarinus', 'pilea-peperomioides', 'echeveria-laui'],
  'cupressus-macrocarpa-goldcrest': ['salvia-rosmarinus', 'eucalyptus-polyanthemos', 'melissa-officinalis', 'olea-europaea', 'thymus-vulgaris', 'dracaena-angolensis'],
  'murraya-paniculata': ['osmanthus-fragrans', 'gardenia-jasminoides', 'jasminum-sambac', 'citrus-japonica', 'hoya-carnosa', 'camellia-japonica'],
  'echeveria-laui': ['aeonium-arboreum-zwartkop', 'crassula-ovata', 'aloe-vera', 'dracaena-trifasciata-moonshine', 'opuntia-microdasys', 'dracaena-angolensis'],
  'dracaena-trifasciata-moonshine': ['dracaena-angolensis', 'zamioculcas-zamiifolia', 'aloe-vera', 'zamioculcas-zamiifolia-raven', 'crassula-ovata', 'eucalyptus-polyanthemos'],
  'dracaena-angolensis': ['dracaena-trifasciata-moonshine', 'zamioculcas-zamiifolia', 'aloe-vera', 'opuntia-microdasys', 'crassula-ovata', 'dracaena-fragrans'],
  'aloe-vera': ['dracaena-angolensis', 'dracaena-trifasciata-moonshine', 'echeveria-laui', 'opuntia-microdasys', 'crassula-ovata', 'zamioculcas-zamiifolia'],
  'crassula-ovata': ['echeveria-laui', 'aeonium-arboreum-zwartkop', 'aloe-vera', 'zamioculcas-zamiifolia', 'kalanchoe-blossfeldiana', 'pilea-peperomioides'],
  'opuntia-microdasys': ['aloe-vera', 'echeveria-laui', 'dracaena-angolensis', 'crassula-ovata', 'aeonium-arboreum-zwartkop', 'dracaena-trifasciata-moonshine'],
  'aeonium-arboreum-zwartkop': ['echeveria-laui', 'crassula-ovata', 'zamioculcas-zamiifolia-raven', 'alocasia-reginula', 'ophiopogon-planiscapus-nigrescens', 'aloe-vera'],
  'camellia-japonica': ['paeonia-lactiflora', 'gardenia-jasminoides', 'rosa-miniature', 'osmanthus-fragrans', 'anthurium-andraeanum', 'citrus-japonica'],
  'osmanthus-fragrans': ['murraya-paniculata', 'gardenia-jasminoides', 'jasminum-sambac', 'camellia-japonica', 'citrus-japonica', 'freesia-refracta'],
  'gardenia-jasminoides': ['jasminum-sambac', 'murraya-paniculata', 'osmanthus-fragrans', 'camellia-japonica', 'spathiphyllum-wallisii', 'phalaenopsis-orchid'],
  'pelargonium-hortorum': ['rosa-miniature', 'kalanchoe-blossfeldiana', 'paeonia-lactiflora', 'hydrangea-macrophylla', 'saintpaulia-ionantha', 'mentha-suaveolens'],
  'hydrangea-macrophylla': ['plumbago-auriculata', 'nemophila-menziesii', 'myosotis-sylvatica', 'paeonia-lactiflora', 'delphinium-elatum', 'kalanchoe-blossfeldiana'],
  'phalaenopsis-orchid': ['spathiphyllum-wallisii', 'anthurium-andraeanum', 'saintpaulia-ionantha', 'hyacinthus-orientalis', 'jasminum-sambac', 'gardenia-jasminoides'],
  'rosa-miniature': ['paeonia-lactiflora', 'camellia-japonica', 'pelargonium-hortorum', 'kalanchoe-blossfeldiana', 'gardenia-jasminoides', 'tulipa-gesneriana'],
  'paeonia-lactiflora': ['rosa-miniature', 'camellia-japonica', 'tulipa-gesneriana', 'hydrangea-macrophylla', 'hyacinthus-orientalis', 'pelargonium-hortorum'],
  'hyacinthus-orientalis': ['tulipa-gesneriana', 'freesia-refracta', 'lavandula-angustifolia', 'delphinium-elatum', 'saintpaulia-ionantha', 'jasminum-sambac'],
  'freesia-refracta': ['hyacinthus-orientalis', 'tulipa-gesneriana', 'helianthus-annuus', 'matricaria-chamomilla', 'kalanchoe-blossfeldiana', 'osmanthus-fragrans'],
  'kalanchoe-blossfeldiana': ['pelargonium-hortorum', 'saintpaulia-ionantha', 'rosa-miniature', 'crassula-ovata', 'anthurium-andraeanum', 'tulipa-gesneriana'],
  'saintpaulia-ionantha': ['lavandula-angustifolia', 'hyacinthus-orientalis', 'kalanchoe-blossfeldiana', 'phalaenopsis-orchid', 'myosotis-sylvatica', 'nemophila-menziesii'],
  'tulipa-gesneriana': ['hyacinthus-orientalis', 'freesia-refracta', 'paeonia-lactiflora', 'rosa-miniature', 'kalanchoe-blossfeldiana', 'camellia-japonica'],
  'thymus-vulgaris': ['salvia-rosmarinus', 'lavandula-angustifolia', 'ocimum-basilicum', 'mentha-piperita', 'mentha-suaveolens', 'matricaria-chamomilla'],
  'matricaria-chamomilla': ['melissa-officinalis', 'mentha-suaveolens', 'ocimum-basilicum', 'freesia-refracta', 'helianthus-annuus', 'nemophila-menziesii'],
  'helianthus-annuus': ['freesia-refracta', 'matricaria-chamomilla', 'kalanchoe-blossfeldiana', 'citrus-japonica', 'tulipa-gesneriana', 'pelargonium-hortorum'],
  'citrus-japonica': ['murraya-paniculata', 'osmanthus-fragrans', 'camellia-japonica', 'gardenia-jasminoides', 'olea-europaea', 'helianthus-annuus'],
  'nemophila-menziesii': ['myosotis-sylvatica', 'plumbago-auriculata', 'delphinium-elatum', 'hydrangea-macrophylla', 'saintpaulia-ionantha', 'matricaria-chamomilla'],
  'myosotis-sylvatica': ['nemophila-menziesii', 'plumbago-auriculata', 'delphinium-elatum', 'hydrangea-macrophylla', 'saintpaulia-ionantha', 'hyacinthus-orientalis'],
  'plumbago-auriculata': ['hydrangea-macrophylla', 'nemophila-menziesii', 'myosotis-sylvatica', 'delphinium-elatum', 'jasminum-sambac', 'gardenia-jasminoides'],
  'delphinium-elatum': ['hydrangea-macrophylla', 'plumbago-auriculata', 'myosotis-sylvatica', 'nemophila-menziesii', 'hyacinthus-orientalis', 'lavandula-angustifolia'],
  'tacca-chantrieri': ['alocasia-reginula', 'aeonium-arboreum-zwartkop', 'ophiopogon-planiscapus-nigrescens', 'zamioculcas-zamiifolia-raven', 'phalaenopsis-orchid', 'anthurium-andraeanum'],
  'ophiopogon-planiscapus-nigrescens': ['zamioculcas-zamiifolia-raven', 'alocasia-reginula', 'aeonium-arboreum-zwartkop', 'tacca-chantrieri', 'dracaena-angolensis', 'dracaena-trifasciata-moonshine'],
};

function cleanPlantQueryPhrase(description: string): string {
  return description
    .trim()
    .replace(/(비슷한|닮은|같은|느낌의|종류의|식물|추천|찾아줘|알려줘|해줘|처럼)/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function findExternalPlantProfile(
  description: string
): ExternalPlantSimilarityProfile | null {
  const raw = description.trim();
  if (!raw) return null;

  const cleaned = cleanPlantQueryPhrase(raw);
  const candidates = [
    cleaned,
    stripKoreanParticles(cleaned),
    ...raw
      .split(/[\s,·/:]+/)
      .map((w) => stripKoreanParticles(w.trim()))
      .filter((w) => w.length >= 2),
  ]
    .map((c) => normalizePlantText(c))
    .filter((c) => c.length >= 2);

  let bestMatch: { profile: ExternalPlantSimilarityProfile; len: number } | null = null;
  for (const profile of EXTERNAL_PLANT_SIMILARITY_PROFILES) {
    for (const alias of profile.aliases) {
      const normAlias = normalizePlantText(alias);
      if (normAlias.length < 2) continue;
      for (const cand of candidates) {
        if (cand === normAlias || (cand.length >= 3 && cand.includes(normAlias))) {
          if (!bestMatch || normAlias.length > bestMatch.len) {
            bestMatch = { profile, len: normAlias.length };
          }
        }
      }
    }
  }

  return bestMatch?.profile ?? null;
}

function findReferencedPlant(
  description: string
): { plant: PlantProfile; isGenericGroup: boolean } | null {
  const raw = description.trim();
  if (!raw) return null;

  const cleaned = cleanPlantQueryPhrase(raw);
  if (!cleaned || cleaned.length < 2) return null;

  const normalized = normalizePlantText(stripKoreanParticles(cleaned));
  const aliased = NAME_ALIASES[normalized];
  const targetNorm = aliased ? normalizePlantText(aliased) : normalized;
  const isGenericGroup = NON_EXCLUSIVE_GROUP_WORDS.has(normalized);

  // 1. Exact or alias match on the cleaned reference
  for (const plant of TRAIT_RECOMMENDATION_CATALOG) {
    const koNorm = normalizePlantText(plant.nameKo);
    const enNorm = normalizePlantText(plant.nameEn);
    const sciNorm = normalizePlantText(plant.scientificName);
    if (
      koNorm === targetNorm ||
      enNorm === targetNorm ||
      sciNorm === targetNorm
    ) {
      return { plant, isGenericGroup };
    }
  }

  // 2. Word-boundary plant reference inside sentence (e.g. "라벤더처럼 보라색 꽃", "알보 몬스테라")
  const words = raw
    .split(/[\s,·/:]+/)
    .map((w) => stripKoreanParticles(w.trim()))
    .filter((w) => w.length >= 2);
  for (const word of words) {
    const wordNorm = normalizePlantText(word);
    const wordAlias = NAME_ALIASES[wordNorm];
    const resolved = wordAlias ? normalizePlantText(wordAlias) : wordNorm;
    if (resolved.length < 2) continue;
    for (const plant of TRAIT_RECOMMENDATION_CATALOG) {
      const koNorm = normalizePlantText(plant.nameKo);
      if (koNorm === resolved) {
        return {
          plant,
          isGenericGroup: NON_EXCLUSIVE_GROUP_WORDS.has(wordNorm),
        };
      }
    }
  }

  // 3. Substring match on plant names/aliases when user enters a cultivar/compound plant name
  if (normalized.length >= 3) {
    let bestSub: { plant: PlantProfile; score: number } | null = null;
    for (const [alias, target] of Object.entries(NAME_ALIASES)) {
      const aliasNorm = normalizePlantText(alias);
      if (aliasNorm.length >= 2 && normalized.includes(aliasNorm)) {
        const targetPlant = TRAIT_RECOMMENDATION_CATALOG.find(
          (p) => normalizePlantText(p.nameKo) === normalizePlantText(target)
        );
        if (targetPlant && (!bestSub || aliasNorm.length > bestSub.score)) {
          bestSub = { plant: targetPlant, score: aliasNorm.length };
        }
      }
    }
    if (bestSub) {
      return { plant: bestSub.plant, isGenericGroup: false };
    }

    for (const plant of TRAIT_RECOMMENDATION_CATALOG) {
      const koNorm = normalizePlantText(plant.nameKo);
      if (koNorm.length >= 3 && (koNorm.includes(normalized) || normalized.includes(koNorm))) {
        return { plant, isGenericGroup: false };
      }
    }
  }

  return null;
}

export function detectPlantNameReference(description: string): string | null {
  const catalogRef = findReferencedPlant(description);
  if (catalogRef && !catalogRef.isGenericGroup) {
    return catalogRef.plant.nameKo.replace(/\s*\([^)]*\)/g, '').trim();
  }
  const externalRef = findExternalPlantProfile(description);
  if (externalRef) {
    return externalRef.displayName;
  }
  return null;
}

function getNormalizedFamily(family: string): string {
  return family.split('(')[0].trim();
}

function getScientificGenus(scientificName: string): string {
  return scientificName.trim().split(/\s+/)[0]?.toLowerCase() ?? '';
}

function scorePlantSimilarity(
  ref: PlantProfile,
  candidate: PlantProfile,
  refMatchedRules: TraitRule[]
): { score: number; similarityReasons: string[] } {
  let score = 0;
  const similarityReasons: string[] = [];

  const curatedList = CURATED_SIMILAR_NEIGHBORS[ref.id];
  if (curatedList) {
    const idx = curatedList.indexOf(candidate.id);
    if (idx !== -1) {
      score += 18 - idx * 2;
      similarityReasons.push('특성·분위기 대표 유사종');
    }
  }

  const refGenus = getScientificGenus(ref.scientificName);
  const candGenus = getScientificGenus(candidate.scientificName);
  if (refGenus && refGenus === candGenus) {
    score += 14;
    similarityReasons.push(`같은 ${refGenus} 속(근연종)`);
  }

  const refFamily = getNormalizedFamily(ref.family);
  const candFamily = getNormalizedFamily(candidate.family);
  if (refFamily && refFamily === candFamily) {
    score += 9;
    if (!similarityReasons.some((r) => r.includes('근연종'))) {
      similarityReasons.push(`같은 ${refFamily} 계열`);
    }
  }

  if (candidate.category === ref.category) {
    score += 7;
    similarityReasons.push(`${candidate.category} 분류 일치`);
  }

  const refFlowering = isFloweringPlant(ref);
  const candFlowering = isFloweringPlant(candidate);
  if (refFlowering === candFlowering) {
    score += refFlowering ? 5 : 3;
  } else if (!refFlowering && candFlowering) {
    score -= 4;
  }

  const refHasScent = ref.characteristics.scentIntensity !== '거의 없음';
  const candHasScent = candidate.characteristics.scentIntensity !== '거의 없음';
  if (refHasScent && candHasScent) {
    score += 5;
  } else if (!refHasScent && !candHasScent) {
    score += 2;
  }

  for (const rule of refMatchedRules) {
    if (!rule.match(candidate)) continue;
    if (rule.group === 'appearance') {
      score += 5;
      if (similarityReasons.length < 4) similarityReasons.push(rule.label);
    } else if (rule.group === 'scent') {
      score += 5;
      if (similarityReasons.length < 4) similarityReasons.push(rule.label);
    } else if (rule.group === 'color') {
      score += 4;
      if (similarityReasons.length < 4) similarityReasons.push(rule.label);
    } else if (rule.group === 'env') {
      score += 3;
      if (similarityReasons.length < 4) similarityReasons.push(rule.label);
    }
  }

  if (candidate.difficulty === ref.difficulty) {
    score += 2;
  }

  const seasons: PlantSeason[] = ['봄', '여름', '가을', '겨울'];
  for (const s of seasons) {
    if (
      ref.characteristics.bloomingSeason.includes(s) &&
      candidate.characteristics.bloomingSeason.includes(s)
    ) {
      score += 2;
      break;
    }
  }

  return { score, similarityReasons };
}

const GENERIC_STOP_TOKENS = new Set([
  '식물',
  '계절:',
  '추천',
  '찾아',
  '나는',
  '있는',
  '없는',
  '좋은',
  '비슷한',
  '같은',
  '느낌',
  '원하는',
  '취향',
  '키우기',
  '키우는',
  '어울리는',
  '해주세요',
  '해줘',
  '알려줘',
  '꽃',
  '잎',
  '향',
  '향기',
  '냄새',
  '색',
  '색깔',
  '색상',
  '실내',
  '물',
  '빛',
  '햇빛',
  '나무',
  '예쁜',
  '피는',
  '적은',
  '많은',
  '자주',
  '가끔',
  '집',
  '방',
  '거실',
  '분위기',
  '보라',
  '보라색',
  '퍼플',
  '연보라',
  '빨간',
  '빨간색',
  '빨강',
  '붉은',
  '붉은색',
  '레드',
  '파란',
  '파란색',
  '파랑',
  '하늘색',
  '하늘빛',
  '하늘',
  '스카이블루',
  '푸른',
  '블루',
  '검은',
  '검은색',
  '검정',
  '검정색',
  '블랙',
  '흑색',
  '까만',
  '까망',
  '노란',
  '노란색',
  '노랑',
  '옐로우',
  '주황',
  '주황색',
  '하얀',
  '하얀색',
  '하양',
  '흰',
  '흰색',
  '백색',
  '순백',
  '순백색',
  '화이트',
  '분홍',
  '분홍색',
  '핑크',
  '초록',
  '초록색',
  '연두',
  '연두색',
  '은청색',
  '은빛',
  '큰',
  '작은',
  '뚫리고',
  '시원하게',
  '늘어지는',
  '동그란',
  '둥근',
]);

export function recommendFromCatalog(
  description: string,
  traits: {
    appearance?: string;
    color?: string;
    scent?: string;
    environment?: string;
    season?: string;
  }
): RecommendationResponse {
  const activeSeason = detectSeasonFromInput(traits.season, description);

  const combinedText = [
    activeSeason ? `계절: ${activeSeason}` : '',
    description,
    traits.appearance,
    traits.color,
    traits.scent,
    traits.environment,
  ]
    .filter(Boolean)
    .join(' ')
    .trim();

  const lowerCombined = combinedText.toLowerCase();
  const compactCombined = lowerCombined.replace(/\s+/g, '');
  const splitWords = lowerCombined
    .split(/[\s,·/:]+/)
    .map((t) => t.trim())
    .filter(Boolean);
  const allWordTokens = Array.from(
    new Set(
      splitWords.flatMap((t) => {
        const stripped = stripKoreanParticles(t);
        return stripped && stripped !== t ? [t, stripped] : [t];
      })
    )
  );
  const tokens = allWordTokens.filter(
    (t) => t.length >= 2 && !GENERIC_STOP_TOKENS.has(t)
  );

  const directPlantRef = findReferencedPlant(description);
  const directPlantMatch = directPlantRef?.plant ?? null;
  const excludeMatchedPlant = Boolean(directPlantRef && !directPlantRef.isGenericGroup);
  const externalPlantMatch = !directPlantMatch
    ? findExternalPlantProfile(description)
    : null;

  const refMatchedRules = directPlantMatch
    ? TRAIT_RULES.filter(
        (rule) =>
          (rule.group === 'color' ||
            rule.group === 'scent' ||
            rule.group === 'appearance' ||
            rule.group === 'env') &&
          rule.match(directPlantMatch)
      )
    : [];

  const triggeredRules = TRAIT_RULES.filter((rule) => {
    if (rule.shouldTrigger && !rule.shouldTrigger(lowerCombined, compactCombined)) {
      return false;
    }
    const matchesKeyword = rule.keywords.some(
      (kw) =>
        lowerCombined.includes(kw) ||
        compactCombined.includes(kw.replace(/\s+/g, ''))
    );
    const matchesExactToken = Boolean(
      rule.exactTokens?.some((tok) => allWordTokens.includes(tok))
    );
    return matchesKeyword || matchesExactToken;
  });

  const flowerColorIds = new Set([
    'color-white',
    'color-red',
    'color-purple',
    'color-skyblue',
    'color-blue',
    'color-yellow',
    'color-pink',
  ]);
  const specificColorRules = triggeredRules.filter(
    (r) => r.group === 'color' && r.id !== 'color-green'
  );
  const specificColorTriggered = specificColorRules.length > 0;
  const flowerColorTriggered = specificColorRules.some((r) =>
    flowerColorIds.has(r.id)
  );
  const foliageQualifierPresent =
    /(잎|무늬|줄무늬|관엽|다육|선인장|수형)/.test(compactCombined);
  const implicitFlowerFromColor = flowerColorTriggered && !foliageQualifierPresent;
  const flowerTriggered = triggeredRules.some((r) => r.id === 'app-flower');
  const scentNoneTriggered = triggeredRules.some((r) => r.id === 'scent-none');
  const scentWantedTriggered = triggeredRules.some(
    (r) => r.group === 'scent' && r.id !== 'scent-none'
  );
  const strictConstraintRules = triggeredRules.filter((r) =>
    [
      'app-fenestrated',
      'app-vine',
      'app-spiky',
      'app-fruit',
      'app-fuzzy',
      'app-round',
      'app-needle',
      'app-succulent',
      'env-hydro',
      'env-pet',
    ].includes(r.id)
  );

  const queryBigrams = description.trim()
    ? extractKoreanBigrams(description)
    : [];

  const candidatePool = excludeMatchedPlant && directPlantMatch
    ? TRAIT_RECOMMENDATION_CATALOG.filter((p) => p.id !== directPlantMatch.id)
    : TRAIT_RECOMMENDATION_CATALOG;

  const scored = candidatePool.map((plant) => {
    let score = 0;
    const matchedLabels: string[] = [];
    let matchedRuleCount = 0;
    let matchedSpecificColor = false;
    let matchedFlower = false;

    if (directPlantMatch) {
      if (directPlantMatch.id === plant.id) {
        score += 55;
        matchedLabels.push(`${plant.category} 대표 식물`);
      } else {
        const sim = scorePlantSimilarity(directPlantMatch, plant, refMatchedRules);
        score += sim.score;
        for (const r of sim.similarityReasons) {
          if (!matchedLabels.includes(r)) {
            matchedLabels.push(r);
          }
        }
      }
    } else if (externalPlantMatch) {
      const prefIdx = externalPlantMatch.preferredIds.indexOf(plant.id);
      if (prefIdx !== -1) {
        score += 20 - prefIdx * 2;
        matchedLabels.push(externalPlantMatch.reasonLabel);
      }
      if (externalPlantMatch.categories.includes(plant.category)) {
        score += 6;
        if (!matchedLabels.includes(`${plant.category} 계열`)) {
          matchedLabels.push(`${plant.category} 계열`);
        }
      }
      for (const ruleId of externalPlantMatch.traitRuleIds) {
        const rule = TRAIT_RULES.find((r) => r.id === ruleId);
        if (rule && rule.match(plant)) {
          score += 4;
          if (!matchedLabels.includes(rule.label)) {
            matchedLabels.push(rule.label);
          }
        }
      }
    }

    // Prioritize plants matching the selected season
    if (activeSeason) {
      const profile = SEASON_PROFILES[activeSeason];
      if (profile.peakIds.includes(plant.id)) {
        score += 9;
        matchedLabels.push(profile.label);
      } else if (profile.goodIds.includes(plant.id)) {
        score += 4;
        matchedLabels.push(`${activeSeason}철 생육 적합`);
      } else if (profile.avoidIds.includes(plant.id)) {
        score -= 4;
      } else if (
        plant.characteristics.bloomingSeason.includes(activeSeason) ||
        plant.characteristics.bloomingSeason.includes('사계절') ||
        plant.characteristics.bloomingSeason.includes('연중')
      ) {
        score += 5;
        matchedLabels.push(`${activeSeason}철 개화 · 감상 적합`);
      }
    }

    const matchedRuleIds = new Set<string>();
    for (const rule of triggeredRules) {
      if (rule.match(plant)) {
        score += rule.weight;
        matchedRuleCount += 1;
        matchedRuleIds.add(rule.id);
        if (rule.group === 'color' && rule.id !== 'color-green') {
          matchedSpecificColor = true;
        }
        if (rule.id === 'app-flower') {
          matchedFlower = true;
        }
        if (!matchedLabels.includes(rule.label)) {
          matchedLabels.push(rule.label);
        }
      }
    }

    // Reward multi-constraint coverage so plants satisfying ALL searched traits always win
    if (triggeredRules.length >= 2 && matchedRuleCount > 0) {
      score += matchedRuleCount * 7;
      if (matchedRuleCount === triggeredRules.length) {
        score += 12;
      }
    }

    // Enforce core characteristic constraints so contrasting plants never pollute results
    if (specificColorTriggered && (flowerTriggered || implicitFlowerFromColor)) {
      const blooms = matchedFlower || isFloweringPlant(plant);
      if (matchedSpecificColor && blooms) {
        score += 14;
        const primaryLead = plant.characteristics.colorDescription.slice(0, 9);
        const primaryMatch = specificColorRules.some((r) =>
          r.match({
            ...plant,
            characteristics: {
              ...plant.characteristics,
              colorDescription: primaryLead,
            },
          })
        );
        if (primaryMatch) {
          score += 8;
        }
      } else {
        score -= 15;
      }
    } else if (specificColorTriggered && !matchedSpecificColor) {
      score -= 12;
    } else if (specificColorTriggered && matchedSpecificColor) {
      const primaryLead = plant.characteristics.colorDescription.slice(0, 15);
      const primaryMatch = specificColorRules.some((r) =>
        r.match({
          ...plant,
          characteristics: {
            ...plant.characteristics,
            colorDescription: primaryLead,
          },
        })
      );
      if (primaryMatch) {
        score += 6;
      }
    }

    if (scentNoneTriggered && plant.characteristics.scentIntensity !== '거의 없음') {
      score -= 15;
    }
    if (scentWantedTriggered && plant.characteristics.scentIntensity === '거의 없음') {
      score -= 10;
    }
    for (const strictRule of strictConstraintRules) {
      if (!matchedRuleIds.has(strictRule.id)) {
        score -= 10;
      }
    }

    // Specific non-stopword keyword overlap boost
    const fullHaystack = [
      plant.nameKo,
      plant.nameEn,
      plant.category,
      plant.summary,
      plant.characteristics.appearance,
      plant.characteristics.colorDescription,
      plant.characteristics.scent,
      plant.characteristics.bloomingSeason,
      plant.characteristics.sizeAndGrowth,
      plant.careGuide.sunlight,
      plant.careGuide.watering,
      plant.funFact,
    ]
      .join(' ')
      .toLowerCase();

    for (const token of tokens) {
      if (fullHaystack.includes(token)) {
        score += 4;
      }
    }

    // Soft Korean 2-gram tie-breaker
    let bigramHits = 0;
    if (queryBigrams.length > 0) {
      const compactHaystack = fullHaystack.replace(/\s+/g, '');
      for (const bg of queryBigrams) {
        if (
          bg === '식물' ||
          bg === '추천' ||
          bg === '같은' ||
          bg === '좋은' ||
          bg === '있는' ||
          bg === '나는' ||
          bg === '피는' ||
          bg === '색이'
        ) {
          continue;
        }
        if (compactHaystack.includes(bg)) {
          bigramHits += 1;
        }
      }
    }

    return { plant, score, matchedRuleCount, bigramHits, matchedLabels };
  });

  scored.sort(
    (a, b) =>
      b.score - a.score ||
      b.matchedRuleCount - a.matchedRuleCount ||
      b.bigramHits - a.bigramHits
  );

  let selected = scored.filter((item) => item.score > 0).slice(0, 6);
  let usedSimilarityFallback = false;

  if (selected.length === 0) {
    usedSimilarityFallback = true;
    const seasonPool = activeSeason
      ? SEASON_PROFILES[activeSeason].peakIds
      : [];
    const cleanInput = compactCombined.replace(/[^가-힣a-z0-9]/gi, '');
    let seedHash = 0;
    for (let i = 0; i < cleanInput.length; i++) {
      seedHash = (seedHash * 31 + cleanInput.charCodeAt(i)) >>> 0;
    }

    const fallbackSorted = [...scored].sort((a, b) => {
      const aSeason = seasonPool.includes(a.plant.id) ? 1 : 0;
      const bSeason = seasonPool.includes(b.plant.id) ? 1 : 0;
      if (b.bigramHits !== a.bigramHits) return b.bigramHits - a.bigramHits;
      if (bSeason !== aSeason) return bSeason - aSeason;

      const aSingleHits = allWordTokens.filter(
        (tok) =>
          tok.length >= 1 &&
          `${a.plant.nameKo}${a.plant.summary}${a.plant.characteristics.colorDescription}${a.plant.characteristics.appearance}`
            .toLowerCase()
            .includes(tok)
      ).length;
      const bSingleHits = allWordTokens.filter(
        (tok) =>
          tok.length >= 1 &&
          `${b.plant.nameKo}${b.plant.summary}${b.plant.characteristics.colorDescription}${b.plant.characteristics.appearance}`
            .toLowerCase()
            .includes(tok)
      ).length;
      if (bSingleHits !== aSingleHits) return bSingleHits - aSingleHits;

      const aHash =
        ((a.plant.id.charCodeAt(0) * 17 +
          a.plant.id.length * 13 +
          seedHash) %
          23) +
        (a.plant.difficulty === '초보자 추천' ? 6 : 0);
      const bHash =
        ((b.plant.id.charCodeAt(0) * 17 +
          b.plant.id.length * 13 +
          seedHash) %
          23) +
        (b.plant.difficulty === '초보자 추천' ? 6 : 0);
      return bHash - aHash;
    });
    selected = fallbackSorted.slice(0, 6);
  }

  const trimmedKeyword = description.trim();
  const refPlantLabel =
    directPlantMatch && excludeMatchedPlant
      ? directPlantMatch.nameKo.replace(/\s*\([^)]*\)/g, '').trim()
      : externalPlantMatch?.displayName ?? null;

  const recommendations: PlantRecommendation[] = selected.map(
    ({ plant, matchedLabels }) => {
      const reasonText = refPlantLabel
        ? `‘${refPlantLabel}’와 비슷한 식물입니다.${matchedLabels.length > 0 ? ` (${matchedLabels.slice(0, 3).join(' · ')})` : ''} ${plant.summary}`
        : matchedLabels.length > 0
          ? `요청하신 조건(${matchedLabels.slice(0, 3).join(', ')})과 잘 어울리는 식물입니다. ${plant.summary}`
          : usedSimilarityFallback && trimmedKeyword
            ? `입력하신 ‘${trimmedKeyword}’ 키워드의 분위기와 감성에 맞춰 추천드리는 식물입니다. ${plant.summary}`
            : usedSimilarityFallback
              ? `검색하신 취향과 분위기·특성이 비슷해 함께 추천드리는 식물입니다. ${plant.summary}`
              : plant.summary;

      return {
        nameKo: plant.nameKo,
        nameEn: plant.nameEn,
        scientificName: plant.scientificName,
        category: plant.category,
        difficulty: plant.difficulty,
        matchReason: reasonText,
        appearanceSummary: plant.characteristics.appearance,
        colorDescription: plant.characteristics.colorDescription,
        colorHexes: plant.characteristics.colorPalette,
        scentSummary: `${plant.characteristics.scentIntensity} · ${plant.characteristics.scent}`,
        quickCareTip: `${plant.careGuide.wateringCycle}`,
        imageUrl: plant.imageUrl,
      };
    }
  );

  return {
    querySummary: refPlantLabel
      ? `‘${refPlantLabel}’와 비슷한 식물`
      : combinedText || '맞춤 식물 추천',
    recommendations,
    sources: [],
    notice: refPlantLabel
      ? `입력하신 ‘${refPlantLabel}’와 생김새·색감·향기·생육 특성이 비슷한 식물 ${recommendations.length}종을 찾았습니다. 더 많은 실존 식물을 찾으려면 오른쪽 “구글 웹에서 추가 식물 더 찾기”를 눌러보세요.`
      : usedSimilarityFallback
        ? `입력하신 ‘${trimmedKeyword || combinedText}’ 키워드와 분위기·특성이 가장 잘 어울리는 식물을 골라 추천했습니다. 더 많은 실존 식물을 찾으려면 오른쪽 “구글 웹에서 추가 식물 더 찾기”를 눌러보세요.`
        : undefined,
  };
}
