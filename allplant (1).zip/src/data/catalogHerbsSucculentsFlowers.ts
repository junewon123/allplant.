import type { PlantProfile } from '../types/plant';

const IMG_HERB = '/src/assets/images/cat_fragrant_lavender_1795403759069.jpg';
const IMG_SUCCULENT = '/src/assets/images/cat_succulent_echeveria_1795403759080.jpg';
const IMG_FLOWER = '/src/assets/images/cat_flowering_camellia_1795403759985.jpg';

export const HERBS_SUCCULENTS_FLOWERS: PlantProfile[] = [
  {
    id: 'lavandula-angustifolia',
    nameKo: '잉글리시 라벤더',
    nameEn: 'English Lavender',
    scientificName: 'Lavandula angustifolia',
    family: '꿀풀과 (Lamiaceae)',
    category: '허브·방향식물',
    origin: '지중해 연안 · 남프랑스 고지대',
    difficulty: '보통',
    summary:
      '은빛이 감도는 가느다란 잎과 보라색 이삭 꽃이 피며, 진정 효과를 주는 깊고 청량한 허브 아로마를 품고 있습니다.',
    imageUrl: IMG_HERB,
    characteristics: {
      appearance:
        '좁고 길쭉한 회녹색 잎이 줄기를 따라 촘촘히 나며, 긴 꽃대 끝에 작은 보라색 꽃들이 이삭 형태로 모여 핍니다.',
      colorPalette: ['#6D28D9', '#8B5CF6', '#94A39B'],
      colorDescription: '선명한 바이올렛·라벤더 보라색 꽃과 은청빛 회녹색 잎',
      scent: '꽃과 잎을 스치기만 해도 달콤하면서도 상쾌한 클래식 허브 아로마 향이 퍼집니다.',
      scentIntensity: '강함 (꽃봉오리에 정유 성분이 가장 농축되어 있음)',
      sizeAndGrowth: '키 40~80cm의 반관목형 허브',
      bloomingSeason: '늦봄~초여름(5~7월) 집중 개화',
      petSafety: '소량의 리날롤 성분이 있어 반려동물이 다량 섭취하지 않도록 주의합니다.',
    },
    careGuide: {
      watering:
        '과습에 매우 취약합니다. 겉흙이 완전히 바싹 마른 뒤 한 번에 흠뻑 주세요. 장마철 비 맞힘을 피합니다.',
      wateringCycle: '봄~가을 4~7일 간격(완전 건조 후) · 겨울 10~14일 간격',
      sunlight: '하루 6시간 이상의 직사광선과 원활한 통풍이 필수입니다.',
      temperature: '15~25°C 선호 · 내한성이 강한 편이라 노지 월동(-10°C 내외) 가능',
      humidity: '30~50%의 건조하고 바람이 잘 통하는 환경을 좋아합니다.',
      soil: '물빠짐이 빠른 사질토(상토 4 : 마사토·펄라이트 6)가 이상적입니다.',
      fertilizer: '척박한 땅에서도 잘 자라므로 봄에 소량의 완효성 비료만 줍니다.',
      pruningAndRepotting:
        '꽃이 진 직후 꽃대와 줄기의 1/3을 다듬어 주면 다음 해 새순이 풍성해집니다.',
      commonIssues:
        '통풍 불량과 과습이 겹치면 뿌리썩음병이 오므로 통기성 좋은 토분을 권장합니다.',
    },
    funFact:
      '라틴어 "Lavare(씻다)"에서 유래했으며, 고대 로마 시대부터 목욕물과 방향제, 심신 안정 허브로 사랑받았습니다.',
  },
  {
    id: 'jasminum-sambac',
    nameKo: '아라비안 자스민 (말리화)',
    nameEn: 'Arabian Jasmine',
    scientificName: 'Jasminum sambac',
    family: '물푸레나무과 (Oleaceae)',
    category: '허브·방향식물',
    origin: '인도 · 동남아시아 열대 지역',
    difficulty: '보통',
    summary:
      '밤이 되면 순백색 별 모양 꽃을 활짝 열어 방 안을 가득 채울 만큼 관능적이고 달콤한 꽃향기를 내뿜습니다.',
    imageUrl: IMG_HERB,
    characteristics: {
      appearance:
        '윤기 나는 타원형 초록 잎이 마주나며, 반덩굴성 가지 끝마다 작은 하얀 꽃송이가 송이송이 달립니다.',
      colorPalette: ['#FAF8F5', '#D4D4C8', '#1E4620'],
      colorDescription: '맑은 순백색~아이보리 꽃잎과 짙은 포레스트 그린 잎',
      scent: '자스민차의 원료로 쓰이는 깊고 달콤한 플로럴 향으로 저녁~밤에 향기가 절정에 달합니다.',
      scentIntensity: '강함 (야간 방향성)',
      sizeAndGrowth: '화분 재배 시 60~150cm, 반덩굴 형태',
      bloomingSeason: '늦봄~초가을(5~9월) 햇빛이 충분하면 반복 개화',
      petSafety: '아라비안 자스민은 반려동물에게 독성이 없는 안전한 종으로 분류됩니다.',
    },
    careGuide: {
      watering:
        '물을 좋아하는 편이므로 겉흙이 마르기 시작하면 즉시 흠뻑 줍니다.',
      wateringCycle: '봄~여름 2~4일에 1회 · 겨울 주 1회',
      sunlight: '하루 4~6시간 이상의 충분한 햇빛(남향·동향 창가)이 필요합니다.',
      temperature: '18~28°C 선호 · 겨울철 10°C 이상 실내 유지',
      humidity: '50~65% 선호 · 건조한 계절엔 잎에 자주 분무해 줍니다.',
      soil: '보수력과 배수력이 균형 잡힌 약산성 배합토(상토 6 : 펄라이트 2 : 마사토 2)를 씁니다.',
      fertilizer: '개화기(봄~여름) 동안 2주에 1회 개화용 액비를 줍니다.',
      pruningAndRepotting:
        '꽃이 진 가지는 2~3마디 아래를 잘라주면 새 가지가 나오며 다시 꽃눈을 맺습니다.',
      commonIssues:
        '실내 건조 시 잎 뒷면에 응애가 잘 생기므로 통풍과 주기적인 잎 세척이 중요합니다.',
    },
    funFact:
      '말린 꽃봉오리는 동양의 전통 자스민 녹차 블렌딩의 핵심 재료로 사용됩니다.',
  },
  {
    id: 'salvia-rosmarinus',
    nameKo: '로즈마리',
    nameEn: 'Rosemary',
    scientificName: 'Salvia rosmarinus',
    family: '꿀풀과 (Lamiaceae)',
    category: '허브·방향식물',
    origin: '지중해 연안 해안가 절벽',
    difficulty: '보통',
    summary:
      '소나무 바늘을 닮은 잎에서 머리를 맑게 해주는 상쾌한 숲과 시트러스, 캄퍼 향이 진하게 배어 나오는 대표 허브입니다.',
    imageUrl: IMG_HERB,
    characteristics: {
      appearance:
        '단단한 목질 줄기에 좁고 뾰족한 상록 잎이 촘촘히 붙으며, 봄·겨울에 연보라·하늘색 작은 꽃이 핍니다.',
      colorPalette: ['#2D5A27', '#9CA3AF', '#93C5FD'],
      colorDescription: '짙은 소나무빛 녹색 잎과 연청색·연보라색 작은 꽃',
      scent: '잎을 손으로 쓸어주기만 해도 청량하고 스파이시한 솔잎·허브 향이 강하게 납니다.',
      scentIntensity: '강함',
      sizeAndGrowth: '화분 기준 30~100cm',
      bloomingSeason: '겨울~봄(12~4월)',
      petSafety: '큰 독성은 없으나 에센셜 오일이 강하므로 다량 섭취는 피합니다.',
    },
    careGuide: {
      watering:
        '건조에 강한 편입니다. 겉흙이 완전히 마른 뒤 물을 흠뻑 주며 물받침에 물이 고이지 않게 합니다.',
      wateringCycle: '봄~가을 4~6일에 1회 · 겨울 7~10일에 1회',
      sunlight: '강한 직사광선과 사방이 트인 바람(통풍)이 생명입니다.',
      temperature: '15~25°C 적정 · 영하권 추위에도 어느 정도 견디나 한파 시 실내 이동',
      humidity: '35~50%의 건조하고 쾌적한 공기를 선호합니다.',
      soil: '배수성 배합토(상토 5 : 마사토·펄라이트 5)를 씁니다.',
      fertilizer: '생장이 왕성한 봄·가을에 소량의 허브용 유기질 비료만 줍니다.',
      pruningAndRepotting:
        '웃자란 줄기 끝을 주기적으로 수확 겸 가지치기하면 옆 가지가 풍성해집니다.',
      commonIssues:
        '통풍이 막힌 실내에서 과습하면 잎 끝부터 검게 마르므로 흙 통기성이 최우선입니다.',
    },
    funFact:
      '라틴어 "Ros marinus(바다의 이슬)"에서 유래했으며, 기억력과 집중력을 높여주는 허브로 유명합니다.',
  },
  {
    id: 'ocimum-basilicum',
    nameKo: '스위트 바질',
    nameEn: 'Sweet Basil',
    scientificName: 'Ocimum basilicum',
    family: '꿀풀과 (Lamiaceae)',
    category: '허브·방향식물',
    origin: '인도 · 열대 아시아',
    difficulty: '초보자 추천',
    summary:
      '부드럽고 동글한 연초록 잎에서 달콤하면서도 스파이시한 지중해 요리 특유의 상큼한 허브 향기가 가득 풍겨 나옵니다.',
    imageUrl: IMG_HERB,
    characteristics: {
      appearance:
        '수분을 머금은 듯 탱글하고 볼록한 타원형 잎이 마주나며, 여름철 줄기 끝에 하얀 작은 꽃이 핍니다.',
      colorPalette: ['#16A34A', '#4ADE80', '#FFFFFF'],
      colorDescription: '맑고 밝은 생생한 초록색 잎과 흰색 꽃',
      scent: '살짝 스치기만 해도 클로브·박하·시트러스가 어우러진 달콤한 바질 향이 진하게 퍼집니다.',
      scentIntensity: '강함',
      sizeAndGrowth: '키 25~50cm, 봄~여름 성장 속도가 매우 빠름',
      bloomingSeason: '여름(7~9월)',
      petSafety: '강아지와 고양이에게 독성이 없는 안전한 허브입니다.',
    },
    careGuide: {
      watering:
        '물을 좋아하는 허브입니다. 겉흙이 마르면 듬뿍 주며 물이 부족하면 잎이 금방 처집니다.',
      wateringCycle: '봄~여름 2~3일에 1회 · 가을 주 1~2회',
      sunlight: '하루 4시간 이상의 햇빛이 잘 드는 창가나 베란다에서 잎이 튼튼하게 자랍니다.',
      temperature: '18~28°C의 따뜻한 온도 선호 · 추위에 약해 12°C 이하에서 냉해를 입음',
      humidity: '50% 내외 일반 실내 습도에서 잘 자랍니다.',
      soil: '보수력과 배수력이 좋은 원예용 상토 + 펄라이트(8:2)를 씁니다.',
      fertilizer: '수확이 많은 봄~여름에 2주에 1회 식용 허브용 유기 액비를 줍니다.',
      pruningAndRepotting:
        '위쪽 줄기 잎마디 위를 잘라(순지르기) 수확하면 양옆에서 두 갈래로 가지가 늘어 풍성해집니다.',
      commonIssues:
        '꽃대가 올라오면 잎이 질겨지고 향이 약해지므로 꽃봉오리는 바로 따주는 것이 좋습니다.',
    },
    funFact:
      '그리스어로 "왕(Basileus)"을 뜻하며, 페스토 소스와 카프레제 샐러드의 핵심 허브로 사랑받습니다.',
  },
  {
    id: 'mentha-piperita',
    nameKo: '페퍼민트 (박하)',
    nameEn: 'Peppermint',
    scientificName: 'Mentha × piperita',
    family: '꿀풀과 (Lamiaceae)',
    category: '허브·방향식물',
    origin: '유럽 교잡 허브',
    difficulty: '초보자 추천',
    summary:
      '톱니 모양 잎에서 코끝이 시원해지는 강렬한 멘톨(박하) 향이 나며, 생명력이 뛰어나 초보자도 쑥쑥 키워 차로 즐길 수 있습니다.',
    imageUrl: IMG_HERB,
    characteristics: {
      appearance:
        '보랏빛이 살짝 감도는 네모난 줄기 위로 가장자리에 톱니가 있는 길쭉한 초록 잎이 자랍니다.',
      colorPalette: ['#15803D', '#22C55E', '#A855F7'],
      colorDescription: '짙은 녹색 잎과 은은한 보라빛 줄기·여름 꽃',
      scent: '시원하고 상쾌한 박하·멘톨 향이 즉각적으로 퍼집니다.',
      scentIntensity: '강함',
      sizeAndGrowth: '키 30~60cm, 땅속줄기로 옆으로 빠르게 퍼짐',
      bloomingSeason: '여름(7~8월) 연보라색 꽃',
      petSafety: '고농도 정유는 반려동물에게 자극이 될 수 있어 다량 섭취만 피하면 됩니다.',
    },
    careGuide: {
      watering:
        '민트는 물을 매우 좋아합니다. 겉흙이 마르지 않도록 촉촉하게 관리하세요.',
      wateringCycle: '봄~여름 1~2일에 1회 · 겨울 4~5일에 1회',
      sunlight: '반양지~양지 모두에서 잘 자라며 한여름 직사광선만 살짝 피해도 싱싱합니다.',
      temperature: '15~25°C 적정 · 노지 월동도 가능한 강인한 내한성',
      humidity: '50~65% 선호',
      soil: '보수력이 좋은 일반 원예 상토를 사용하며 다른 식물과 합식은 피하고 단독 화분에 심으세요.',
      fertilizer: '봄~가을 월 1회 허브용 비료를 줍니다.',
      pruningAndRepotting:
        '밑동이 헐거워질 정도로 빠르게 번지므로 수시로 윗줄기를 수확하고 1년에 한 번 분갈이합니다.',
      commonIssues:
        '통풍이 부족하고 잎이 너무 빽빽하면 진딧물이나 흰가루병이 올 수 있으니 자주 수확해 솎아 주세요.',
    },
    funFact:
      '스피어민트와 워터민트의 자연 교잡종으로, 잎 속 멘톨 함량이 일반 민트보다 훨씬 높습니다.',
  },
  {
    id: 'melissa-officinalis',
    nameKo: '레몬밤',
    nameEn: 'Lemon Balm',
    scientificName: 'Melissa officinalis',
    family: '꿀풀과 (Lamiaceae)',
    category: '허브·방향식물',
    origin: '남유럽 · 지중해 · 서아시아',
    difficulty: '초보자 추천',
    summary:
      '폭신한 주름이 있는 하트 잎에서 싱그러운 생레몬 껍질 같은 상큼한 시트러스 향기가 나는 다년생 힐링 허브입니다.',
    imageUrl: IMG_HERB,
    characteristics: {
      appearance:
        '잔잔한 톱니와 깊은 주름이 있는 밝은 녹색 하트 모양 잎이 풍성하게 무리 지어 자랍니다.',
      colorPalette: ['#22C55E', '#BEF264', '#FEF08A'],
      colorDescription: '산뜻한 연초록~레몬빛이 도는 밝은 그린',
      scent: '손끝으로 잎을 건드리면 기분 좋은 레몬 시트러스와 달콤한 허브 향이 감돕니다.',
      scentIntensity: '강함',
      sizeAndGrowth: '키 30~60cm, 다년생으로 풍성히 자람',
      bloomingSeason: '여름(6~8월) 작은 흰색 꿀꽃 개화',
      petSafety: '강아지와 고양이에게 독성이 없는 안전한 허브입니다.',
    },
    careGuide: {
      watering:
        '겉흙이 마르기 시작하면 물을 듬뿍 줍니다. 건조하면 잎이 축 처졌다가 물 주면 금세 회복합니다.',
      wateringCycle: '봄~가을 2~4일에 1회 · 겨울 주 1회',
      sunlight: '반양지~밝은 간접광에서 잎이 타지 않고 부드럽고 향기롭게 자랍니다.',
      temperature: '15~25°C 적정 · 내한성이 매우 강함',
      humidity: '50% 내외 일반 습도에 잘 적응합니다.',
      soil: '배수와 보수가 적당한 일반 허브용 상토를 사용합니다.',
      fertilizer: '봄~가을 월 1회 유기질 액비를 줍니다.',
      pruningAndRepotting:
        '줄기가 길어지면 아랫마디를 남기고 잘라 수확하면 새순이 빽빽하게 올라옵니다.',
      commonIssues:
        '한여름 직사광선에 잎이 탈 수 있으므로 여름에는 반그늘로 옮겨 주세요.',
    },
    funFact:
      '속명 "Melissa"는 그리스어로 꿀벌을 뜻하며, 꿀벌들이 이 꽃의 향기를 무척 좋아해 붙은 이름입니다.',
  },
  {
    id: 'eucalyptus-polyanthemos',
    nameKo: '유칼립투스 폴리안',
    nameEn: 'Silver Dollar Gum',
    scientificName: 'Eucalyptus polyanthemos',
    family: '도금양과 (Myrtaceae)',
    category: '허브·방향식물',
    origin: '호주 남동부 건조 숲',
    difficulty: '세심한 관리 필요',
    summary:
      '은빛이 감도는 동그랗고 하트 모양 같은 청록 잎에서 코끝이 뻥 뚫리는 듯한 상쾌한 숲·멘톨 향이 납니다.',
    imageUrl: IMG_HERB,
    characteristics: {
      appearance:
        '은청색 분이 오른 듯한 매트하고 둥근 잎이 하늘거리는 가느다란 줄기에 어긋납니다.',
      colorPalette: ['#64748B', '#7C9082', '#94A3B8'],
      colorDescription: '유화 물감 같은 톤 다운된 은청록·세이지 그린',
      scent: '시네올 성분이 함유되어 시원한 멘톨, 박하, 청량한 나무 숲의 향이 납니다.',
      scentIntensity: '은은함~강함 (잎을 비비면 매우 진함)',
      sizeAndGrowth: '화분 재배 시 60~180cm',
      bloomingSeason: '성숙목은 여름에 크림색 수술 꽃을 피웁니다.',
      petSafety: '시네올 에센셜 오일이 반려동물에게 독성을 유발할 수 있어 닿지 않는 곳에 둡니다.',
    },
    careGuide: {
      watering:
        '목마름에 매우 예민하여 겉흙이 마르려 할 때 듬뿍 주되 물고임은 피해야 하는 균형이 중요합니다.',
      wateringCycle: '봄~여름 2~4일에 1회 · 겨울 5~7일에 1회',
      sunlight: '하루 5시간 이상의 직사광선과 끊임없는 통풍(창문 열기)이 필수입니다.',
      temperature: '12~25°C 적정 · 서늘하고 통풍 좋은 베란다 최적',
      humidity: '40~55%의 쾌적한 공기 순환 환경 선호',
      soil: '배수가 뛰어나면서도 수분을 적당히 머금는 상토 6 : 배수재 4 배합토가 좋습니다.',
      fertilizer: '인산 성분에 민감하므로 저인산 완효성 비료를 봄에 소량만 줍니다.',
      pruningAndRepotting:
        '뿌리가 예민하므로 분갈이 시 뿌리털을 건드리지 않도록 통째로 옮깁니다.',
      commonIssues:
        '한 번 바싹 말라 바스라진 잎은 다시 살아나지 않으므로 흙 마름 체크를 매일 해주세요.',
    },
    funFact:
      '말린 뒤에도 은청빛 색감과 특유의 피톤치드 향이 오래 남아 리스나 인테리어 오브제로 널리 활용됩니다.',
  },
  {
    id: 'cupressus-macrocarpa-goldcrest',
    nameKo: '율마 (골드크레스트)',
    nameEn: 'Lemon Cypress',
    scientificName: 'Cupressus macrocarpa Goldcrest',
    family: '측백나무과 (Cupressaceae)',
    category: '허브·방향식물',
    origin: '미국 캘리포니아 몬터레이 원예종',
    difficulty: '세심한 관리 필요',
    summary:
      '황금빛을 머금은 부드러운 연두색 침엽수 형태로, 잎을 살짝 만지면 산뜻한 레몬·피톤치드 향기가 나는 미니 크리스마스 트리입니다.',
    imageUrl: IMG_HERB,
    characteristics: {
      appearance:
        '원뿔 모양의 단정한 실루엣을 이루며 가늘고 부드러운 비늘잎이 빽빽하게 자랍니다.',
      colorPalette: ['#84CC16', '#BEF264', '#4D7C0F'],
      colorDescription: '햇빛 아래 황금빛으로 빛나는 밝은 라임·연두색',
      scent: '잎을 손으로 살짝 비비면 청량한 레몬 껍질과 편백 숲이 섞인 향이 납니다.',
      scentIntensity: '은은함~강함 (접촉 시 발향)',
      sizeAndGrowth: '실내 화분 30cm~1.5m',
      bloomingSeason: '상록 침엽수로 사계절 푸름을 유지합니다.',
      petSafety: '일반적으로 독성은 낮으나 잎이 거칠어 반려동물이 먹지 않도록 합니다.',
    },
    careGuide: {
      watering:
        '물 마름에 매우 민감합니다. 겉흙이 마르기 시작하면 즉시 듬뿍 주며 물받침 저면관수도 효과적입니다.',
      wateringCycle: '봄~가을 2~3일에 1회 · 겨울 4~5일에 1회',
      sunlight: '풍부한 직사광선과 사계절 통풍이 절대적으로 필요합니다.',
      temperature: '10~22°C의 서늘한 환경 선호 · 한여름 고온다습에 약함',
      humidity: '50% 내외가 좋으나 반드시 시원한 바람이 통해야 합니다.',
      soil: '배수가 좋고 약간 산성인 상토 6 : 마사토 4 배합토가 적합합니다.',
      fertilizer: '봄~가을 2개월에 1회 소량의 완효성 비료를 줍니다.',
      pruningAndRepotting:
        '안쪽의 묵은 잎을 살짝 털어 통풍을 확보해 주고, 겉모양을 다듬을 땐 새순 끝만 손으로 따줍니다.',
      commonIssues:
        '하루만 물을 놓쳐 잎이 바싹 마르면 회복이 어렵고, 어둡고 더운 거실에선 안쪽부터 갈변합니다.',
    },
    funFact:
      '원뿔 모양의 밝은 연두빛 수형 덕분에 겨울철 살아있는 미니 크리스마스트리로 가장 사랑받습니다.',
  },
  {
    id: 'murraya-paniculata',
    nameKo: '오렌지자스민',
    nameEn: 'Orange Jasmine',
    scientificName: 'Murraya paniculata',
    family: '운향과 (Rutaceae)',
    category: '허브·방향식물',
    origin: '동남아시아 · 호주 열대',
    difficulty: '보통',
    summary:
      '작고 윤기 나는 아카시아 같은 초록 잎 사이로 순백의 꽃이 피어, 오렌지꽃과 자스민을 섞은 듯 상큼하고 달콤한 향기를 전합니다.',
    imageUrl: IMG_FLOWER,
    characteristics: {
      appearance:
        '작고 둥근 타원형 잎들이 새털처럼 깔끔하게 달리는 단정한 목본 식물이며, 별 모양의 하얀 꽃 후 작은 붉은 열매가 맺히기도 합니다.',
      colorPalette: ['#FFFFFF', '#166534', '#EF4444'],
      colorDescription: '순백색 꽃과 윤기 도는 에메랄드빛 작은 잎',
      scent: '감귤류(네롤리) 꽃향기와 달콤한 자스민 향이 조화된 맑고 기분 좋은 향기입니다.',
      scentIntensity: '강함 (개화 시 방 안 가득 발향)',
      sizeAndGrowth: '화분 기준 40~120cm',
      bloomingSeason: '봄~가을 조건이 맞으면 여러 차례 반복 개화',
      petSafety: '강아지와 고양이에게 독성이 보고되지 않은 비교적 안전한 수종입니다.',
    },
    careGuide: {
      watering:
        '겉흙이 2~3cm 말랐을 때 충분히 줍니다. 과습 시 잎이 후두둑 떨어질 수 있습니다.',
      wateringCycle: '봄~가을 4~6일에 1회 · 겨울 7~10일에 1회',
      sunlight: '하루 4시간 이상 햇빛이 잘 드는 밝은 창가에서 꽃봉오리가 잘 맺힙니다.',
      temperature: '18~26°C 적정 · 겨울철 10°C 이상 실내 관리',
      humidity: '45~60% 일반 실내 습도에서 잘 자랍니다.',
      soil: '배수가 잘되는 사질양토(상토 6 : 마사토·펄라이트 4)를 씁니다.',
      fertilizer: '개화 시즌(봄~여름)에 2~3주마다 개화용 액비를 공급합니다.',
      pruningAndRepotting:
        '꽃이 진 후 2년에 한 번 분갈이하며 삐져나온 잔가지만 다듬어 주세요.',
      commonIssues:
        '환경이 갑자기 어두워지거나 찬 바람을 맞으면 작은 잎들이 떨어질 수 있습니다.',
    },
    funFact:
      '이름에 자스민이 들어가지만 실제로는 감귤나무와 같은 운향과에 속해 상큼한 네롤리 계열 향기가 납니다.',
  },
  {
    id: 'echeveria-laui',
    nameKo: '에케베리아 라우이',
    nameEn: 'Echeveria Laui',
    scientificName: 'Echeveria laui',
    family: '돌나물과 (Crassulaceae)',
    category: '다육·선인장',
    origin: '멕시코 오아하카주 고산 지대',
    difficulty: '보통',
    summary:
      '통통한 파스텔 블루 잎 표면을 눈처럼 하얀 천연 분(백분)이 감싸고 있는 우아한 장미 모양 다육식물입니다.',
    imageUrl: IMG_SUCCULENT,
    characteristics: {
      appearance:
        '도톰하고 둥근 주걱 모양 잎이 촘촘한 로제트(장미꽃) 형태로 배열됩니다. 표면 백분은 손으로 만지지 마세요.',
      colorPalette: ['#CBD5E1', '#E2D4D8', '#94A3B8'],
      colorDescription: '파우더리한 은청색, 연보라·분홍빛이 감도는 맑은 분백색',
      scent: '향기가 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '직경 10~20cm 내외의 콤팩트한 크기',
      bloomingSeason: '봄~초여름 주황·산호빛 종 모양 꽃이 핍니다.',
      petSafety: '독성이 없어 강아지·고양이에게 안전합니다.',
    },
    careGuide: {
      watering:
        '흙이 완전히 바싹 마르고 아래쪽 잎이 살짝 말랑해질 때(2~3주에 1회) 흙 위로만 조심스레 줍니다.',
      wateringCycle: '봄·가을 2주에 1회 · 여름·겨울 3~4주에 1회',
      sunlight: '풍부한 직사광선과 통풍이 색감과 잎 두께를 결정합니다.',
      temperature: '15~25°C 적정 · 겨울철 5°C 이상 유지',
      humidity: '30~45%의 건조한 환경을 선호합니다.',
      soil: '배수가 극대화된 다육 전용토(마사토·난석·펄라이트 75% + 상토 25%)가 필수입니다.',
      fertilizer: '봄·가을 성장기에만 아주 묽은 다육용 비료를 1~2회 소량 줍니다.',
      pruningAndRepotting:
        '마른 하엽은 핀셋으로 깔끔하게 제거해 통풍을 확보합니다.',
      commonIssues:
        '여름철 고온다습 시 무름병에 주의하고 바람이 잘 통하게 관리하세요.',
    },
    funFact:
      '독일 식물학자 알프레드 라우(Alfred Lau)가 멕시코 절벽에서 발견하여 학명에 이름이 붙었습니다.',
  },
  {
    id: 'dracaena-angolensis',
    nameKo: '스투키 (실린드리카 산세베리아)',
    nameEn: 'Cylindrical Snake Plant',
    scientificName: 'Dracaena angolensis',
    family: '비짜루과 (Asparagaceae)',
    category: '다육·선인장',
    origin: '아프리카 앙골라 건조 지역',
    difficulty: '초보자 추천',
    summary:
      '곧게 하늘로 뻗은 굵은 원통형 잎과 호랑이 무늬 줄이 모던하며, 밤에 산소를 방출하고 물을 거의 주지 않아도 잘 버팁니다.',
    imageUrl: IMG_SUCCULENT,
    characteristics: {
      appearance:
        '뾰족하고 단단한 원통 기둥 모양의 다육질 잎이 수직으로 솟아오르며 짙고 옅은 녹색 가로 줄무늬가 새겨져 있습니다.',
      colorPalette: ['#1E3A2F', '#4D6B53', '#84A98C'],
      colorDescription: '차분한 올리브 그린과 딥 포레스트 그린의 얼룩무늬',
      scent: '향기가 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '화분 기준 30~80cm, 성장 속도가 매우 느림',
      bloomingSeason: '드물게 향기로운 작은 흰색 꽃대가 올라오기도 합니다.',
      petSafety: '사포닌 성분이 있어 반려동물이 씹지 않도록 주의해야 합니다.',
    },
    careGuide: {
      watering:
        '건조에 극도로 강하고 과습에는 약합니다. 흙 속까지 바싹 마른 뒤 한 달에 한 번 정도만 주어도 잘 자랍니다.',
      wateringCycle: '봄~가을 3~4주에 1회 · 겨울 4~6주에 1회',
      sunlight: '햇빛이 잘 드는 곳부터 실내 반음지까지 적응력이 뛰어납니다.',
      temperature: '15~28°C 적정 · 겨울철 10°C 이상 관리',
      humidity: '건조한 일반 실내 환경(30~50%)에 완벽히 적합합니다.',
      soil: '배수가 아주 빠른 다육·선인장용 마사토 위주의 흙을 사용합니다.',
      fertilizer: '거의 필요 없으며 봄철 연 1~2회 아주 묽은 액비면 충분합니다.',
      pruningAndRepotting:
        '뿌리가 화분을 가득 채울 때까지 2~3년에 한 번만 분갈이해도 됩니다.',
      commonIssues:
        '물을 너무 자주 주면 밑둥이 물러 쓰러지므로 절대 과습하지 않는 것이 핵심입니다.',
    },
    funFact:
      'CAM 식물에 속해 밤 시간에 이산화탄소를 흡수하고 산소를 내뿜어 침실용으로 인기가 높습니다.',
  },
  {
    id: 'aloe-vera',
    nameKo: '알로에 베라',
    nameEn: 'Aloe Vera',
    scientificName: 'Aloe vera',
    family: '아스포델루스과 (Asphodelaceae)',
    category: '다육·선인장',
    origin: '아라비아반도 · 북아프리카',
    difficulty: '초보자 추천',
    summary:
      '가장자리에 부드러운 톱니가 있는 두툼한 다육 잎 속에 맑은 수분 젤을 가득 머금고 있는 실용적이고 강인한 식물입니다.',
    imageUrl: IMG_SUCCULENT,
    characteristics: {
      appearance:
        '로제트 형태로 솟아오른 굵고 길쭉한 칼날 모양의 다육질 잎 가장자리에 작은 돌기가 돋아 있습니다.',
      colorPalette: ['#4D7C0F', '#84CC16', '#A3E635'],
      colorDescription: '은은한 회록색·밝은 연두빛 잎',
      scent: '잎을 자르면 신선하고 맑은 풀 내음이 납니다(평소엔 무향).',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '높이 30~60cm, 옆에서 자구가 잘 자람',
      bloomingSeason: '성숙 시 주황·노랑 긴 꽃대가 올라옵니다.',
      petSafety: '껍질의 알로인 성분이 반려동물에게 설사를 유발할 수 있어 주의합니다.',
    },
    careGuide: {
      watering:
        '잎에 수분이 가득하므로 흙이 완전히 마른 뒤 2~3주에 한 번 흠뻑 줍니다.',
      wateringCycle: '봄~가을 2주에 1회 · 겨울 3~4주에 1회',
      sunlight: '햇빛이 잘 드는 창가(양지~반양지)에서 가장 튼튼하고 도톰하게 자랍니다.',
      temperature: '15~27°C 적정 · 겨울철 5°C 이상 실내 보호',
      humidity: '건조한 실내(30~45%)를 선호합니다.',
      soil: '배수가 빠른 선인장·다육용 배합토(마사토·펄라이트 60% 이상)를 씁니다.',
      fertilizer: '봄·가을에 아주 소량의 다육용 비료만 줍니다.',
      pruningAndRepotting:
        '옆으로 올라온 아기 알로에(자구)가 커지면 봄에 떼어내 새 화분에 심어 보세요.',
      commonIssues:
        '햇빛이 부족하면 잎이 가늘고 길게 눕고, 직사가 너무 강하면 잎 색이 붉은 갈색으로 변할 수 있습니다.',
    },
    funFact:
      '고대 이집트에서는 "불멸의 식물"이라 불리며 피부 진정과 상처 치유용으로 수천 년간 재배되었습니다.',
  },
  {
    id: 'crassula-ovata',
    nameKo: '염좌 (돈나무)',
    nameEn: 'Jade Plant',
    scientificName: 'Crassula ovata',
    family: '돌나물과 (Crassulaceae)',
    category: '다육·선인장',
    origin: '남아프리카 · 모잠비크',
    difficulty: '초보자 추천',
    summary:
      '윤기 있는 통통한 동전 모양 다육 잎이 작은 나무처럼 굵은 목질 가지에 달려 분재처럼 고풍스러운 수형을 자랑합니다.',
    imageUrl: IMG_SUCCULENT,
    characteristics: {
      appearance:
        '단단한 갈색 나무 기둥 같은 줄기 위에 두툼하고 매끈한 타원형 잎이 쌍을 이루어 빽빽히 자랍니다.',
      colorPalette: ['#15803D', '#65A30D', '#DC2626'],
      colorDescription: '광택 있는 비취빛 초록 잎 (햇빛을 많이 받으면 가장자리가 붉게 물듦)',
      scent: '향기가 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '화분 기준 25cm~1m, 수명이 매우 길어 수십 년 자람',
      bloomingSeason: '성숙한 개체는 겨울에 별 모양의 흰색·분홍 꽃을 피웁니다.',
      petSafety: '강아지와 고양이에게 독성이 있어 닿지 않는 곳에 둡니다.',
    },
    careGuide: {
      watering:
        '잎이 통통하고 단단할 땐 물을 주지 말고, 잎이 살짝 주름지거나 말랑해질 때 흠뻑 줍니다.',
      wateringCycle: '봄~가을 2주에 1회 · 겨울 3~4주에 1회',
      sunlight: '하루 4시간 이상의 밝은 햇빛과 통풍이 잘되는 창가가 최적입니다.',
      temperature: '15~25°C 적정 · 겨울철 7°C 이상 실내 유지',
      humidity: '건조한 실내(30~50%)에 잘 맞습니다.',
      soil: '배수가 빠른 다육용 마사토 혼합토를 사용합니다.',
      fertilizer: '봄·가을 성장기에 연 2~3회 묽은 다육용 비료를 줍니다.',
      pruningAndRepotting:
        '가지를 잘라 2~3일 말린 뒤 흙에 꽂으면 쉽게 뿌리가 내립니다.',
      commonIssues:
        '과습 시 잎이 통통한 채로 우수수 떨어지므로 반드시 흙 건조를 확인하고 물 주세요.',
    },
    funFact:
      '동글동글한 비취빛 잎이 옥이나 동전을 닮아 풍수지리에서 행운과 부를 부르는 식물로 사랑받습니다.',
  },
  {
    id: 'camellia-japonica',
    nameKo: '동백나무',
    nameEn: 'Japanese Camellia',
    scientificName: 'Camellia japonica',
    family: '차나무과 (Theaceae)',
    category: '꽃·관화식물',
    origin: '한국 남부 · 일본 · 중국 동부 해안',
    difficulty: '보통',
    summary:
      '한겨울에서 이른 봄 사이 짙고 윤기 나는 상록 잎 사이로 선명한 분홍·붉은 꽃을 피우는 기품 있는 관화식물입니다.',
    imageUrl: IMG_FLOWER,
    characteristics: {
      appearance:
        '가죽처럼 두껍고 광택이 도는 타원형 상록 잎이 촘촘히 자라며, 풍성한 꽃잎과 노란 수술이 어우러진 대륜의 꽃이 핍니다.',
      colorPalette: ['#BE123C', '#F472B6', '#14532D'],
      colorDescription: '선명한 진홍·연분홍 꽃잎과 짙은 흑녹색 광택 잎',
      scent: '대부분 은은한 차(Tea) 계열의 맑고 소박한 향을 지닙니다.',
      scentIntensity: '은은함',
      sizeAndGrowth: '화분 50~150cm, 노지에서는 3~6m 소교목',
      bloomingSeason: '겨울~초봄(12~4월)',
      petSafety: '강아지·고양이에게 독성이 없는 안전한 식물입니다.',
    },
    careGuide: {
      watering:
        '흙이 마르기 전에 촉촉하게 유지하되 물고임은 피합니다. 꽃눈이 커지는 가을~겨울 수분 부족을 주의하세요.',
      wateringCycle: '봄~가을 3~5일에 1회 · 겨울 7일에 1회',
      sunlight: '반양지~반음지를 좋아하며 한여름 강렬한 직사광선은 피해 주세요.',
      temperature: '서늘한 10~20°C 선호 · 개화를 위해 겨울철 5~10°C 서늘한 베란다가 도움 됨',
      humidity: '50~70% 선호 · 실내 난방 시 건조하지 않게 관리하세요.',
      soil: '약산성(pH 5.5~6.5)의 배수 좋은 흙(녹소토·피트모스 혼합)에서 잘 자랍니다.',
      fertilizer: '꽃이 진 직후인 봄(4~5월)과 초가을에 완효성 산성 비료를 줍니다.',
      pruningAndRepotting:
        '꽃이 진 후 안쪽 잔가지를 정리하며, 여름철 꽃눈 형성 후에는 가지치기를 피합니다.',
      commonIssues:
        '고온 건조한 실내에서는 꽃봉오리가 말라 떨어지기 쉬우니 서늘하고 환기 잘되는 곳에 두세요.',
    },
    funFact:
      '추운 겨울에 동박새가 꿀을 먹으며 수분을 돕기 때문에 새의 무게를 견딜 수 있도록 꽃송이가 통째로 튼튼하게 달려 있습니다.',
  },
  {
    id: 'osmanthus-fragrans',
    nameKo: '은목서 (만리향)',
    nameEn: 'Sweet Olive (Sweet Osmanthus)',
    scientificName: 'Osmanthus fragrans',
    family: '물푸레나무과 (Oleaceae)',
    category: '꽃·관화식물',
    origin: '중국 남부 · 히말라야 · 동아시아',
    difficulty: '보통',
    summary:
      '가을에 피는 작고 뽀얀 꽃에서 "만 리 밖까지 퍼진다"고 알려진 달콤한 살구·복숭아 계열의 고혹적인 향기가 납니다.',
    imageUrl: IMG_FLOWER,
    characteristics: {
      appearance:
        '가죽질의 긴 타원형 잎이 마주나며, 잎겨드랑이마다 아주 작은 네 갈래의 꽃들이 송이째 피어납니다.',
      colorPalette: ['#FEF3C7', '#FDE68A', '#1E3A2F'],
      colorDescription: '은백색~크림 아이보리 꽃(금목서는 주황빛)과 짙은 녹색 잎',
      scent: '잘 익은 살구, 복숭아, 꿀을 섞은 듯 달콤하고 품격 있는 과일·플로럴 향이 멀리까지 퍼집니다.',
      scentIntensity: '강함 ("만리향")',
      sizeAndGrowth: '화분 기준 80~180cm',
      bloomingSeason: '가을(9~10월)',
      petSafety: '반려동물에게 독성이 보고되지 않은 안전한 수종입니다.',
    },
    careGuide: {
      watering: '겉흙이 마르면 듬뿍 주며 지나친 과습이나 극심한 건조를 피합니다.',
      wateringCycle: '봄~가을 3~5일에 1회 · 겨울 7~10일에 1회',
      sunlight: '하루 4시간 이상의 충분한 햇빛과 통풍이 있어야 가을에 꽃눈이 맺힙니다.',
      temperature: '15~25°C 적정 · 겨울철 베란다(0~5°C 이상) 월동 권장',
      humidity: '40~60% 실내 환경에 잘 적응합니다.',
      soil: '배수가 잘되는 중성~약산성 사질양토(상토 6 : 마사토 4)가 좋습니다.',
      fertilizer: '봄 성장기와 초여름에 인산·칼륨 비율이 높은 비료를 소량 줍니다.',
      pruningAndRepotting:
        '가지치기는 꽃이 진 후 이른 봄에 진행해야 가을 꽃눈을 자르지 않습니다.',
      commonIssues:
        '어둡고 답답한 거실 안쪽에 오래 두면 잎이 떨어지고 꽃이 피지 않습니다.',
    },
    funFact:
      '은목서는 하얀 꽃이, 형제 나무인 금목서는 진한 귤빛 주황색 꽃이 가을에 피며 둘 다 향기가 매우 짙습니다.',
  },
  {
    id: 'gardenia-jasminoides',
    nameKo: '치자나무',
    nameEn: 'Cape Jasmine (Gardenia)',
    scientificName: 'Gardenia jasminoides',
    family: '꼭두서니과 (Rubiaceae)',
    category: '꽃·관화식물',
    origin: '한국 남부 · 중국 · 일본 · 대만',
    difficulty: '세심한 관리 필요',
    summary:
      '에나멜처럼 반짝이는 짙은 녹색 잎과 상아빛 순백 꽃이 어우러지며, 크리미하고 우아한 고급 향수의 원료가 되는 꽃나무입니다.',
    imageUrl: IMG_FLOWER,
    characteristics: {
      appearance:
        '광택이 강한 긴 타원형 잎이 빽빽하게 자라며, 장미처럼 겹겹이 말린 순백색·크림색 꽃이 핍니다.',
      colorPalette: ['#FFFBEB', '#FEF3C7', '#064E3B'],
      colorDescription: '유백색~진주빛 흰 꽃과 광택이 흐르는 짙은 청록색 잎',
      scent: '자스민과 코코넛, 화이트 플라워가 조화된 깊고 우아한 향기를 지녔습니다.',
      scentIntensity: '강함',
      sizeAndGrowth: '화분 기준 40~100cm의 단정한 관목',
      bloomingSeason: '초여름(6~7월) 중심',
      petSafety: '반려동물이 섭취 시 가벼운 위장 장애를 일으킬 수 있습니다.',
    },
    careGuide: {
      watering:
        '물을 좋아하는 식물이므로 겉흙이 마르기 시작할 때 흠뻑 줍니다. 흙이 완전히 마르면 꽃봉오리가 떨어집니다.',
      wateringCycle: '봄~여름 2~3일에 1회 · 겨울 5~7일에 1회',
      sunlight: '밝은 햇빛(반양지~양지)을 좋아하며 한여름 강렬한 직사만 살짝 가려줍니다.',
      temperature: '16~24°C 선호 · 겨울철 5~10°C 이상 보호',
      humidity: '60% 이상의 높은 습도를 좋아하며 잦은 분무가 도움 됩니다.',
      soil: '반드시 약산성(pH 5.0~6.0) 배합토(피트모스·녹소토 혼합)를 사용해야 황화 현상을 막습니다.',
      fertilizer: '개화 전후로 산성 식물용 비료(철분 포함)를 줍니다.',
      pruningAndRepotting:
        '꽃이 진 직후인 여름에 수형을 다듬어야 다음 해 꽃눈이 형성됩니다.',
      commonIssues:
        '잎맥만 초록이고 잎면이 노랗게 변하는 것은 토양 산성도 부족 신호이므로 산성 토양과 철분을 보충하세요.',
    },
    funFact:
      '치자 열매는 천연 황색 식용 색소로 예로부터 단무지나 전, 한과에 고운 노란빛을 들이는 데 쓰였습니다.',
  },
  {
    id: 'pelargonium-hortorum',
    nameKo: '제라늄 (펠라고니움)',
    nameEn: 'Zonal Geranium',
    scientificName: 'Pelargonium × hortorum',
    family: '쥐손이풀과 (Geraniaceae)',
    category: '꽃·관화식물',
    origin: '남아프리카 원예 교배종',
    difficulty: '초보자 추천',
    summary:
      '부채꼴 둥근 잎에 독특한 허브·레몬 향기가 배어 있고, 공처럼 둥근 붉은·분홍·흰색 꽃볼을 일 년 내내 쉴 새 없이 피워냅니다.',
    imageUrl: IMG_FLOWER,
    characteristics: {
      appearance:
        '잔털이 있는 둥근 잎 중앙에 말굽 무늬가 들어가며, 긴 꽃대 끝에 작은 꽃들이 모여 큰 꽃다발을 이룹니다.',
      colorPalette: ['#DC2626', '#FB7185', '#4D7C0F'],
      colorDescription: '다홍·연분홍·살구·백색 등 다채로운 꽃볼과 짙은 초록 잎',
      scent: '꽃이 아닌 잎을 문질렀을 때 진한 레몬·로즈·스파이시 허브 향이 납니다.',
      scentIntensity: '은은함~강함 (잎 접촉 시 방출)',
      sizeAndGrowth: '화분 기준 25~60cm',
      bloomingSeason: '햇빛과 온도가 맞으면 봄~가을, 실내에서도 연중 개화',
      petSafety: '제라니올 성분으로 인해 반려동물 섭취 시 주의가 필요합니다.',
    },
    careGuide: {
      watering:
        '건조에 강한 반면 과습에는 약합니다. 겉흙이 충분히 마른 뒤 잎에 닿지 않게 흙 위로만 물을 주세요.',
      wateringCycle: '봄~가을 4~6일에 1회 · 여름·겨울 7~10일에 1회',
      sunlight: '하루 4시간 이상 직사광선을 쬐어주어야 꽃대가 연이어 올라옵니다.',
      temperature: '15~24°C 적정 · 고온다습한 한여름엔 반그늘에서 통풍 관리',
      humidity: '40~55%의 서늘하고 건조한 통풍 환경을 선호합니다.',
      soil: '배수가 좋은 원예 상토 + 펄라이트(7:3)가 적합합니다.',
      fertilizer: '봄·가을에 2주 간격으로 꽃 식물용 액비를 줍니다.',
      pruningAndRepotting:
        '시든 꽃대는 바로 꺾어주고, 봄·가을에 줄기를 잘라 삽목하면 쉽게 번식됩니다.',
      commonIssues:
        '장마철 고온다습 시 줄기 무름병에 주의하고 비를 피해서 물 주기를 줄여주세요.',
    },
    funFact:
      '잎에 함유된 정유 향이 모기나 날벌레를 쫓는 천연 방충 식물로도 유럽 창가에서 널리 키웁니다.',
  },
  {
    id: 'hydrangea-macrophylla',
    nameKo: '수국',
    nameEn: 'Bigleaf Hydrangea',
    scientificName: 'Hydrangea macrophylla',
    family: '수국과 (Hydrangeaceae)',
    category: '꽃·관화식물',
    origin: '한국 · 일본 · 동아시아 해안',
    difficulty: '보통',
    summary:
      '넓은 잎 사이로 풍성하고 동그란 부케처럼 탐스러운 파랑·보라·분홍빛 꽃송이를 피우며, 토양 산도에 따라 꽃 색이 바뀌는 신비로운 꽃입니다.',
    imageUrl: IMG_FLOWER,
    characteristics: {
      appearance:
        '굵고 톱니가 있는 큰 타원형 잎이 마주나며, 수많은 작은 꽃잎들이 모여 지름 15~25cm의 둥근 꽃볼을 이룹니다.',
      colorPalette: ['#60A5FA', '#A78BFA', '#F472B6'],
      colorDescription: '하늘색·라벤더 보라·연분홍·순백색 등 토양 pH에 따라 달라지는 파스텔 색감',
      scent: '대부분 아주 은은하고 맑은 풀·꽃 내음만 납니다.',
      scentIntensity: '거의 없음~은은함',
      sizeAndGrowth: '화분 기준 40~100cm의 낙엽 관목',
      bloomingSeason: '초여름(5~7월)',
      petSafety: '잎과 꽃봉오리에 독성이 있어 반려동물이 먹지 않도록 주의합니다.',
    },
    careGuide: {
      watering:
        '이름처럼 물을 매우 좋아하는 식물입니다. 겉흙이 마르기 시작하면 즉시 흠뻑 주어야 꽃이 처지지 않습니다.',
      wateringCycle: '봄~여름 매일~2일에 1회 · 겨울 주 1회',
      sunlight: '오전 햇빛이 드는 반양지가 최적이며 한여름 뜨거운 오후 직사광선은 피해 주세요.',
      temperature: '15~23°C 적정 · 겨울철 0~5°C의 추위를 겪어야 다음 해 꽃눈이 잘 분화됩니다.',
      humidity: '50~70%의 촉촉한 공기를 좋아합니다.',
      soil: '보수력이 좋은 상토 기반(산성토일수록 파란색, 중성·알칼리성일수록 분홍색 발현)을 씁니다.',
      fertilizer: '봄 성장기와 꽃이 진 직후에 개화용 완효성 비료를 줍니다.',
      pruningAndRepotting:
        '꽃이 시든 직후 7월 중순 이전에 2마디 아래를 잘라주어야 다음 해 꽃눈이 만들어집니다.',
      commonIssues:
        '조금만 물이 부족해도 전체가 축 처지지만 바로 듬뿍 물을 주면 금세 생기를 되찾습니다.',
    },
    funFact:
      '산성 토양에서는 흙 속 알루미늄 이온이 흡수되어 꽃이 파란색이 되고, 알칼리성 토양에서는 분홍색이 됩니다.',
  },
  {
    id: 'phalaenopsis-orchid',
    nameKo: '호접란 (팔레놉시스)',
    nameEn: 'Moth Orchid',
    scientificName: 'Phalaenopsis',
    family: '난초과 (Orchidaceae)',
    category: '꽃·관화식물',
    origin: '동남아시아 · 필리핀 · 대만 열대우림',
    difficulty: '초보자 추천',
    summary:
      '나비가 날갯짓하는 듯 우아한 꽃이 한 번 피면 2~4개월간 유지되며, 흙 대신 바크나 수태에서 자라 실내 관리가 깔끔한 서양란입니다.',
    imageUrl: IMG_FLOWER,
    characteristics: {
      appearance:
        '두툼하고 넓은 진녹색 잎 몇 장 위로 길고 유연한 꽃대가 뻗어 나비 모양의 대형 꽃 여러 송이가 차례로 핍니다.',
      colorPalette: ['#FFFFFF', '#F472B6', '#FACC15'],
      colorDescription: '순백색·연분홍·보라·연노랑 등 우아한 꽃잎과 굵은 은백색 공중 뿌리',
      scent: '대부분 무향이나 일부 미니 품종은 아침에 은은한 시트러스·장미 향이 납니다.',
      scentIntensity: '거의 없음 (품종별 은은함)',
      sizeAndGrowth: '높이 30~70cm',
      bloomingSeason: '겨울~봄에 주로 개화하며 수개월간 유지',
      petSafety: '강아지와 고양이에게 독성이 없는 완전히 안전한 식물입니다.',
    },
    careGuide: {
      watering:
        '투명 화분 안의 뿌리가 초록색에서 은회색으로 변하고 수태나 바크가 바싹 말랐을 때(약 7~10일마다) 흠뻑 줍니다. 잎 중앙 생장점에 물이 고이지 않게 주의하세요.',
      wateringCycle: '7~10일에 1회 (뿌리 색 확인 후 관수)',
      sunlight: '커튼을 거친 밝은 간접광이 최적입니다. 직사광선은 잎을 태웁니다.',
      temperature: '18~26°C 선호 · 꽃대를 올리려면 가을철 밤 기온을 15°C 내외로 2~3주 서늘하게 두면 효과적',
      humidity: '50~70% 선호',
      soil: '일반 흙을 쓰면 뿌리가 썩습니다. 반드시 수태(이끼) 또는 바크(나무껍질)에 심으세요.',
      fertilizer: '성장기에 난 전용 아주 묽은 액비를 월 1~2회 줍니다.',
      pruningAndRepotting:
        '꽃이 다 진 후 꽃대의 밑에서 3번째 마디 위를 자르면 옆에서 2차 꽃대가 나올 수 있습니다.',
      commonIssues:
        '과습 시 뿌리가 갈색으로 물러 썩으므로 통기성이 좋은 투명 화분 사용을 추천합니다.',
    },
    funFact:
      '자연에서는 땅이 아니라 열대우림 큰 나무 줄기에 뿌리를 붙이고 공중의 습기를 먹으며 자라는 착생 난초입니다.',
  },
  {
    id: 'rosa-miniature',
    nameKo: '미니장미',
    nameEn: 'Miniature Rose',
    scientificName: 'Rosa chinensis Minima',
    family: '장미과 (Rosaceae)',
    category: '꽃·관화식물',
    origin: '동아시아 원예 교배종',
    difficulty: '보통',
    summary:
      '작은 화분에서도 클래식한 장미 꽃송이를 풍성하게 피우며, 빨강·분홍·노랑·주황 등 다채로운 색감과 은은한 장미 향을 선사합니다.',
    imageUrl: IMG_FLOWER,
    characteristics: {
      appearance:
        '작은 톱니가 있는 광택 잎과 가느다란 가지 끝마다 겹꽃 형태의 앙증맞은 장미가 여러 송이 핍니다.',
      colorPalette: ['#E11D48', '#FB7185', '#FBBF24'],
      colorDescription: '붉은색·분홍색·살구색·노랑·순백색 등 품종별 다양',
      scent: '품종에 따라 은은하고 달콤한 전통 장미 향(티 로즈 향)이 납니다.',
      scentIntensity: '은은함~보통',
      sizeAndGrowth: '화분 기준 20~45cm',
      bloomingSeason: '봄~가을 햇빛이 좋으면 반복 개화',
      petSafety: '가시가 있어 다치지 않도록 주의하며 잎·꽃 자체 독성은 낮습니다.',
    },
    careGuide: {
      watering:
        '겉흙이 마르기 시작하면 잎에 닿지 않게 흙 위로 흠뻑 줍니다. 물 마름에 민감한 편입니다.',
      wateringCycle: '봄~여름 2~3일에 1회 · 겨울 5~7일에 1회',
      sunlight: '하루 최소 5시간 이상의 직사광선과 바람이 통하는 베란다·야외 환경이 필수입니다.',
      temperature: '15~24°C 선호 · 내한성이 있어 서늘한 베란다 월동 가능',
      humidity: '40~55%의 쾌적한 통풍 환경 선호',
      soil: '배수가 좋고 영양이 풍부한 원예 상토 + 마사토(7:3)를 씁니다.',
      fertilizer: '꽃을 계속 피우므로 봄~가을 2주 간격으로 개화용 비료를 충분히 줍니다.',
      pruningAndRepotting:
        '시든 꽃은 아래 5장 잎 마디 위에서 잘라주어야 새 순과 꽃봉오리가 빠르게 올라옵니다.',
      commonIssues:
        '환기가 부족한 실내에선 응애와 흰가루병이 생기기 쉬우므로 반드시 바람이 통하는 창가에 두세요.',
    },
    funFact:
      '보통 화원에서 한 화분에 3~4포기가 합식되어 판매되므로 분갈이 시 살짝 분리해주면 더 건강히 자랍니다.',
  },
  {
    id: 'hyacinthus-orientalis',
    nameKo: '히아신스',
    nameEn: 'Common Hyacinth',
    scientificName: 'Hyacinthus orientalis',
    family: '비짜루과 (Asparagaceae)',
    category: '꽃·관화식물',
    origin: '동지중해 · 터키 · 시리아',
    difficulty: '초보자 추천',
    summary:
      '양파 모양 구근에서 올라온 별 모양 작은 꽃들이 포도송이처럼 촘촘히 피며, 방 안 전체를 채울 만큼 매혹적이고 짙은 봄 향기를 뿜어냅니다.',
    imageUrl: IMG_FLOWER,
    characteristics: {
      appearance:
        '굵은 알뿌리(구근) 위로 도톰하고 매끈한 잎이 둘러싸고, 중앙의 굵은 꽃대에 별 모양 꽃이 조밀하게 달립니다.',
      colorPalette: ['#6366F1', '#EC4899', '#FFFFFF'],
      colorDescription: '보라·파랑·분홍·흰색·연노랑 등 선명한 파스텔 및 원색',
      scent: '달콤하고 우아하면서도 맑은 봄꽃 향수가 방 안 가득 퍼질 만큼 발향력이 뛰어납니다.',
      scentIntensity: '강함',
      sizeAndGrowth: '높이 20~35cm의 아담한 구근 식물',
      bloomingSeason: '겨울 끝~봄(2~4월), 수경재배 시 한겨울에도 개화',
      petSafety: '구근에 옥살산칼슘이 있어 반려동물이 씹지 않게 주의합니다.',
    },
    careGuide: {
      watering:
        '흙 재배 시 겉흙이 마르면 줍니다. 유리병 수경재배 시엔 알뿌리 밑둥의 뿌리 부분만 물에 닿게 채워 알뿌리가 썩지 않게 합니다.',
      wateringCycle: '흙 재배 주 1~2회 · 수경재배 주 1회 물 교체',
      sunlight: '꽃봉오리가 올라올 땐 서늘하고 밝은 간접광이 꽃을 오래 유지시킵니다.',
      temperature: '10~18°C의 서늘한 실내에서 꽃이 오래가고 향이 맑습니다.',
      humidity: '일반 실내 습도에 잘 적응합니다.',
      soil: '배수가 잘되는 상토 + 마사토 혼합토 또는 투명 유리병 수경재배 모두 좋습니다.',
      fertilizer: '꽃을 피우는 동안 구근 자체 영양분으로 충분하며 꽃 진 후 구근 키울 때만 소량 줍니다.',
      pruningAndRepotting:
        '꽃이 지면 꽃대만 잘라내고 잎이 자연스럽게 누렇게 마를 때까지 햇빛을 쬐어 구근을 살찌운 뒤 서늘한 곳에 보관합니다.',
      commonIssues:
        '너무 따뜻한 실내에 두면 꽃대가 짧게 뭉쳐 피거나 꽃이 금방 시들 수 있습니다.',
    },
    funFact:
      '그리스 신화에서 아폴론의 사랑을 받던 청년 히아킨토스의 이름에서 유래한 대표적인 봄의 구근 꽃입니다.',
  },
  {
    id: 'freesia-refracta',
    nameKo: '프리지아',
    nameEn: 'Freesia',
    scientificName: 'Freesia refracta',
    family: '붓꽃과 (Iridaceae)',
    category: '꽃·관화식물',
    origin: '남아프리카 케이프 지방',
    difficulty: '보통',
    summary:
      '줄기 끝에 90도로 꺾여 나란히 피어나는 종 모양의 노랑·하양·보라색 꽃에서 상큼하고 달콤한 복숭아·시트러스 계열 향수가 납니다.',
    imageUrl: IMG_FLOWER,
    characteristics: {
      appearance:
        '가늘고 칼처럼 뾰족한 잎 사이로 가느다란 꽃대가 올라와 끝부분이 수평으로 휘며 5~7송이의 나팔 모양 꽃이 차례로 핍니다.',
      colorPalette: ['#FACC15', '#FFFFFF', '#A855F7'],
      colorDescription: '화사한 개나리 노랑·순백·연보라·다홍색 꽃',
      scent: '누구나 좋아하는 상큼하고 맑은 달콤함(복숭아·후추·시트러스 노트)이 진하게 납니다.',
      scentIntensity: '강함',
      sizeAndGrowth: '키 30~45cm',
      bloomingSeason: '늦겨울~봄(2~4월)',
      petSafety: '강아지와 고양이에게 특별한 독성이 보고되지 않은 비교적 안전한 식물입니다.',
    },
    careGuide: {
      watering:
        '구근에서 싹이 트고 자랄 때 겉흙이 마르면 흠뻑 줍니다. 잎이 마르는 휴면기엔 단수합니다.',
      wateringCycle: '생육기 4~6일에 1회',
      sunlight: '햇빛이 부족하면 잎과 꽃대가 힘없이 쓰러지므로 반드시 밝은 창가 양지에 둡니다.',
      temperature: '12~18°C의 서늘한 봄 기온에서 튼튼하게 피고 오래갑니다.',
      humidity: '40~55% 쾌적한 실내 환경 선호',
      soil: '배수가 잘되는 사질양토(상토 6 : 펄라이트·마사토 4)를 사용합니다.',
      fertilizer: '꽃봉오리가 올라올 때 묽은 개화용 액비를 1~2회 줍니다.',
      pruningAndRepotting:
        '가느다란 잎이 쓰러지지 않도록 작은 지지대를 세워주면 깔끔합니다.',
      commonIssues:
        '고온의 실내에 두면 잎만 길게 웃자라고 꽃봉오리가 마르기 쉬우니 서늘한 베란다를 추천합니다.',
    },
    funFact:
      '졸업식과 입학식 꽃다발의 상징이며, "당신의 시작을 응원합니다"라는 꽃말을 지녔습니다.',
  },
  {
    id: 'kalanchoe-blossfeldiana',
    nameKo: '칼랑코에',
    nameEn: 'Flaming Katy',
    scientificName: 'Kalanchoe blossfeldiana',
    family: '돌나물과 (Crassulaceae)',
    category: '꽃·관화식물',
    origin: '마다가스카르',
    difficulty: '초보자 추천',
    summary:
      '도톰한 다육질 초록 잎 위로 붉고 노랗고 분홍빛의 작은 별 꽃들이 꽃다발처럼 빽빽하게 모여 오랫동안 피어 있는 다육 꽃식물입니다.',
    imageUrl: IMG_FLOWER,
    characteristics: {
      appearance:
        '가장자리가 물결 모양으로 둥글게 패인 두꺼운 다육질 잎 위로 4장의 꽃잎을 가진 작은 꽃들이 우산처럼 뭉쳐 핍니다.',
      colorPalette: ['#EF4444', '#F59E0B', '#EC4899'],
      colorDescription: '선명한 빨강·주황·노랑·분홍·흰색 홑꽃 또는 겹꽃',
      scent: '향기가 거의 없는 무향 꽃식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '높이 15~35cm의 아담한 크기',
      bloomingSeason: '겨울~봄에 주로 개화하며 한 번 피면 1~2개월 유지',
      petSafety: '강아지와 고양이에게 독성이 있어 반려동물이 씹지 못하게 높은 선반에 둡니다.',
    },
    careGuide: {
      watering:
        '다육과 식물이므로 겉흙이 완전히 마른 뒤(7~10일 간격) 꽃에 닿지 않게 흙 위로만 줍니다.',
      wateringCycle: '봄~가을 7~10일에 1회 · 겨울 2주에 1회',
      sunlight: '하루 4시간 이상의 밝은 햇빛을 받으면 꽃 색감이 더욱 선명해집니다.',
      temperature: '15~24°C 적정 · 겨울철 10°C 이상 실내 유지',
      humidity: '건조한 실내(35~50%)에 잘 맞습니다.',
      soil: '배수가 잘되는 상토 + 펄라이트·마사토(6:4) 배합토를 씁니다.',
      fertilizer: '개화기 후 봄·가을에 월 1회 묽은 비료를 줍니다.',
      pruningAndRepotting:
        '시든 꽃대는 아래 마디에서 잘라주면 새 잎이 나고, 가을에 밤 시간(14시간 어둡게)이 길어지면 다시 꽃눈을 맺습니다.',
      commonIssues:
        '과습하면 줄기 밑둥이 쉽게 무르므로 물 주기를 아끼는 편이 훨씬 안전합니다.',
    },
    funFact:
      '낮이 짧아지고 밤이 길어질 때 꽃눈이 생기는 대표적인 "단일 식물"입니다.',
  },
  {
    id: 'saintpaulia-ionantha',
    nameKo: '아프리칸 바이올렛 (세인트폴리아)',
    nameEn: 'African Violet',
    scientificName: 'Streptocarpus sect. Saintpaulia',
    family: '게스네리아과 (Gesneriaceae)',
    category: '꽃·관화식물',
    origin: '탄자니아 · 케냐 고산 숲',
    difficulty: '보통',
    summary:
      '벨벳처럼 보송보송한 둥근 잎 중앙에서 짙은 보라·분홍·흰색 꽃이 실내 형광등 불빛 아래에서도 연중 사계절 피어나는 실내 요정 식물입니다.',
    imageUrl: IMG_FLOWER,
    characteristics: {
      appearance:
        '솜털이 뽀송뽀송하게 돋은 둥글고 도톰한 잎들이 납작한 방석 모양으로 퍼지고 중앙에서 고운 꽃송이들이 솟아오릅니다.',
      colorPalette: ['#6D28D9', '#EC4899', '#166534'],
      colorDescription: '벨벳 보라색·연보라·투톤 분홍·순백색 꽃과 짙은 녹색 솜털 잎',
      scent: '향기가 거의 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '높이 10~20cm의 아주 콤팩트한 테이블용 크기',
      bloomingSeason: '온도와 실내조명이 맞으면 사계절 수시로 개화',
      petSafety: '강아지와 고양이에게 독성이 없는 안전한 식물입니다.',
    },
    careGuide: {
      watering:
        '솜털 잎에 찬물이 닿으면 갈색 얼룩이 생기므로 미지근한 물로 흙 위로만 주거나 물받침 저면관수를 해주세요.',
      wateringCycle: '봄~가을 4~6일에 1회 · 겨울 7~10일에 1회',
      sunlight: '직사광선 없이도 밝은 실내 간접광이나 책상 스탠드·식물등 아래에서 아주 잘 자라고 꽃을 피웁니다.',
      temperature: '18~24°C의 일정한 실내 온도 선호',
      humidity: '50~60% 선호',
      soil: '가볍고 공기가 잘 통하는 피트모스·펄라이트·버미큘라이트 혼합토가 좋습니다.',
      fertilizer: '개화기 동안 바이올렛·개화용 아주 묽은 액비를 격주로 줍니다.',
      pruningAndRepotting:
        '잎 하나를 따서 흙이나 물에 꽂아두면 뿌리가 내리고 아기 식물이 돋아나는 잎꽂이 번식이 아주 잘됩니다.',
      commonIssues:
        '찬물 분무나 직사광선에 노출되면 잎에 원형 얼룩이 생기니 잎을 적시지 마세요.',
    },
    funFact:
      '햇빛이 강하지 않은 실내 책상이나 북향 창가에서도 1년 내내 꽃을 볼 수 있는 가장 대표적인 실내 꽃식물입니다.',
  },
  {
    id: 'tulipa-gesneriana',
    nameKo: '튤립',
    nameEn: 'Garden Tulip',
    scientificName: 'Tulipa gesneriana',
    family: '백합과 (Liliaceae)',
    category: '꽃·관화식물',
    origin: '중앙아시아 · 터키',
    difficulty: '초보자 추천',
    summary:
      '매끈한 잎 사이로 단정하고 우아한 술잔 모양의 꽃을 피우며, 빨강·노랑·분홍·보라·하양 등 가장 다채로운 봄빛을 선물하는 꽃입니다.',
    imageUrl: IMG_FLOWER,
    characteristics: {
      appearance:
        '굵고 탄력 있는 초록 줄기 위로 6장의 꽃잎이 포개어진 컵·달걀 모양의 꽃 한 송이가 고고하게 핍니다.',
      colorPalette: ['#E11D48', '#FACC15', '#F472B6'],
      colorDescription: '붉은·분홍·노랑·보라·크림화이트 등 원색과 파스텔 전반',
      scent: '대부분 은은하고 맑은 풀·꽃 내음이 감돕니다.',
      scentIntensity: '은은함',
      sizeAndGrowth: '키 25~50cm의 봄철 구근 식물',
      bloomingSeason: '봄(3~5월)',
      petSafety: '구근에 튤리팔린 성분이 있어 반려동물이 구근을 먹지 않게 주의합니다.',
    },
    careGuide: {
      watering:
        '싹이 올라오고 자라는 동안 겉흙이 마르면 흠뻑 줍니다. 수경재배 시엔 뿌리만 물에 닿게 관리하세요.',
      wateringCycle: '생육기 주 2회',
      sunlight: '햇빛을 좋아하지만 꽃이 핀 뒤엔 너무 덥지 않고 밝은 곳에 두어야 꽃이 오래갑니다.',
      temperature: '10~18°C의 서늘한 기온에서 봉오리가 천천히 열리며 오래 지속됩니다.',
      humidity: '일반 실내 습도에 잘 적응합니다.',
      soil: '배수가 잘되는 원예 상토 + 마사토(7:3)를 사용합니다.',
      fertilizer: '개화 중에는 구근의 영양분으로 충분합니다.',
      pruningAndRepotting:
        '꽃이 지면 씨앗이 맺히지 않도록 꽃목만 잘라내고 잎이 마를 때까지 광합성을 시켜 구근을 수확합니다.',
      commonIssues:
        '실내가 너무 따뜻하면 꽃봉오리가 하루 만에 확 펼쳐지고 시들 수 있으니 밤에는 서늘한 곳에 두세요.',
    },
    funFact:
      '튤립은 꽃이 잘린 뒤에도 빛과 온도에 반응해 꽃대가 계속 자라고 해를 향해 고개를 돌리는 성질이 있습니다.',
  },
  {
    id: 'thymus-vulgaris',
    nameKo: '타임 (백리향)',
    nameEn: 'Common Thyme',
    scientificName: 'Thymus vulgaris',
    family: '꿀풀과 (Lamiaceae)',
    category: '허브·방향식물',
    origin: '서부 지중해 연안',
    difficulty: '보통',
    summary:
      '깨알처럼 앙증맞은 작은 잎이 촘촘히 달린 줄기에서 진하고 고소한 숲·허브 향이 백 리까지 퍼져나가는 매력적인 미니 허브입니다.',
    imageUrl: IMG_HERB,
    characteristics: {
      appearance:
        '가느다란 목질 줄기에 5mm 내외의 작은 타원형 잎들이 빽빽하게 달리며, 품종에 따라 레몬 무늬나 은빛 잎을 가집니다.',
      colorPalette: ['#2D6A4F', '#84CC16', '#D8B4FE'],
      colorDescription: '차분한 짙은 녹색·노란 테두리 무늬 잎과 연보라 작은 꽃',
      scent: '따뜻하고 스파이시하며 흙·레몬 느낌이 감도는 깊은 티몰(Thymol) 허브 향입니다.',
      scentIntensity: '강함',
      sizeAndGrowth: '키 15~30cm, 포복성으로 아담하게 퍼짐',
      bloomingSeason: '늦봄~초여름(5~7월)',
      petSafety: '강아지와 고양이에게 독성이 없는 안전한 식용 허브입니다.',
    },
    careGuide: {
      watering:
        '지중해 건조 지대 식물이라 겉흙이 완전히 마른 뒤 물을 줍니다. 장마철 과습에 약합니다.',
      wateringCycle: '봄~가을 4~6일에 1회 · 겨울 7~10일에 1회',
      sunlight: '하루 5시간 이상의 직사광선과 바람이 잘 통하는 창가·베란다가 필수입니다.',
      temperature: '15~24°C 적정 · 추위에도 강해 노지 월동 가능',
      humidity: '35~50% 건조하고 쾌적한 환경 선호',
      soil: '모래와 마사토 비율이 높은 배수성 토양(상토 5 : 마사토 5)을 씁니다.',
      fertilizer: '척박한 곳에서도 잘 자라 봄철 소량의 유기질 비료면 충분합니다.',
      pruningAndRepotting:
        '요리에 쓰기 위해 윗가지를 수시로 잘라주면 통풍이 좋아지고 새 잎이 풍성해집니다.',
      commonIssues:
        '물빠짐이 나쁘면 아래 줄기가 까맣게 썩을 수 있으므로 배수 구멍이 큰 토분을 추천합니다.',
    },
    funFact:
      '고대 그리스에서는 용기의 상징으로 여겨져 기사들이 출정할 때 타임 가지를 옷에 수놓아 주었습니다.',
  },
  {
    id: 'matricaria-chamomilla',
    nameKo: '캐모마일 (카밀레)',
    nameEn: 'German Chamomile',
    scientificName: 'Matricaria chamomilla',
    family: '국화과 (Asteraceae)',
    category: '허브·방향식물',
    origin: '유럽 · 서아시아',
    difficulty: '보통',
    summary:
      '미니 데이지를 닮은 하얀 꽃잎과 노란 꽃심에서 잘 익은 사과처럼 달콤하고 포근한 향기가 피어나는 대표 허브티 식물입니다.',
    imageUrl: IMG_HERB,
    characteristics: {
      appearance:
        '하늘하늘한 깃털처럼 가늘게 갈라진 초록 잎 사이로 볼록한 노란 중앙과 하얀 꽃잎을 가진 작은 꽃들이 피어납니다.',
      colorPalette: ['#FACC15', '#FFFFFF', '#22C55E'],
      colorDescription: '맑은 순백색 꽃잎, 따뜻한 개나리 노란 꽃심, 가느다란 초록 잎',
      scent: '꽃봉오리에서 풋사과를 베어 문 듯 달콤하고 마음을 편안하게 가라앉히는 사과·허브 향이 납니다.',
      scentIntensity: '은은함~강함 (꽃에서 진하게 발향)',
      sizeAndGrowth: '키 25~60cm',
      bloomingSeason: '봄~초여름(5~7월)',
      petSafety: '대부분 안전하나 국화과 알레르기가 있는 경우 다량 섭취는 피합니다.',
    },
    careGuide: {
      watering:
        '겉흙이 마르면 흠뻑 주되 물고임은 피합니다. 꽃이 피기 시작하면 물 소모가 늘어납니다.',
      wateringCycle: '봄~가을 3~5일에 1회',
      sunlight: '풍부한 햇빛과 통풍이 있어야 줄기가 튼튼하게 서고 꽃이 많이 핍니다.',
      temperature: '15~22°C의 선선한 봄 날씨를 좋아합니다.',
      humidity: '40~55% 쾌적한 공기 순환 환경 선호',
      soil: '배수가 잘되는 일반 원예 상토 + 펄라이트(7:3)를 사용합니다.',
      fertilizer: '질소 비료를 너무 많이 주면 잎만 무성하고 꽃이 적게 피므로 소량만 줍니다.',
      pruningAndRepotting:
        '활짝 핀 꽃을 수확해서 말려두면 따뜻한 캐모마일 허브차로 즐길 수 있습니다.',
      commonIssues:
        '봄철 진딧물이 잘 꼬이므로 바람이 잘 통하는 곳에 두고 발견 시 즉시 씻어내세요.',
    },
    funFact:
      '그리스어로 "땅의 사과(Chamaimelon)"라는 뜻에서 이름이 유래했을 만큼 신선한 사과 향기가 특징입니다.',
  },
  {
    id: 'opuntia-microdasys',
    nameKo: '백도선 (토끼귀 선인장)',
    nameEn: 'Bunny Ears Cactus',
    scientificName: 'Opuntia microdasys',
    family: '선인장과 (Cactaceae)',
    category: '다육·선인장',
    origin: '멕시코 중부 사막',
    difficulty: '초보자 추천',
    summary:
      '납작하고 동그란 선인장 마디 두 개가 토끼 귀처럼 솟아오른 귀여운 형태에 하얀 솜털 같은 가시 점이 돋아난 매력적인 선인장입니다.',
    imageUrl: IMG_SUCCULENT,
    characteristics: {
      appearance:
        '타원형 손바닥 모양 줄기 위에 좌우로 새 줄기가 자라 토끼 귀 실루엣을 이루며, 표면에 보송한 흰 가시 다발이 규칙적으로 박혀 있습니다.',
      colorPalette: ['#4D7C0F', '#F8FAFC', '#84CC16'],
      colorDescription: '차분한 올리브 그린 바탕에 흰색(또는 노란색) 점무늬 가시',
      scent: '향기가 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '화분 기준 15~45cm, 천천히 귀가 늘어남',
      bloomingSeason: '성숙 시 드물게 노란 꽃이 핍니다.',
      petSafety: '겉보기에 보송해 보이지만 아주 미세한 잔가시(글로키드)가 피부에 박히기 쉬우므로 절대 맨손이나 동물이 만지지 않도록 주의하세요.',
    },
    careGuide: {
      watering:
        '흙 속까지 완전히 바싹 마른 뒤 한 달에 1~2회만 흠뻑 줍니다. 겨울엔 거의 주지 않아도 됩니다.',
      wateringCycle: '봄~가을 2~3주에 1회 · 겨울 한 달에 1회',
      sunlight: '하루 4~5시간 이상의 밝은 햇빛 아래에서 토끼 귀가 통통하고 짧게 예쁘게 자랍니다.',
      temperature: '15~30°C 적정 · 겨울철 5°C 이상 실내 보호',
      humidity: '건조한 실내(25~45%)가 최적입니다.',
      soil: '배수가 극대화된 선인장 전용토(마사토·난석·펄라이트 80% + 상토 20%)를 씁니다.',
      fertilizer: '봄~여름 성장기에 아주 묽은 선인장 비료를 1~2회만 줍니다.',
      pruningAndRepotting:
        '분갈이 시에는 두꺼운 고무장갑이나 집게를 이용해 미세 가시가 손에 닿지 않게 조심하세요.',
      commonIssues:
        '빛이 부족하면 토끼 귀가 가늘고 길게 웃자라며 휘어지므로 가장 밝은 창가에 두세요.',
    },
    funFact:
      '미키마우스나 토끼 귀를 닮은 실루엣 덕분에 책상 위 반려 선인장으로 가장 인기가 높습니다.',
  },
];
