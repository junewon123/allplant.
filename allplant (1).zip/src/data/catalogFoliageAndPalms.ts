import type { PlantProfile } from '../types/plant';

const IMG_FOLIAGE = '/src/assets/images/cat_foliage_monstera_1795403759928.jpg';
const IMG_PALM = '/src/assets/images/hero_botanical_conservatory_1795403760157.jpg';

export const FOLIAGE_AND_PALM_PLANTS: PlantProfile[] = [
  {
    id: 'monstera-deliciosa',
    nameKo: '몬스테라 델리시오사',
    nameEn: 'Swiss Cheese Plant',
    scientificName: 'Monstera deliciosa',
    family: '천남성과 (Araceae)',
    category: '관엽식물',
    origin: '멕시코 남부 · 중앙아메리카 열대우림',
    difficulty: '초보자 추천',
    summary:
      '성숙할수록 잎에 깊은 구멍과 갈라짐(천공)이 생기는 대표 실내 관엽식물로, 이국적인 존재감이 뚜렷합니다.',
    imageUrl: IMG_FOLIAGE,
    characteristics: {
      appearance:
        '크고 윤기 있는 하트형 잎이 자라며, 성장함에 따라 잎 가장자리가 깃털처럼 갈라지고 잎 내부에 타원형 구멍이 뚫립니다. 줄기에서 공중 뿌리가 자라 지지대를 타고 오릅니다.',
      colorPalette: ['#1B4332', '#2D6A4F', '#52B788'],
      colorDescription: '깊고 선명한 에메랄드빛 진녹색, 새순은 밝은 연두색',
      scent: '특별한 향이 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '실내 화분 기준 높이 1~2m 이상, 성장기(봄~가을)에 매우 빠르게 자람',
      bloomingSeason: '실내에서는 거의 개화하지 않으며, 성숙한 열대 환경에서 육수화서 꽃이 핍니다.',
      petSafety: '줄기와 잎 수액에 불용성 옥살산칼슘이 있어 강아지·고양이에게 독성이 있습니다.',
    },
    careGuide: {
      watering:
        '화분 겉흙에서 3~4cm 깊이까지 마른 것을 손가락으로 확인한 뒤, 화분 밑 구멍으로 물이 빠져나올 때까지 충분히 줍니다.',
      wateringCycle: '봄~가을 주 1회 · 겨울 10~14일에 1회',
      sunlight:
        '커튼을 거친 밝은 간접광에서 가장 건강하고 잎이 예쁘게 갈라집니다. 너무 어두우면 잎에 구멍이 생기지 않습니다.',
      temperature: '생육 적온 18~27°C · 겨울철 최소 13°C 이상 실내 유지',
      humidity: '50~70%의 다소 높은 공중 습도를 좋아하지만 일반 실내 습도에서도 잘 적응합니다.',
      soil: '배수가 잘되는 관엽용 배합토(상토 5 : 펄라이트 3 : 바크·마사토 2)를 추천합니다.',
      fertilizer: '봄부터 초가을까지 월 1~2회 묽게 탄 관엽식물용 액비를 줍니다.',
      pruningAndRepotting:
        '1~2년마다 봄철에 한 치수 큰 화분으로 분갈이합니다. 줄기가 처지면 코코봉 지지대를 세워 주세요.',
      commonIssues:
        '잎 끝이 누렇게 마르면 과습이나 건조, 잎 뒷면의 흰 가루는 깍지벌레나 응애 신호이므로 닦아내고 방제합니다.',
    },
    funFact:
      '열대우림의 강한 바람과 폭우를 통과시키기 위해 잎에 자연스럽게 구멍이 뚫리는 진화를 거쳤습니다.',
  },
  {
    id: 'pilea-peperomioides',
    nameKo: '필레아 페페로미오이데스',
    nameEn: 'Chinese Money Plant',
    scientificName: 'Pilea peperomioides',
    family: '쐐기풀과 (Urticaceae)',
    category: '관엽식물',
    origin: '중국 윈난성 · 쓰촨성 산악 지대',
    difficulty: '초보자 추천',
    summary:
      '동글납작한 동전 모양의 잎들이 가느다란 잎자루 끝에 달려 우산처럼 겹쳐 자라는 사랑스러운 실내 식물입니다.',
    imageUrl: IMG_FOLIAGE,
    characteristics: {
      appearance:
        '매끈하고 완만한 원형 잎 한가운데에 잎자루가 방패처럼 연결되어 있어 연꽃잎이나 팬케이크를 연상시킵니다.',
      colorPalette: ['#15803D', '#22C55E', '#86EFAC'],
      colorDescription: '맑고 선명한 애플그린~비취색 잎',
      scent: '향기가 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '높이 25~45cm의 아담한 테이블·선반용 크기',
      bloomingSeason: '성숙한 개체는 봄에 아주 작은 별 모양 꽃이 핍니다.',
      petSafety: '강아지와 고양이에게 독성이 없는 완전히 안전한 식물입니다.',
    },
    careGuide: {
      watering:
        '겉흙이 마르고 잎이 살짝 탄력을 잃어 처지는 느낌이 들 때 듬뿍 물을 줍니다.',
      wateringCycle: '봄~가을 5~7일에 1회 · 겨울 10~14일에 1회',
      sunlight:
        '밝은 간접광을 좋아합니다. 빛 방향으로 줄기가 굽는 성질이 강하므로 일주일에 한 번씩 화분을 돌려주세요.',
      temperature: '15~24°C 적정 · 겨울철 10°C 이상 유지',
      humidity: '40~60% 일반 실내 습도에서 잘 자랍니다.',
      soil: '가볍고 배수가 잘되는 관엽 배합토(상토 6 : 펄라이트 3 : 마사토 1)를 권장합니다.',
      fertilizer: '봄~가을 월 1회 묽은 액비를 주면 동글동글한 잎이 크게 자랍니다.',
      pruningAndRepotting:
        '흙 위로 올라오는 아기 필레아(자구)가 5cm 이상 자라면 봄에 분리해 새로운 화분에 심을 수 있습니다.',
      commonIssues:
        '빛이 너무 강하면 잎 가장자리가 안으로 말리고, 과습하면 아래 잎부터 떨어집니다.',
    },
    funFact:
      '1940년대 유럽 가정끼리 자구를 나누어 키우면서 "우정 식물(Friendship Plant)"이라는 별명을 얻었습니다.',
  },
  {
    id: 'goeppertia-orbifolia',
    nameKo: '칼라데아 오르비폴리아',
    nameEn: 'Prayer Plant (Calathea Orbifolia)',
    scientificName: 'Goeppertia orbifolia',
    family: '마란타과 (Marantaceae)',
    category: '관엽식물',
    origin: '볼리비아 열대우림',
    difficulty: '보통',
    summary:
      '손바닥보다 큰 둥근 잎 위로 은빛과 진녹색 줄무늬가 정교하게 그려져 있으며, 밤이면 잎을 오므리는 수면 운동을 합니다.',
    imageUrl: IMG_FOLIAGE,
    characteristics: {
      appearance:
        '풍성하고 넓은 부채꼴 원형 잎에 일정한 간격의 은백색 사선 줄무늬가 새겨져 있어 예술적인 무늬를 감상할 수 있습니다.',
      colorPalette: ['#166534', '#A7F3D0', '#D1FAE5'],
      colorDescription: '짙은 초록과 파스텔 민트·은빛의 조화로운 줄무늬',
      scent: '향기가 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '높이 40~80cm, 좌우로 풍성하게 잎이 펼쳐짐',
      bloomingSeason: '잎의 무늬를 주로 감상하는 대표 무늬 관엽식물입니다.',
      petSafety: '강아지·고양이에게 독성이 전혀 없는 100% 안전한 식물입니다.',
    },
    careGuide: {
      watering:
        '겉흙이 1~2cm 정도 말랐을 때 정수된 물이나 하루 받아둔 수돗물을 주는 것이 잎 끝 마름을 줄이는 데 좋습니다.',
      wateringCycle: '봄~가을 주 1~2회 · 겨울 7~10일에 1회',
      sunlight:
        '부드러운 반음지~간접광이 최적입니다. 강한 햇빛에 노출되면 은빛 줄무늬가 바랠 수 있습니다.',
      temperature: '18~26°C 적정 · 15°C 이하 찬 바람 주의',
      humidity: '60% 이상의 높은 습도를 좋아하므로 가습기 옆이나 주기적 분무가 도움 됩니다.',
      soil: '보습력이 좋은 피트모스·코코피트 기반 상토에 펄라이트를 섞어 통기성을 확보합니다.',
      fertilizer: '봄~가을 월 1회 아주 묽게 희석한 액비를 줍니다.',
      pruningAndRepotting:
        '누렇게 변하거나 끝이 마른 오래된 잎은 줄기 밑둥에서 깔끔히 잘라 새 잎에 에너지를 집중시킵니다.',
      commonIssues:
        '실내 공기가 건조하면 잎 끝이 갈색으로 타들어가고 응애가 발생하기 쉬우므로 습도 유지가 핵심입니다.',
    },
    funFact:
      '밤이 되면 잎을 하늘로 세우고 낮에 다시 펼치는 "기도 식물(Prayer Plant)" 습성이 있습니다.',
  },
  {
    id: 'ficus-elastica',
    nameKo: '인도고무나무 (멜라니·버건디)',
    nameEn: 'Rubber Plant',
    scientificName: 'Ficus elastica',
    family: '뽕나무과 (Moraceae)',
    category: '관엽식물',
    origin: '인도 북동부 · 동남아시아',
    difficulty: '초보자 추천',
    summary:
      '두툼하고 광택이 흐르는 타원형 잎과 붉은 잎눈(새순 껍질)이 매력적이며 공기정화 능력이 뛰어난 강건한 나무형 관엽식물입니다.',
    imageUrl: IMG_FOLIAGE,
    characteristics: {
      appearance:
        '굵고 단단한 목질 줄기 위로 두꺼운 가죽 질감의 큼직한 타원형 잎이 어긋나며, 새 잎은 붉은 포엽에 싸여 올라옵니다.',
      colorPalette: ['#14532D', '#3F2E3E', '#4D7C0F'],
      colorDescription: '광택 있는 진녹색·검붉은 버건디빛(품종에 따라 무늬 포함)',
      scent: '향기가 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '실내 화분 기준 70cm~2m 이상, 곧게 자람',
      bloomingSeason: '관엽 위주로 실내에서는 꽃을 보지 않습니다.',
      petSafety: '줄기의 흰 유액에 자극 성분이 있어 반려동물이 씹지 않도록 주의합니다.',
    },
    careGuide: {
      watering:
        '겉흙이 3~4cm 마른 것을 확인한 뒤 화분 밑으로 물이 나올 때까지 듬뿍 줍니다. 과습 시 아래 잎부터 떨어집니다.',
      wateringCycle: '봄~가을 주 1회 · 겨울 10~14일에 1회',
      sunlight:
        '밝은 간접광~반양지에서 잎 색감이 선명해집니다. 특히 버건디·무늬 품종은 빛이 부족하면 녹색으로 옅어집니다.',
      temperature: '16~27°C 적정 · 겨울철 10°C 이상 유지',
      humidity: '일반 실내 습도(40~60%)에 잘 적응하며 가끔 잎의 먼지를 젖은 천으로 닦아주세요.',
      soil: '배수가 잘되는 상토 6 : 펄라이트 2 : 마사토 2 혼합토를 사용합니다.',
      fertilizer: '봄~가을 1~2개월마다 관엽식물용 완효성 비료 또는 액비를 줍니다.',
      pruningAndRepotting:
        '원하는 높이에서 줄기를 자르면 곁가지가 나와 풍성한 수형을 만들 수 있습니다(수액이 손에 묻지 않게 장갑 착용).',
      commonIssues:
        '환경 변화(자리 이동, 급격한 온도 변화) 직후 잎을 몇 장 떨어뜨릴 수 있으나 안정되면 금세 회복합니다.',
    },
    funFact:
      '과거 천연고무(라텍스)를 채취하던 수종 중 하나로, 실내 포름알데히드 제거 능력이 우수합니다.',
  },
  {
    id: 'ficus-lyrata',
    nameKo: '떡갈고무나무',
    nameEn: 'Fiddle-Leaf Fig',
    scientificName: 'Ficus lyrata',
    family: '뽕나무과 (Moraceae)',
    category: '관엽식물',
    origin: '서아프리카 열대우림',
    difficulty: '보통',
    summary:
      '바이올린처럼 넓고 물결치는 큼직한 잎이 인상적이어서 모던 인테리어의 대표 플랜테리어 수종으로 꼽힙니다.',
    imageUrl: IMG_FOLIAGE,
    characteristics: {
      appearance:
        '길이 25~40cm에 달하는 넓은 주걱·바이올린 모양의 잎이 주름진 잎맥과 함께 풍성하게 펼쳐집니다.',
      colorPalette: ['#1B4332', '#2D6A4F', '#65A30D'],
      colorDescription: '선명한 진녹색 잎과 연녹색 잎맥',
      scent: '특별한 향이 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '실내 기준 1~2.5m까지 크게 자라는 대형 관엽수',
      bloomingSeason: '실내에서는 잎의 조형미를 감상합니다.',
      petSafety: '줄기 수액에 자극 성분이 있어 반려동물 접촉에 주의합니다.',
    },
    careGuide: {
      watering:
        '겉흙이 3~5cm 정도 마르면 듬뿍 주되 화분 받침에 고인 물은 바로 비워 뿌리 호흡을 지켜주세요.',
      wateringCycle: '봄~가을 7~10일에 1회 · 겨울 2주에 1회',
      sunlight:
        '창문을 거친 밝은 간접광과 통풍을 좋아합니다. 자리를 자주 옮기면 스트레스로 잎을 떨어뜨립니다.',
      temperature: '18~26°C 적정 · 겨울철 12°C 이상 유지',
      humidity: '50~65% 선호 · 겨울철 난방 시 잎에 분무해 주면 좋습니다.',
      soil: '배수가 빠른 관엽용 흙(상토 5 : 펄라이트 3 : 바크 2)을 추천합니다.',
      fertilizer: '봄~여름 성장기에 월 1회 관엽용 액비를 공급합니다.',
      pruningAndRepotting:
        '2년에 한 번 봄에 분갈이하고, 잎이 너무 한쪽으로 쏠리면 주기적으로 화분을 돌려 빛을 고루 받게 합니다.',
      commonIssues:
        '잎에 갈색 반점이 번지면 과습 또는 뿌리썩음 신호이므로 물 주기를 늘리고 통풍을 강화하세요.',
    },
    funFact:
      '잎 모양이 바이올린(Fiddle)을 닮아 영어로 "Fiddle-Leaf Fig"라는 이름이 붙었습니다.',
  },
  {
    id: 'strelitzia-nicolai',
    nameKo: '여인초 (극락조화)',
    nameEn: 'White Bird of Paradise',
    scientificName: 'Strelitzia nicolai',
    family: '극락조화과 (Strelitziaceae)',
    category: '관엽식물',
    origin: '남아프리카 해안 아열대 지역',
    difficulty: '초보자 추천',
    summary:
      '바나나 잎처럼 길고 웅장한 부채꼴 잎이 시원하게 뻗어 공간에 열대 리조트 같은 분위기를 선사하는 대형 식물입니다.',
    imageUrl: IMG_FOLIAGE,
    characteristics: {
      appearance:
        '긴 잎자루 끝에 크고 넓은 타원형 잎이 양쪽으로 펼쳐지며, 바람을 통과시키기 위해 잎맥을 따라 자연스럽게 갈라지기도 합니다.',
      colorPalette: ['#14532D', '#166534', '#4ADE80'],
      colorDescription: '묵직하고 시원한 진녹색~청록빛 잎',
      scent: '향기가 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '실내 1.2~2.5m 이상 크게 자람',
      bloomingSeason: '실내 화분에서는 꽃이 드물지만, 성숙 시 흰색·남색 새 부리 모양 꽃이 핍니다.',
      petSafety: '강아지·고양이가 섭취 시 가벼운 위장 자극이 있을 수 있습니다.',
    },
    careGuide: {
      watering:
        '큰 잎으로 수분 증발이 활발하므로 겉흙이 마르면 듬뿍 줍니다. 겨울에는 물 주기를 줄여 뿌리 무름을 막습니다.',
      wateringCycle: '봄~가을 5~7일에 1회 · 겨울 10~14일에 1회',
      sunlight:
        '밝은 햇빛(반양지~양지)을 매우 좋아합니다. 거실 창가 바로 앞이 가장 이상적입니다.',
      temperature: '18~28°C 적정 · 겨울철 10°C 이상 실내 관리',
      humidity: '50% 내외 일반 실내 습도에서도 잘 자라며 먼지가 쌓이면 잎을 닦아 주세요.',
      soil: '단단하게 뿌리를 지지할 수 있도록 상토 6 : 마사토·펄라이트 4 비율로 배합합니다.',
      fertilizer: '봄~초가을까지 월 1~2회 관엽용 비료를 주면 큼직한 새 잎이 힘차게 올라옵니다.',
      pruningAndRepotting:
        '갈라진 잎은 자연스러운 현상이므로 자르지 않아도 되며, 누렇게 수명을 다한 바깥쪽 잎만 밑둥에서 정리합니다.',
      commonIssues:
        '빛이 부족하면 줄기가 약하게 웃자라며 옆으로 힘없이 벌어질 수 있습니다.',
    },
    funFact:
      '잎이 바람에 의해 자연스럽게 찢어지는 이유는 강한 해풍에 줄기가 부러지는 것을 방지하기 위한 생존 전략입니다.',
  },
  {
    id: 'epipremnum-aureum',
    nameKo: '스킨답서스 (포토스)',
    nameEn: 'Golden Pothos',
    scientificName: 'Epipremnum aureum',
    family: '천남성과 (Araceae)',
    category: '공기정화·야자',
    origin: '프랑스령 폴리네시아 모레아섬',
    difficulty: '초보자 추천',
    summary:
      '하트 모양 잎에 황금빛·연두빛 대리석 무늬가 들어가며, 물꽂이부터 반음지 실내까지 어디서나 씩씩하게 자라는 덩굴 식물입니다.',
    imageUrl: IMG_PALM,
    characteristics: {
      appearance:
        '매끈한 하트형 잎이 긴 덩굴 줄기를 따라 이어지며, 선반 위에서 아래로 늘어뜨리거나 행잉 플랜트로 연출하기 좋습니다.',
      colorPalette: ['#15803D', '#84CC16', '#FEF08A'],
      colorDescription: '짙은 녹색 바탕에 노랑·크림·연두빛 무늬',
      scent: '향기가 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '덩굴 길이 1~3m 이상, 성장 속도가 빠름',
      bloomingSeason: '관엽 및 공기정화용 덩굴 식물입니다.',
      petSafety: '옥살산칼슘이 있어 강아지·고양이에게 독성이 있습니다.',
    },
    careGuide: {
      watering:
        '겉흙이 마른 뒤 흠뻑 줍니다. 물이 부족하면 잎이 살짝 돌돌 말리며 신호를 보내어 초보자도 타이밍을 알기 쉽습니다.',
      wateringCycle: '봄~가을 5~7일에 1회 · 겨울 10일에 1회',
      sunlight:
        '어두운 실내에서도 버틸 정도로 적응력이 높지만, 밝은 간접광에서 무늬가 훨씬 선명해집니다.',
      temperature: '15~28°C 적정 · 겨울철 10°C 이상 유지',
      humidity: '일반 실내 습도(40~60%)에서 문제없이 자랍니다.',
      soil: '일반 관엽용 배합토 또는 수경재배(물꽂이)로도 아주 잘 자랍니다.',
      fertilizer: '봄~가을 1~2개월마다 묽은 액비를 주면 잎 크기가 커집니다.',
      pruningAndRepotting:
        '줄기가 너무 길어지면 마디 아래를 잘라 물에 꽂아 두면 금세 새 뿌리가 나와 쉽게 번식됩니다.',
      commonIssues:
        '과습 시 잎이 노랗게 변하므로 흙이 마른 것을 확인한 후 물을 주세요.',
    },
    funFact:
      '일산화탄소와 포름알데히드 제거 능력이 뛰어나 주방이나 침실, 사무실 책상 위 반려식물로 전 세계에서 가장 많이 길러집니다.',
  },
  {
    id: 'spathiphyllum-wallisii',
    nameKo: '스파트필름',
    nameEn: 'Peace Lily',
    scientificName: 'Spathiphyllum wallisii',
    family: '천남성과 (Araceae)',
    category: '공기정화·야자',
    origin: '콜롬비아 · 베네수엘라 열대우림',
    difficulty: '초보자 추천',
    summary:
      '짙은 초록 잎 사이로 순백색 고깔 모양 꽃(불염포)이 우아하게 피어나며, 암모니아·벤젠 등 실내 유해가스를 정화합니다.',
    imageUrl: IMG_PALM,
    characteristics: {
      appearance:
        '광택 있는 긴 타원형 잎이 빽빽한 다발을 이루고, 긴 꽃대 끝에 하얀 잎처럼 생긴 불염포와 연노랑 꽃이 피어납니다.',
      colorPalette: ['#FFFFFF', '#166534', '#FEF9C3'],
      colorDescription: '맑은 순백색 꽃포와 짙은 에메랄드 그린 잎',
      scent: '꽃이 피었을 때 아주 은은하고 맑은 풀·꽃 내음이 감돕니다.',
      scentIntensity: '은은함',
      sizeAndGrowth: '높이 35~70cm의 단정한 크기',
      bloomingSeason: '봄~가을 사이 빛이 적당하면 수시로 개화',
      petSafety: '옥살산칼슘이 있어 반려동물이 먹지 않도록 주의합니다.',
    },
    careGuide: {
      watering:
        '물을 좋아하는 편입니다. 겉흙이 마르면 충분히 주며, 목이 마르면 잎 전체가 축 처졌다가 물을 주면 몇 시간 내로 꼿꼿이 살아납니다.',
      wateringCycle: '봄~가을 3~5일에 1회 · 겨울 7~10일에 1회',
      sunlight:
        '실내 반음지~밝은 간접광에 완벽히 적응합니다. 직사광선은 잎을 태울 수 있으니 피하세요.',
      temperature: '18~26°C 적정 · 겨울철 12°C 이상 유지',
      humidity: '50~70%의 습한 공기를 좋아합니다.',
      soil: '보수력과 배수력이 균형 잡힌 관엽 상토 + 펄라이트(7:3)를 사용합니다.',
      fertilizer: '봄~여름 월 1회 개화용 또는 관엽용 묽은 액비를 주면 하얀 꽃대가 잘 올라옵니다.',
      pruningAndRepotting:
        '꽃이 시간이 지나 초록색으로 변하거나 시들면 꽃대 밑둥을 잘라 주세요.',
      commonIssues:
        '공기가 너무 건조하거나 비료가 과하면 잎 끝이 갈색으로 탈 수 있습니다.',
    },
    funFact:
      '하얀 꽃처럼 보이는 부분은 사실 꽃이 아니라 수술 꽃차례를 감싸 보호하는 "불염포"라는 특수한 잎입니다.',
  },
  {
    id: 'zamioculcas-zamiifolia',
    nameKo: '금전수 (자미오쿨카스)',
    nameEn: 'ZZ Plant',
    scientificName: 'Zamioculcas zamiifolia',
    family: '천남성과 (Araceae)',
    category: '공기정화·야자',
    origin: '동아프리카 탄자니아 · 케냐',
    difficulty: '초보자 추천',
    summary:
      '동전을 꿴 듯 매끈하고 반짝이는 잎이 줄기마다 규칙적으로 달리고, 어두운 실내와 가뭄에도 끄떡없는 개업·선물 1순위 식물입니다.',
    imageUrl: IMG_FOLIAGE,
    characteristics: {
      appearance:
        '땅속 감자 모양의 알뿌리(구근)에서 굵고 탄력 있는 줄기가 솟아오르며, 양쪽으로 왁스 광택이 나는 두꺼운 잎이 대칭으로 배열됩니다.',
      colorPalette: ['#14532D', '#15803D', '#4D7C0F'],
      colorDescription: '거울처럼 광택이 도는 진녹색 잎, 새순은 싱그러운 연녹색',
      scent: '향기가 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '높이 40~90cm, 천천히 단단하게 자람',
      bloomingSeason: '관엽 수형을 감상하는 상록 식물입니다.',
      petSafety: '잎과 줄기에 독성이 있어 반려동물과 어린이 손에 닿지 않게 둡니다.',
    },
    careGuide: {
      watering:
        '땅속 구근에 물을 가득 저장하고 있으므로 절대 자주 주지 마세요. 흙 속까지 완전히 마른 뒤 월 1~2회만 주어도 충분합니다.',
      wateringCycle: '봄~가을 2~3주에 1회 · 겨울 한 달에 1회',
      sunlight:
        '형광등만 있는 현관이나 사무실 반음지부터 밝은 간접광까지 어디서든 잘 자랍니다.',
      temperature: '18~26°C 적정 · 겨울철 12°C 이상 유지',
      humidity: '건조한 일반 실내 환경에 매우 강합니다.',
      soil: '물빠짐이 아주 좋은 마사토·펄라이트 비율이 높은 흙(상토 5 : 배수재 5)을 추천합니다.',
      fertilizer: '성장기인 봄~여름에 연 2~3회 아주 묽은 액비면 충분합니다.',
      pruningAndRepotting:
        '뿌리가 화분을 밀어낼 만큼 꽉 찼을 때 2~3년에 한 번만 분갈이하세요.',
      commonIssues:
        '금전수를 죽이는 거의 유일한 원인은 "과습"입니다. 잎이 노랗게 물러지면 물 주기를 즉시 멈추세요.',
    },
    funFact:
      '잎 모양이 엽전(동전)을 닮아 재물운을 불러온다는 의미에서 "금전수" 또는 "돈나무"로 불립니다.',
  },
  {
    id: 'dypsis-lutescens',
    nameKo: '아레카야자',
    nameEn: 'Areca Palm',
    scientificName: 'Dypsis lutescens',
    family: '종려과 (Arecaceae)',
    category: '공기정화·야자',
    origin: '마다가스카르 열대 지역',
    difficulty: '초보자 추천',
    summary:
      '가늘고 우아한 깃털 모양의 잎이 사방으로 퍼지며 실내 습도를 높이고 포름알데히드를 제거하는 NASA 선정 대표 공기정화식물입니다.',
    imageUrl: IMG_PALM,
    characteristics: {
      appearance:
        '대나무 마디처럼 뻗은 여러 줄기에서 아치형으로 휘어지는 가늘고 긴 깃털 잎이 시원하게 펼쳐집니다.',
      colorPalette: ['#4D7C0F', '#65A30D', '#A3E635'],
      colorDescription: '싱그럽고 밝은 연녹색~중간 초록빛 줄기와 잎',
      scent: '향기가 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '실내 1~2.2m, 비교적 꾸준히 새 잎을 올림',
      bloomingSeason: '실내에서는 관엽 수형 위주로 감상합니다.',
      petSafety: '강아지와 고양이 모두에게 완전히 안전한 무독성 식물입니다.',
    },
    careGuide: {
      watering:
        '증산 작용이 매우 활발해 수분 소모가 많은 편입니다. 겉흙이 마르면 미지근한 물로 듬뿍 주세요.',
      wateringCycle: '봄~가을 3~5일에 1회 · 겨울 주 1회',
      sunlight:
        '창문을 거친 밝은 간접광이 최적입니다. 강한 한여름 직사광선 아래에서는 잎이 누렇게 탈 수 있습니다.',
      temperature: '18~26°C 적정 · 겨울철 최소 13°C 이상 유지',
      humidity: '50~60% 선호 · 공기가 건조하면 잎 끝이 갈색으로 마르므로 자주 분무해 줍니다.',
      soil: '보수력과 배수력이 모두 좋은 관엽식물용 상토 + 펄라이트(7:3)를 사용합니다.',
      fertilizer: '봄~여름 사이 2개월마다 완효성 알비료나 묽은 액비를 공급합니다.',
      pruningAndRepotting:
        '갈변한 아래 잎이나 끝이 탄 잎만 소독된 가위로 사선 정리하고, 2년에 한 번 분갈이합니다.',
      commonIssues:
        '건조할 때 잎 뒷면에 응애가 잘 생기므로 주기적으로 잎을 닦아주고 분무해 예방합니다.',
    },
    funFact:
      '높이 1.8m 정도의 아레카야자 한 그루는 하루에 약 1리터의 수분을 공기 중에 내뿜는 천연 가습기 역할을 합니다.',
  },
  {
    id: 'chamaedorea-elegans',
    nameKo: '테이블야자',
    nameEn: 'Parlor Palm',
    scientificName: 'Chamaedorea elegans',
    family: '종려과 (Arecaceae)',
    category: '공기정화·야자',
    origin: '멕시코 · 과테말라 열대우림 하층부',
    difficulty: '초보자 추천',
    summary:
      '책상이나 테이블 위에 올려두기 알맞은 아담한 크기의 야자수로, 반음지에서도 씩씩하게 자라며 반려동물에게도 안전합니다.',
    imageUrl: IMG_PALM,
    characteristics: {
      appearance:
        '가느다란 대나무형 줄기 위에 섬세하고 부드러운 깃털 모양의 작은 잎들이 가지런히 달립니다.',
      colorPalette: ['#15803D', '#22C55E', '#4D7C0F'],
      colorDescription: '부드럽고 산뜻한 중간 녹색 잎',
      scent: '향기가 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '테이블용 30~80cm, 천천히 단정하게 자람',
      bloomingSeason: '드물게 좁쌀처럼 작은 노란 꽃이 피기도 합니다.',
      petSafety: '강아지와 고양이에게 독성이 없는 완전히 안전한 식물입니다.',
    },
    careGuide: {
      watering:
        '겉흙이 마르면 흠뻑 주며 수경재배나 흙 재배 모두 잘 적응합니다.',
      wateringCycle: '봄~가을 4~6일에 1회 · 겨울 7~10일에 1회',
      sunlight:
        '열대우림 큰 나무 아래에서 자라던 종이라 반음지나 실내 형광등 아래에서도 아주 잘 견딥니다.',
      temperature: '16~25°C 적정 · 겨울철 10°C 이상 유지',
      humidity: '50% 내외를 좋아하며 건조 시 잎 끝에 가끔 분무해 줍니다.',
      soil: '일반 관엽용 배합토에 펄라이트 20~30%를 섞어 배수를 돕습니다.',
      fertilizer: '봄~가을 2개월에 1회 아주 묽은 액비를 줍니다.',
      pruningAndRepotting:
        '뿌리가 예민한 편이므로 분갈이 시 뿌리를 심하게 털지 말고 그대로 큰 화분으로 옮기세요.',
      commonIssues:
        '직사광선에 오래 두면 잎 전체가 하얗고 누렇게 타버리니 반드시 그늘진 창가에 둡니다.',
    },
    funFact:
      '빅토리아 시대 유럽 거실(Parlor)을 장식하던 대표 실내 식물이라 영어로 "Parlor Palm"이라 불립니다.',
  },
  {
    id: 'hoya-carnosa',
    nameKo: '호야 카노사',
    nameEn: 'Wax Plant (Porcelain Flower)',
    scientificName: 'Hoya carnosa',
    family: '협죽도과 (Apocynaceae)',
    category: '공기정화·야자',
    origin: '동아시아 · 호주 열대 및 아열대',
    difficulty: '초보자 추천',
    summary:
      '도톰하고 왁스칠을 한 듯 매끈한 다육질 덩굴 잎 사이에서 별사탕 같은 분홍 꽃볼이 피며 밤에 달콤한 초콜릿·꿀 향이 납니다.',
    imageUrl: IMG_PALM,
    characteristics: {
      appearance:
        '두툼하고 반짝이는 타원형 잎이 긴 덩굴 줄기를 따라 마주나며, 성숙하면 우산 모양의 도자기 질감 별 꽃송이가 달립니다.',
      colorPalette: ['#FBCFE8', '#F472B6', '#166534'],
      colorDescription: '진주빛 연분홍·아이보리 별 꽃과 짙은 녹색 잎',
      scent: '꽃이 피는 저녁부터 새벽 사이에 진하고 달콤한 바닐라·밀크초콜릿·꿀 향을 풍깁니다.',
      scentIntensity: '은은함~강함 (개화 시 야간 발향)',
      sizeAndGrowth: '덩굴 길이 1~3m 이상, 행잉 플랜트나 지지대 연출에 적합',
      bloomingSeason: '늦봄~여름(5~8월)',
      petSafety: '강아지와 고양이에게 독성이 없는 안전한 식물입니다.',
    },
    careGuide: {
      watering:
        '다육성 잎에 수분을 저장하므로 흙이 바싹 마르고 잎이 미세하게 유연해질 때 듬뿍 줍니다.',
      wateringCycle: '봄~가을 7~10일에 1회 · 겨울 2~3주에 1회',
      sunlight:
        '밝은 간접광에서 무성하게 자라며, 꽃을 피우려면 아침 햇살이나 창가 밝은 빛이 꼭 필요합니다.',
      temperature: '18~26°C 적정 · 겨울철 10°C 이상 유지',
      humidity: '50~65%를 선호하나 일반 실내 습도에서도 매우 강건합니다.',
      soil: '아주 거칠고 배수 빠른 바크·펄라이트·상토 혼합토가 좋습니다.',
      fertilizer: '봄~여름 성장기에 개화용 묽은 액비를 월 1~2회 줍니다.',
      pruningAndRepotting:
        '꽃이 진 자리의 꽃대는 자르지 마세요! 다음 해에 정확히 그 꽃대에서 다시 꽃이 핍니다.',
      commonIssues:
        '화분이 너무 크면 뿌리 확장에만 에너지를 써서 꽃이 잘 안 피므로 약간 비좁은 화분에서 키우세요.',
    },
    funFact:
      '꽃에서 맑고 달콤한 꿀방울이 맺히는 경우가 있으며, 한 번 생긴 꽃대는 매년 같은 자리에서 꽃을 피웁니다.',
  },
  {
    id: 'pachira-aquatica',
    nameKo: '파키라',
    nameEn: 'Money Tree',
    scientificName: 'Pachira aquatica',
    family: '아욱과 (Malvaceae)',
    category: '관엽식물',
    origin: '중앙아메리카 · 남아메리카 습지',
    difficulty: '초보자 추천',
    summary:
      '다섯 손가락을 펼친 듯 시원한 잎과 땋은 줄기 모양이 매력적이며 공기정화와 관리 용이성으로 사랑받는 실내 나무입니다.',
    imageUrl: IMG_FOLIAGE,
    characteristics: {
      appearance:
        '통통한 목질 줄기 꼭대기에 5~7장의 긴 타원형 작은 잎이 손바닥처럼 방사형으로 달립니다.',
      colorPalette: ['#15803D', '#22C55E', '#78350F'],
      colorDescription: '싱그러운 연두~진녹색 잎과 연한 갈색 목질 줄기',
      scent: '향기가 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '실내 화분 기준 40cm~1.8m',
      bloomingSeason: '관엽 나무 위주로 감상합니다.',
      petSafety: '강아지와 고양이에게 독성이 없는 안전한 식물입니다.',
    },
    careGuide: {
      watering:
        '줄기에 수분을 저장하므로 겉흙이 3~4cm 마르면 듬뿍 줍니다. 과습 시 줄기 밑둥이 물러질 수 있습니다.',
      wateringCycle: '봄~가을 7~10일에 1회 · 겨울 2주에 1회',
      sunlight: '밝은 간접광부터 반음지까지 폭넓게 적응합니다.',
      temperature: '18~26°C 적정 · 겨울철 12°C 이상 유지',
      humidity: '40~60% 일반 실내 환경에 잘 맞습니다.',
      soil: '배수가 잘되는 상토 + 펄라이트 + 마사토 혼합토를 사용합니다.',
      fertilizer: '봄~가을 월 1회 관엽식물용 묽은 액비를 줍니다.',
      pruningAndRepotting:
        '웃자란 가지는 봄철에 짧게 정리하면 새순이 다시 풍성하게 돋아납니다.',
      commonIssues:
        '물을 너무 자주 주어 줄기를 만졌을 때 푹신하게 들어가면 뿌리 과습을 의심해야 합니다.',
    },
    funFact:
      '줄기를 3~5가닥 땋아서 키우는 수형이 행운과 재물을 모은다고 하여 선물용으로 큰 인기를 얻었습니다.',
  },
  {
    id: 'dracaena-fragrans',
    nameKo: '행운목 (맛상게아나)',
    nameEn: 'Corn Plant',
    scientificName: 'Dracaena fragrans',
    family: '비짜루과 (Asparagaceae)',
    category: '공기정화·야자',
    origin: '아프리카 열대 지역',
    difficulty: '초보자 추천',
    summary:
      '굵은 통나무 줄기에서 옥수수 잎처럼 길고 윤기 나는 아치형 잎이 솟아오르며, 실내 공기를 정화하고 관리가 매우 수월합니다.',
    imageUrl: IMG_PALM,
    characteristics: {
      appearance:
        '곧게 선 굵은 목질 줄기 옆이나 끝에서 연두색·진녹색 줄무늬가 들어간 긴 리본 모양 잎들이 풍성하게 자랍니다.',
      colorPalette: ['#14532D', '#84CC16', '#78350F'],
      colorDescription: '진녹색 바탕 중앙에 밝은 연두빛 띠 무늬',
      scent: '평소에는 무향이지만 드물게 꽃이 피면 밤에 진하고 달콤한 꽃향기가 납니다.',
      scentIntensity: '거의 없음 (개화 시 강함)',
      sizeAndGrowth: '실내 기준 40cm~1.8m',
      bloomingSeason: '수년 이상 건강히 자라면 드물게 흰 꽃대가 올라옵니다.',
      petSafety: '사포닌 성분이 있어 반려동물이 잎을 씹지 않도록 주의합니다.',
    },
    careGuide: {
      watering:
        '겉흙이 마르면 듬뿍 주며 수경재배(물받침 얕게 담그기)로 키우는 경우 물을 주기적으로 갈아주세요.',
      wateringCycle: '봄~가을 7~10일에 1회 · 겨울 2주에 1회',
      sunlight:
        '실내 반음지~밝은 간접광에서 무늬가 가장 예쁩니다. 직사광선은 잎을 태울 수 있습니다.',
      temperature: '18~25°C 적정 · 겨울철 12°C 이상 유지',
      humidity: '50% 내외가 좋으며 건조 시 잎 끝 갈변을 막기 위해 가끔 분무해 주세요.',
      soil: '배수가 좋은 관엽용 상토 또는 굵은 마사토·수경재배 환경 모두 가능합니다.',
      fertilizer: '봄~가을 2개월에 1회 소량의 관엽용 비료를 줍니다.',
      pruningAndRepotting:
        '노화되어 누렇게 마른 아래 잎은 줄기에서 깔끔히 떼어내 주세요.',
      commonIssues:
        '수돗물의 불소나 건조함으로 잎 끝이 갈색으로 타면 끝부분만 잎 모양대로 가볍게 다듬어 줍니다.',
    },
    funFact:
      '수경재배로 통나무 토막에서 싹이 돋아나는 모습을 감상할 수 있어 가정에서 행운을 상징하는 식물로 애용됩니다.',
  },
  {
    id: 'nephrolepis-exaltata',
    nameKo: '보스턴고사리',
    nameEn: 'Boston Fern',
    scientificName: 'Nephrolepis exaltata',
    family: '줄고사리과 (Nephrolepidaceae)',
    category: '공기정화·야자',
    origin: '아메리카 · 아프리카 열대 습윤 숲',
    difficulty: '보통',
    summary:
      '풍성하게 아치를 그리며 늘어지는 레이스 같은 초록 잎이 특징이며, 실내 습도 조절과 포름알데히드 제거 능력이 최상위권입니다.',
    imageUrl: IMG_PALM,
    characteristics: {
      appearance:
        '가늘고 주름진 수많은 작은 잎이 깃털처럼 촘촘히 달려 사방으로 분수처럼 퍼집니다.',
      colorPalette: ['#16A34A', '#4ADE80', '#15803D'],
      colorDescription: '생기 넘치는 밝은 잔디빛 초록색',
      scent: '싱그러운 숲과 풀 내음이 은은하게 느껴집니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '폭 40~90cm, 행잉 바스켓에서 풍성하게 늘어짐',
      bloomingSeason: '포자로 번식하는 양치식물로 꽃은 피지 않습니다.',
      petSafety: '강아지와 고양이에게 독성이 없는 완전히 안전한 식물입니다.',
    },
    careGuide: {
      watering:
        '촉촉한 환경을 무척 좋아하므로 겉흙이 마르기 시작할 때 흠뻑 줍니다. 흙이 완전히 마르면 잎이 바스락거리며 떨어집니다.',
      wateringCycle: '봄~가을 2~4일에 1회 · 겨울 5~7일에 1회',
      sunlight: '반음지~부드러운 간접광이 최적입니다. 직사광선은 피하세요.',
      temperature: '16~24°C 적정 · 겨울철 10°C 이상 유지',
      humidity: '60% 이상의 습도를 좋아하며 분무기나 저면 물받침 자갈로 공중 습도를 높여주면 풍성해집니다.',
      soil: '보습력이 있는 피트모스 위주 상토에 펄라이트를 20% 정도 섞습니다.',
      fertilizer: '봄~여름 월 1회 아주 묽은 질소 위주 액비를 줍니다.',
      pruningAndRepotting:
        '안쪽에 마른 갈색 잎은 바로 잘라내어 통풍을 확보해야 새 순이 잘 올라옵니다.',
      commonIssues:
        '건조할 때 잎이 하얗게 바래며 가루처럼 떨어지므로 물 마름과 분무 관리가 가장 중요합니다.',
    },
    funFact:
      'NASA의 공기정화 실험에서 휘발성 유기화합물(특히 포름알데히드) 제거율 1위를 기록한 식물입니다.',
  },
  {
    id: 'hedera-helix',
    nameKo: '아이비 (잉글리시 아이비)',
    nameEn: 'English Ivy',
    scientificName: 'Hedera helix',
    family: '두릅나무과 (Araliaceae)',
    category: '관엽식물',
    origin: '유럽 · 서아시아 숲',
    difficulty: '초보자 추천',
    summary:
      '별 모양을 닮은 각진 잎이 덩굴을 타고 흐르며, 추위와 그늘에도 잘 견뎌 실내 벽면이나 선반 장식에 잘 어울립니다.',
    imageUrl: IMG_FOLIAGE,
    characteristics: {
      appearance:
        '3~5갈래로 각진 귀여운 단풍·별 모양 잎이 가느다란 덩굴 줄기마다 촘촘히 자랍니다.',
      colorPalette: ['#14532D', '#4D7C0F', '#F3F4F6'],
      colorDescription: '짙은 초록 또는 흰색·크림색 가장자리 무늬',
      scent: '향기가 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '덩굴 길이 50cm~3m, 뻗는 속도가 빠름',
      bloomingSeason: '실내에서는 덩굴 잎을 주로 감상합니다.',
      petSafety: '사포닌 성분이 있어 반려동물 섭취 시 주의가 필요합니다.',
    },
    careGuide: {
      watering:
        '겉흙이 마르면 흠뻑 줍니다. 흙 재배와 수경재배 모두 쉽게 자랍니다.',
      wateringCycle: '봄~가을 4~6일에 1회 · 겨울 7~10일에 1회',
      sunlight:
        '반음지~밝은 간접광이 좋으며 무늬 아이비는 빛이 어느 정도 있어야 흰 무늬가 유지됩니다.',
      temperature: '10~22°C의 다소 서늘한 환경을 좋아하며 추위에도 강합니다.',
      humidity: '50% 내외가 좋으며 여름철 고온 건조 시 응애 예방을 위해 잎 샤워를 자주 해주세요.',
      soil: '배수가 잘되는 일반 원예 상토 + 펄라이트 혼합토를 사용합니다.',
      fertilizer: '봄~가을 월 1회 묽은 액비를 줍니다.',
      pruningAndRepotting:
        '길게 자란 줄기를 잘라 물에 담가 두면 쉽게 뿌리가 내려 숱을 늘릴 수 있습니다.',
      commonIssues:
        '실내가 너무 덥고 건조하면 잎 뒷면에 응애가 잘 생기므로 서늘하고 통풍 좋은 곳에 두세요.',
    },
    funFact:
      '고대 그리스·로마에서는 승리와 영원한 우정, 신의를 상징해 월계관과 함께 장식에 쓰였습니다.',
  },
  {
    id: 'anthurium-andraeanum',
    nameKo: '안스리움',
    nameEn: 'Flamingo Flower',
    scientificName: 'Anthurium andraeanum',
    family: '천남성과 (Araceae)',
    category: '꽃·관화식물',
    origin: '콜롬비아 · 에콰도르 열대우림',
    difficulty: '초보자 추천',
    summary:
      '반짝이는 하트 모양의 붉은·분홍·흰색 꽃포가 한 번 피면 수개월간 시들지 않고 오래 유지되는 매력적인 열대 관화식물입니다.',
    imageUrl: IMG_FOLIAGE,
    characteristics: {
      appearance:
        '윤기 흐르는 진녹색 하트 잎 사이로 에나멜처럼 광택 나는 하트형 꽃포(불염포)와 뾰족한 꽃대가 올라옵니다.',
      colorPalette: ['#DC2626', '#F43F5E', '#14532D'],
      colorDescription: '선명한 다홍·분홍·백색·초콜릿색 꽃포와 짙은 녹색 잎',
      scent: '대부분 무향에 가깝습니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '높이 30~60cm, 연중 천천히 새 잎과 꽃을 올림',
      bloomingSeason: '온도와 빛이 맞으면 사계절 내내 꽃을 감상할 수 있습니다.',
      petSafety: '옥살산칼슘이 포함되어 반려동물이 씹지 않게 주의합니다.',
    },
    careGuide: {
      watering:
        '겉흙이 2~3cm 마르면 흠뻑 줍니다. 굵은 뿌리가 숨 쉴 수 있도록 과습은 피하세요.',
      wateringCycle: '봄~가을 5~7일에 1회 · 겨울 10일에 1회',
      sunlight:
        '밝은 간접광에서 꽃이 가장 오래가고 끊임없이 새 꽃대가 올라옵니다. 직사광선은 잎을 태웁니다.',
      temperature: '18~27°C 선호 · 겨울철 15°C 이상 따뜻한 실내 유지',
      humidity: '60% 이상의 촉촉한 습도를 좋아합니다.',
      soil: '통기성이 아주 뛰어난 바크·펄라이트·피트모스 혼합토(난용 배합 혼합)가 이상적입니다.',
      fertilizer: '봄~가을 월 1회 묽은 개화용 액비를 주면 연속 개화에 도움 됩니다.',
      pruningAndRepotting:
        '색이 바래 초록빛으로 변하거나 시든 꽃은 줄기 아래쪽에서 잘라주세요.',
      commonIssues:
        '겨울철 13°C 이하의 찬 바람을 맞으면 잎이 검게 변하며 냉해를 입기 쉽습니다.',
    },
    funFact:
      '안스리움 꽃은 한 번 피면 2~3개월 이상 싱싱하게 유지되어 생화 절화 및 실내 인테리어 화분으로 인기가 높습니다.',
  },
  {
    id: 'aglaonema-commutatum',
    nameKo: '아글라오네마 (스노우사파이어·엔젤)',
    nameEn: 'Chinese Evergreen',
    scientificName: 'Aglaonema commutatum',
    family: '천남성과 (Araceae)',
    category: '관엽식물',
    origin: '동남아시아 열대우림',
    difficulty: '초보자 추천',
    summary:
      '은백색·핑크빛·연두색 얼룩무늬가 수채화처럼 들어간 화려한 잎을 가졌으면서도 빛이 적은 실내에서 가장 잘 버티는 순한 식물입니다.',
    imageUrl: IMG_FOLIAGE,
    characteristics: {
      appearance:
        '넓고 뾰족한 타원형 잎이 다발로 풍성하게 올라오며, 품종에 따라 은빛·분홍·붉은색 무늬가 잎 전면에 퍼집니다.',
      colorPalette: ['#15803D', '#E2E8F0', '#FB7185'],
      colorDescription: '진녹색 바탕에 은백색·연분홍·레몬빛 무늬',
      scent: '향기가 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '높이 30~70cm, 단정하게 포기가 넓어짐',
      bloomingSeason: '관엽 무늬 위주로 감상합니다.',
      petSafety: '옥살산칼슘 성분이 있어 반려동물 접촉에 주의합니다.',
    },
    careGuide: {
      watering:
        '겉흙이 3cm 가량 마른 뒤 물을 충분히 줍니다. 과습하면 줄기가 물러질 수 있습니다.',
      wateringCycle: '봄~가을 주 1회 · 겨울 10~14일에 1회',
      sunlight:
        '반음지~밝은 간접광에 매우 강합니다. 붉거나 흰 무늬가 많은 품종은 밝은 간접광에서 색이 더 선명합니다.',
      temperature: '18~26°C 선호 · 추위에 약하므로 겨울철 13~15°C 이상 유지',
      humidity: '50~65% 선호 · 일반 실내에서도 잘 자랍니다.',
      soil: '배수가 빠른 관엽 배합토(상토 6 : 펄라이트 3 : 마사토 1)를 씁니다.',
      fertilizer: '봄~가을 월 1회 묽은 관엽용 액비를 줍니다.',
      pruningAndRepotting:
        '오래된 아래 잎이 누렇게 되면 떼어내고, 포기나누기로 쉽게 번식할 수 있습니다.',
      commonIssues:
        '겨울철 창가 냉기를 맞으면 잎이 처지고 물러지므로 추운 밤엔 거실 안쪽으로 들여주세요.',
    },
    funFact:
      '그리스어로 "빛나는 실"이라는 뜻을 지니고 있으며, 실제로 빛이 적은 환경에서도 잎 무늬가 환하게 빛납니다.',
  },
  {
    id: 'philodendron-birkin',
    nameKo: '필로덴드론 버킨',
    nameEn: 'Philodendron Birkin',
    scientificName: 'Philodendron Birkin',
    family: '천남성과 (Araceae)',
    category: '관엽식물',
    origin: '원예 교배종 (원종 남아메리카 열대)',
    difficulty: '초보자 추천',
    summary:
      '짙은 초록색 윤기 있는 잎 위에 하얀 핀스트라이프 줄무늬가 정교하게 그려진 세련된 미니 관엽식물입니다.',
    imageUrl: IMG_FOLIAGE,
    characteristics: {
      appearance:
        '도톰하고 둥근 하트 모양 잎이 방사형으로 돋아나며, 새 잎은 거의 흰색이나 크림색에 가까운 무늬로 나와 점차 초록 줄무늬로 자리 잡습니다.',
      colorPalette: ['#14532D', '#F8FAFC', '#4ADE80'],
      colorDescription: '에메랄드 진녹색 잎과 선명한 아이보리·화이트 사선 줄무늬',
      scent: '향기가 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '높이 25~50cm의 콤팩트한 크기',
      bloomingSeason: '관엽 잎 무늬를 감상하는 식물입니다.',
      petSafety: '옥살산칼슘 성분이 있어 반려동물 섭취에 주의합니다.',
    },
    careGuide: {
      watering:
        '겉흙이 2~3cm 말랐을 때 흠뻑 줍니다. 과습 시 줄기가 무를 수 있으니 물 빠짐을 확인하세요.',
      wateringCycle: '봄~가을 7일 간격 · 겨울 10~14일 간격',
      sunlight:
        '밝은 간접광에서 가장 또렷한 흰색 핀스트라이프 무늬가 발현됩니다.',
      temperature: '18~26°C 적정 · 겨울철 13°C 이상 유지',
      humidity: '50~65% 선호 · 일반 실내에서도 잘 자랍니다.',
      soil: '공기 순환이 좋은 상토 5 : 펄라이트 3 : 바크 2 혼합토가 좋습니다.',
      fertilizer: '봄~가을 월 1회 묽은 관엽용 액비를 공급합니다.',
      pruningAndRepotting:
        '가끔 초록색과 무늬가 반반 섞이거나 완전히 초록색인 "리버트" 잎이 나올 수 있는 것도 매력입니다.',
      commonIssues:
        '빛이 너무 어두우면 흰 줄무늬가 점차 옅어지므로 밝은 창가 근처로 옮겨 주세요.',
    },
    funFact:
      '에르메스 버킨백처럼 고급스럽고 희소성 있는 무늬를 가졌다고 해서 "버킨(Birkin)"이라는 이름이 붙었습니다.',
  },
  {
    id: 'alocasia-frydek',
    nameKo: '알로카시아 프라이덱 (그린벨벳)',
    nameEn: 'Green Velvet Alocasia',
    scientificName: 'Alocasia micholitziana Frydek',
    family: '천남성과 (Araceae)',
    category: '관엽식물',
    origin: '필리핀 루손섬 열대우림',
    difficulty: '세심한 관리 필요',
    summary:
      '벨벳처럼 보송보송하고 짙은 초록빛 화살촉 잎 위에 선명한 하얀 잎맥이 도드라져 보이는 고급스러운 관엽식물입니다.',
    imageUrl: IMG_FOLIAGE,
    characteristics: {
      appearance:
        '매트한 벨벳 질감의 긴 화살·방패 모양 잎과 순백색에 가까운 굵은 잎맥의 색 대비가 극적입니다.',
      colorPalette: ['#064E3B', '#F8FAFC', '#16A34A'],
      colorDescription: '벨벳 질감의 딥 포레스트 그린과 대비되는 밝은 흰 잎맥',
      scent: '향기가 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '높이 40~80cm, 구근(알뿌리)에서 새 잎이 교체되며 자람',
      bloomingSeason: '관엽 잎을 주로 감상합니다.',
      petSafety: '옥살산칼슘 성분이 있어 반려동물 접촉에 주의합니다.',
    },
    careGuide: {
      watering:
        '구근 식물이라 과습에 취약합니다. 겉흙이 3~4cm 마른 뒤 미지근한 물로 줍니다.',
      wateringCycle: '봄~가을 5~7일에 1회 · 겨울 10~14일에 1회',
      sunlight: '밝은 간접광과 부드러운 통풍을 좋아합니다. 직사광선은 벨벳 잎을 태웁니다.',
      temperature: '20~27°C의 따뜻한 온도 선호 · 겨울철 15°C 이상 유지',
      humidity: '60~75%의 높은 습도를 좋아하지만 잎 표면에 물이 고이지 않도록 주의하세요.',
      soil: '배수가 매우 빠른 바크·펄라이트·상토 혼합토가 필수입니다.',
      fertilizer: '봄~여름 성장기에 2~3주 간격으로 묽은 액비를 줍니다.',
      pruningAndRepotting:
        '알로카시아는 새 잎이 나면서 가장 오래된 잎 1장이 자연스럽게 누렇게 지는 특성이 있습니다.',
      commonIssues:
        '건조한 실내에서 응애가 가장 자주 생기는 종 중 하나이므로 잎 뒷면을 수시로 살펴보세요.',
    },
    funFact:
      '벨벳 질감 덕분에 빛을 반사하지 않고 흡수해 어떤 관엽식물보다 깊고 묵직한 초록빛을 띱니다.',
  },
  {
    id: 'dieffenbachia',
    nameKo: '디펜바키아 (트로픽스노우)',
    nameEn: 'Dumb Cane',
    scientificName: 'Dieffenbachia seguine',
    family: '천남성과 (Araceae)',
    category: '관엽식물',
    origin: '카리브해 · 남아메리카 열대',
    difficulty: '초보자 추천',
    summary:
      '큼직한 잎 중앙을 눈이 내린 듯 화려한 크림색·연두색 얼룩무늬가 채우고 있어 실내 분위기를 환하게 밝혀주는 식물입니다.',
    imageUrl: IMG_FOLIAGE,
    characteristics: {
      appearance:
        '굵고 다육질의 직립 줄기 위로 크고 넓은 타원형 잎이 풍성하게 솟아오릅니다.',
      colorPalette: ['#166534', '#ECFCCB', '#84CC16'],
      colorDescription: '짙은 녹색 테두리와 크림·연두빛 대리석 무늬 중앙',
      scent: '향기가 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '실내 50cm~1.3m',
      bloomingSeason: '관엽 무늬를 감상하는 식물입니다.',
      petSafety: '수액에 강한 독성(옥살산칼슘)이 있으므로 반려동물과 어린이가 닿지 않게 하고 가지치기 시 장갑을 낍니다.',
    },
    careGuide: {
      watering:
        '겉흙이 2~3cm 마르면 흠뻑 줍니다. 줄기에 수분을 저장하므로 과습만 피하면 매우 튼튼합니다.',
      wateringCycle: '봄~가을 주 1회 · 겨울 10~14일에 1회',
      sunlight: '밝은 간접광에서 크림색 무늬가 가장 화려하고 풍성하게 유지됩니다.',
      temperature: '18~26°C 적정 · 겨울철 13°C 이상 유지',
      humidity: '50% 내외 일반 실내 습도에 잘 적응합니다.',
      soil: '배수가 잘되는 일반 관엽식물 배합토를 사용합니다.',
      fertilizer: '봄~가을 월 1회 관엽용 액비를 공급합니다.',
      pruningAndRepotting:
        '오래된 아래 잎을 떼어내면 줄기가 목질화되면서 야자수처럼 시원한 수형이 됩니다.',
      commonIssues:
        '분갈이나 잎 정리 후에는 반드시 손을 씻어 수액이 눈이나 입에 닿지 않도록 합니다.',
    },
    funFact:
      '19세기 오스트리아 쇤브룬 궁전의 수석 정원사 요제프 디펜바흐의 이름에서 학명이 유래했습니다.',
  },
  {
    id: 'ficus-benghalensis',
    nameKo: '뱅갈고무나무',
    nameEn: 'Banyan Fig',
    scientificName: 'Ficus benghalensis',
    family: '뽕나무과 (Moraceae)',
    category: '관엽식물',
    origin: '인도 · 스리랑카',
    difficulty: '초보자 추천',
    summary:
      '우유를 탄 듯 부드러운 연두·파스텔 잎과 하얀 곡선형 목질 줄기가 조화되어 내추럴·화이트톤 인테리어에 가장 잘 어울리는 나무입니다.',
    imageUrl: IMG_FOLIAGE,
    characteristics: {
      appearance:
        '매끄러운 밝은 베이지·회백색 줄기 위로 보송한 짧은 털이 있는 도톰한 타원형 잎이 풍성하게 달립니다.',
      colorPalette: ['#65A30D', '#BEF264', '#D6D3D1'],
      colorDescription: '부드러운 라임·세이지 그린 잎과 선명한 노란빛 잎맥',
      scent: '향기가 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '실내 60cm~2m 이상',
      bloomingSeason: '사계절 내내 잎과 수형을 감상합니다.',
      petSafety: '흰 유액이 있어 반려동물이 잎을 씹지 않도록 주의합니다.',
    },
    careGuide: {
      watering:
        '겉흙이 3~4cm 마르면 흠뻑 줍니다. 잎이 많을수록 물 소모가 빠르므로 흙 상태를 만져보고 결정하세요.',
      wateringCycle: '봄~가을 5~7일에 1회 · 겨울 10~14일에 1회',
      sunlight:
        '밝은 간접광이나 반양지를 좋아합니다. 햇빛이 충분할수록 특유의 밝은 연두빛 잎이 살아납니다.',
      temperature: '18~26°C 적정 · 겨울철 10°C 이상 유지',
      humidity: '40~60% 일반 실내 환경에 잘 적응합니다.',
      soil: '배수가 빠른 관엽 배합토(상토 6 : 펄라이트 2 : 마사토 2)를 씁니다.',
      fertilizer: '봄~가을 월 1회 관엽용 비료를 줍니다.',
      pruningAndRepotting:
        '수형을 위해 윗가지를 잘라주면 옆으로 가지가 뻗어 풍성한 나무 모양이 됩니다.',
      commonIssues:
        '통풍이 부족한 실내에서 잎 뒷면에 깍지벌레나 응애가 생길 수 있으므로 가끔 잎을 닦아주세요.',
    },
    funFact:
      '인도에서는 신성한 나무로 여겨지며, 자연에서는 공중 뿌리가 땅에 닿아 기둥처럼 자라 숲 하나를 이룰 만큼 크게 자랍니다.',
  },
  {
    id: 'calathea-makoyana',
    nameKo: '칼라데아 마코야나 (공작야자)',
    nameEn: 'Peacock Plant',
    scientificName: 'Goeppertia makoyana',
    family: '마란타과 (Marantaceae)',
    category: '관엽식물',
    origin: '브라질 동부 열대우림',
    difficulty: '보통',
    summary:
      '연녹색 잎 앞면에 붓으로 그린 듯한 짙은 초록 깃털 무늬가 있고, 잎 뒷면은 붉은 자주빛을 띠는 화려한 공작 깃털 식물입니다.',
    imageUrl: IMG_FOLIAGE,
    characteristics: {
      appearance:
        '타원형의 얇고 우아한 잎 앞면에는 대칭 깃털 얼룩이, 뒷면에는 와인·자주색 색감이 도는 이중 매력이 있습니다.',
      colorPalette: ['#15803D', '#A7F3D0', '#701A75'],
      colorDescription: '연두·진녹색 공작 무늬 앞면과 자주빛 뒷면',
      scent: '향기가 없는 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '높이 30~60cm',
      bloomingSeason: '잎의 무늬를 감상하는 식물입니다.',
      petSafety: '강아지와 고양이에게 독성이 없는 완전히 안전한 식물입니다.',
    },
    careGuide: {
      watering:
        '겉흙이 마르기 시작할 때 정수된 물이나 하루 받아둔 물로 촉촉하게 유지해 줍니다.',
      wateringCycle: '봄~가을 주 1~2회 · 겨울 7~10일에 1회',
      sunlight: '반음지~부드러운 간접광이 최적입니다. 강한 직사광선을 피하세요.',
      temperature: '18~25°C 적정 · 15°C 이상 유지',
      humidity: '60% 이상의 습도를 좋아해 가습기 주변이나 분무 관리가 좋습니다.',
      soil: '보습과 통기가 조화로운 피트모스·펄라이트 배합토를 씁니다.',
      fertilizer: '봄~가을 월 1회 묽게 탄 액비를 줍니다.',
      pruningAndRepotting:
        '수명을 다한 아래 잎은 밑둥에서 잘라 새 잎이 자랄 공간을 열어줍니다.',
      commonIssues:
        '습도가 낮으면 잎 가장자리가 마르면서 돌돌 말리므로 분무를 자주 해주세요.',
    },
    funFact:
      '공작새의 꽁지깃을 펼쳐놓은 것 같은 잎 무늬 덕분에 "Peacock Plant(공작 식물)"로 불립니다.',
  },
];
