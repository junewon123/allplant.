import type { PlantProfile } from '../types/plant';

export const TRAIT_SPECIAL_COLOR_PLANTS: PlantProfile[] = [
  // Sky-Blue Plants (하늘색 식물)
  {
    id: 'nemophila-menziesii',
    nameKo: '네모필라 (베이비 블루 아이즈)',
    nameEn: 'Baby Blue Eyes',
    scientificName: 'Nemophila menziesii',
    family: '지치과',
    category: '꽃·관화식물',
    origin: '북아메리카 서부 (캘리포니아)',
    difficulty: '초보자 추천',
    summary:
      '맑은 봄 하늘을 그대로 옮겨 놓은 듯한 투명한 하늘색 꽃잎과 하얀 중심부가 어우러진 앙증맞은 초화류입니다.',
    imageUrl:
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/b/b9/Nemophila_menziesii_7794.JPG/960px-Nemophila_menziesii_7794.JPG',
    characteristics: {
      appearance:
        '가는 깃털처럼 갈라진 부드러운 연녹색 잎 사이로 지름 2~3cm의 둥글고 투명한 하늘색 다섯 꽃잎이 풍성하게 핍니다.',
      colorPalette: ['#6CB4EE', '#A7D8FF', '#FFFFFF'],
      colorDescription: '맑은 하늘색 꽃잎과 순백색 중심부, 부드러운 연녹색 잎',
      scent: '강한 향기는 없으나 가까이 다가가면 싱그러운 풀내음과 은은한 꽃향이 느껴집니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '키 15~25cm 정도로 낮게 옆으로 퍼지며 자라는 한해살이풀입니다.',
      bloomingSeason: '봄(3~6월) 시원한 기온에서 릴레이 개화합니다.',
      petSafety: '독성이 보고되지 않아 반려동물과 함께 키우기에 비교적 안전합니다.',
    },
    careGuide: {
      watering:
        '과습에 뿌리가 약하므로 겉흙이 마르면 잎에 닿지 않게 화분 가장자리로 듬뿍 줍니다.',
      wateringCycle: '봄·가을 주 2~3회 (겉흙이 마르면 충분히)',
      sunlight:
        '햇빛이 충분한 베란다 양지나 창가에서 꽃색이 선명해지고 웃자라지 않습니다.',
      temperature: '10~22°C의 서늘한 환경을 좋아하며 한여름 고온다습에 약합니다.',
      humidity: '통풍이 잘되는 보통 실내 습도(40~60%)가 적합합니다.',
      soil: '배수가 잘되는 상토에 펄라이트를 20% 정도 섞어 사용합니다.',
      fertilizer: '개화기 동안 2주에 1회 묽은 꽃 비료를 줍니다.',
      pruningAndRepotting:
        '시든 꽃을 바로 따주면 새 꽃봉오리가 계속 올라옵니다.',
      commonIssues:
        '통풍 부족과 고온 과습 시 줄기가 무르기 쉬우므로 바람이 잘 통하는 곳에 두세요.',
    },
    funFact:
      '영명 "베이비 블루 아이즈(Baby Blue Eyes)"는 맑고 순수한 아기의 푸른 눈동자를 닮은 하늘색 꽃에서 유래했습니다.',
  },
  {
    id: 'myosotis-sylvatica',
    nameKo: '물망초 (포겟 미 낫)',
    nameEn: 'Wood Forget-me-not',
    scientificName: 'Myosotis sylvatica',
    family: '지치과',
    category: '꽃·관화식물',
    origin: '유럽 및 아시아 온대 지역',
    difficulty: '초보자 추천',
    summary:
      '"나를 잊지 마세요"라는 꽃말로 유명한 작은 하늘색 꽃 식물로, 별 모양의 여린 하늘빛 꽃송이가 옹기종기 모여 핍니다.',
    imageUrl:
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/8/8a/Myosotis_sylvatica_03.jpg/960px-Myosotis_sylvatica_03.jpg',
    characteristics: {
      appearance:
        '부드러운 잔털이 있는 타원형 잎 위에서 가느다란 꽃대가 올라와 지름 1cm 내외의 파스텔 하늘색 꽃이 무리 지어 핍니다.',
      colorPalette: ['#73B9EE', '#BFE3FF', '#FACC15'],
      colorDescription: '파스텔 하늘색 꽃잎과 노란색 작은 꽃심, 짙은 초록 잎',
      scent: '저녁 무렵 가까이에서 맡으면 아주 은은하고 달큰한 꽃향기가 납니다.',
      scentIntensity: '은은함',
      sizeAndGrowth: '키 15~30cm 정도로 아담하게 무리지어 자랍니다.',
      bloomingSeason: '봄~초여름(4~6월)에 가장 풍성하게 개화합니다.',
      petSafety: '반려동물이 다량 섭취 시 가벼운 소화 불편을 일으킬 수 있어 주의합니다.',
    },
    careGuide: {
      watering:
        '수분을 좋아하는 편이라 겉흙이 마르기 직전에 촉촉하게 물을 줍니다.',
      wateringCycle: '봄·초여름 주 2~3회 (겉흙이 마르기 시작할 때)',
      sunlight: '부드러운 오전 직사광이나 밝은 반양지 창가가 이상적입니다.',
      temperature: '12~20°C의 선선한 기온을 선호하며 여름철 강한 더위는 피합니다.',
      humidity: '50~65%의 적당히 촉촉하고 통풍 좋은 환경을 좋아합니다.',
      soil: '보수력과 배수력이 균형 잡힌 일반 원예용 상토를 사용합니다.',
      fertilizer: '꽃눈이 맺힐 때 완효성 비료나 액비를 소량 공급합니다.',
      pruningAndRepotting:
        '꽃이 진 꽃대는 잘라내어 씨앗 결실로 인한 영양 소모를 줄여줍니다.',
      commonIssues:
        '건조하거나 통풍이 안 되면 흰가루병이 생길 수 있으니 환기에 신경 써주세요.',
    },
    funFact:
      '작은 다섯 꽃잎 가운데에 노란 링이 있어 하늘색 색감이 더욱 맑고 도드라져 보입니다.',
  },
  {
    id: 'plumbago-auriculata',
    nameKo: '플럼바고 (갯질경이 · 블루 플럼바고)',
    nameEn: 'Cape Leadwort',
    scientificName: 'Plumbago auriculata',
    family: '갯질경이과',
    category: '꽃·관화식물',
    origin: '남아프리카 공화국',
    difficulty: '초보자 추천',
    summary:
      '초여름부터 가을까지 시원한 하늘색 나팔 모양 꽃을 쉴 새 없이 피우는 덩굴성 관목으로, 여름 베란다 정원에 청량감을 더해줍니다.',
    imageUrl:
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/e/e1/Plumbago_auriculata_2718.jpg/960px-Plumbago_auriculata_2718.jpg',
    characteristics: {
      appearance:
        '부드럽게 아치를 그리며 뻗는 가지 끝에 수국을 닮은 둥근 꽃송이 형태로 맑은 하늘색 꽃이 주렁주렁 달립니다.',
      colorPalette: ['#87CEEB', '#5EA9DC', '#3F7D4C'],
      colorDescription: '청량한 하늘색·연파랑 꽃과 밝은 에메랄드 초록 잎',
      scent: '향기는 거의 없으나 시각적으로 매우 시원한 느낌을 줍니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '실내 화분에서는 50~120cm 크기로 수형을 다듬어 키우기 좋습니다.',
      bloomingSeason: '늦봄~가을(5~10월) 햇빛이 좋으면 끊임없이 꽃을 피웁니다.',
      petSafety: '잎과 꽃받침에 약한 자극 성분이 있을 수 있어 반려동물이 씹지 않도록 합니다.',
    },
    careGuide: {
      watering:
        '성장기에는 물을 꽤 좋아하므로 겉흙이 마르면 흠뻑 줍니다. 겨울에는 물주기를 줄입니다.',
      wateringCycle: '봄~가을 주 2~3회, 겨울 주 1회 이하',
      sunlight:
        '하루 4시간 이상 햇빛이 잘 드는 창가나 베란다 양지에서 꽃이 가장 풍성합니다.',
      temperature: '15~28°C에서 왕성히 자라며, 겨울에는 5°C 이상 실내로 들여 월동합니다.',
      humidity: '일반 실내 습도(40~60%)에서도 문제없이 잘 자랍니다.',
      soil: '배수가 잘되는 원예용 배양토에 마사토나 펄라이트를 20~30% 섞습니다.',
      fertilizer: '개화가 이어지는 봄~가을 사이 2~3주 간격으로 액비를 줍니다.',
      pruningAndRepotting:
        '꽃이 진 가지를 1/3 정도 다듬어주면 곁가지가 나오면서 꽃이 훨씬 많이 핍니다.',
      commonIssues:
        '빛이 부족하면 잎만 자라고 하늘색 꽃이 적게 피므로 최대한 밝은 곳에 배치하세요.',
    },
    funFact:
      '하늘색 꽃잎 뒤쪽 꽃받침에 끈적한 미세 털이 있어 꽃잎이 떨어진 뒤에도 오래 매달리는 독특한 특징이 있습니다.',
  },
  {
    id: 'delphinium-elatum',
    nameKo: '델피니움',
    nameEn: 'Delphinium',
    scientificName: 'Delphinium elatum',
    family: '미나리아재비과',
    category: '꽃·관화식물',
    origin: '유럽 및 시베리아 산악 지대',
    difficulty: '보통',
    summary:
      '길게 뻗은 꽃대 위로 투명한 하늘색과 청보라빛 꽃송이가 탑처럼 층층이 피어오르는 우아한 고급 화훼 식물입니다.',
    imageUrl:
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/a/a3/Delphinium_elatum_-_panoramio.jpg/960px-Delphinium_elatum_-_panoramio.jpg',
    characteristics: {
      appearance:
        '손바닥처럼 깊게 갈라진 잎 사이로 곧게 솟은 꽃대에 하늘색·아쿠아블루 겹꽃과 홑꽃이 수직으로 풍성하게 달립니다.',
      colorPalette: ['#60A5FA', '#93C5FD', '#2E5A36'],
      colorDescription: '선명한 하늘색·스카이블루 꽃잎과 흰색·암자빛 꽃심, 진녹색 잎',
      scent: '뚜렷한 발향은 적고 깔끔한 생화 내음이 납니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '소형 품종은 40~60cm, 대형 종은 1m 이상 시원하게 자랍니다.',
      bloomingSeason: '늦봄~초여름(5~7월)에 주로 개화합니다.',
      petSafety: '알칼로이드 독성이 있어 반려동물과 어린아이가 먹지 않도록 반드시 손이 닿지 않는 곳에 둡니다.',
    },
    careGuide: {
      watering:
        '과습으로 뿌리가 무르지 않게 겉흙이 마르면 아침 시간에 흠뻑 줍니다.',
      wateringCycle: '봄·초여름 주 2회 (배수가 잘되게 관리)',
      sunlight: '햇빛이 잘 들고 바람이 선선하게 통하는 베란다나 야외 정원이 좋습니다.',
      temperature: '10~22°C의 서늘한 기후를 좋아하며 한여름 열대야에는 약합니다.',
      humidity: '통풍이 원활한 40~55% 습도를 유지하세요.',
      soil: '배수가 뛰어나고 약알칼리성~중성을 띠는 비옥한 배합토가 적합합니다.',
      fertilizer: '봄철 새순이 자랄 때 완효성 비료를 소량 얹어줍니다.',
      pruningAndRepotting:
        '첫 꽃대가 시든 후 밑동을 잘라주면 조건이 맞을 때 2차 꽃대가 올라오기도 합니다.',
      commonIssues:
        '키가 커서 바람에 쓰러질 수 있으니 지지대를 세워주면 깔끔하게 감상할 수 있습니다.',
    },
    funFact:
      '학명 "델피니움(Delphinium)"은 피기 전 꽃봉오리의 모습이 돌고래를 닮았다고 해서 그리스어 돌고래(delphis)에서 붙었습니다.',
  },

  // Black / Deep Obsidian Plants (검은색 · 검정색 식물)
  {
    id: 'tacca-chantrieri',
    nameKo: '블랙 배트 플라워 (타카 찬트리에리)',
    nameEn: 'Black Bat Flower',
    scientificName: 'Tacca chantrieri',
    family: '마과',
    category: '꽃·관화식물',
    origin: '동남아시아 열대우림',
    difficulty: '세심한 관리 필요',
    summary:
      '박쥐가 날개를 펼친 듯한 신비로운 검은색·흑자색 꽃과 길게 늘어진 수염이 시선을 사로잡는 진귀한 블랙 플라워입니다.',
    imageUrl:
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/a/a9/Bat_Flower_or_Cat_Whiskers_%28Tacca_Chantrieri%29_%2849532732922%29.jpg/960px-Bat_Flower_or_Cat_Whiskers_%28Tacca_Chantrieri%29_%2849532732922%29.jpg',
    characteristics: {
      appearance:
        '큼직한 광택 초록 잎 사이로 흑자색에 가까운 진한 검은색 박쥐 날개 모양 포엽과 20~30cm 길이의 실 같은 꽃수염이 뻗어 나옵니다.',
      colorPalette: ['#1C1917', '#3B0764', '#1E3A2F'],
      colorDescription: '칠흑 같은 검은색·검정색 꽃포엽과 깊은 진녹색 잎',
      scent: '뚜렷한 꽃향기는 거의 없는 무향에 가깝습니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '실내 화분에서 키 50~90cm 정도로 존재감 있게 자랍니다.',
      bloomingSeason: '따뜻하고 습도가 충분한 여름~초가을(6~10월)에 개화합니다.',
      petSafety: '사포닌 성분이 있어 반려동물이 잎이나 뿌리를 먹지 않게 주의하세요.',
    },
    careGuide: {
      watering:
        '열대우림 하층부 식물이라 흙이 바짝 마르지 않도록 겉흙이 살짝 말랐을 때 충분히 줍니다.',
      wateringCycle: '봄~가을 주 2회, 겨울 주 1회',
      sunlight:
        '직사광선에 잎이 타기 쉬우므로 커튼을 거친 부드러운 반음지·간접광이 좋습니다.',
      temperature: '18~28°C의 따뜻한 실내를 좋아하며 겨울 최저 13°C 이상 유지합니다.',
      humidity: '65~80%의 높은 공중 습도를 선호하므로 가습기나 잎 주변 분무가 큰 도움이 됩니다.',
      soil: '난석·바크·피트모스·펄라이트를 섞어 통기성과 보수력이 동시에 좋은 흙을 씁니다.',
      fertilizer: '봄~가을 성장기에 월 1~2회 묽은 관엽·화훼 겸용 액비를 줍니다.',
      pruningAndRepotting:
        '노랗게 변한 아래 잎과 진 꽃대는 깨끗이 정리해 통풍을 확보합니다.',
      commonIssues:
        '공기가 너무 건조하면 잎 끝이 갈색으로 타들어가므로 습도 관리가 핵심입니다.',
    },
    funFact:
      '실제로 자연계에 완벽한 순수 검은 색소는 드물지만, 타카의 꽃은 안토시아닌 색소가 극도로 농축되어 눈으로 보기에 완벽한 검은색에 가깝습니다.',
  },
  {
    id: 'zamioculcas-zamiifolia-raven',
    nameKo: '블랙 레이븐 금전수 (레이븐 ZZ)',
    nameEn: 'Raven ZZ Plant',
    scientificName: 'Zamioculcas zamiifolia \'Raven\'',
    family: '천남성과',
    category: '관엽식물',
    origin: '동아프리카 원종 개량 품종 (한국 개량종 도원)',
    difficulty: '초보자 추천',
    summary:
      '처음에는 형광 연두색으로 새순이 올라왔다가 성숙하면서 매끈한 광택의 칠흑 같은 검은색 잎으로 물드는 세련된 블랙 인테리어 식물입니다.',
    imageUrl:
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/f/fe/Zamioculcas_zamiifolia_%27Dowon%27_vel_Raven_kz02.jpg/960px-Zamioculcas_zamiifolia_%27Dowon%27_vel_Raven_kz02.jpg',
    characteristics: {
      appearance:
        '두툼한 구근 위에서 대나무처럼 솟은 줄기 양옆으로 왁스 코팅한 듯 반짝이는 검은색·흑자빛 타원형 잎이 규칙적으로 배열됩니다.',
      colorPalette: ['#18181B', '#27272A', '#84CC16'],
      colorDescription: '광택 있는 칠흑 검은색·검정색 성엽과 라임 연두빛 새순의 대비',
      scent: '향이 전혀 없는 깔끔한 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '실내에서 40~80cm로 단정하게 자라며 성장 속도는 느린 편입니다.',
      bloomingSeason: '사계절 내내 강렬한 블랙 잎을 감상하는 식물입니다.',
      petSafety: '옥살산칼슘 결정이 있어 반려동물과 영유아가 먹지 않도록 주의합니다.',
    },
    careGuide: {
      watering:
        '뿌리에 수분을 저장하는 덩이줄기가 있어 과습을 가장 피해야 합니다. 속흙까지 완전히 말랐을 때 줍니다.',
      wateringCycle: '봄~가을 2~3주에 1회, 겨울 월 1회',
      sunlight:
        '어두운 반음지에서도 잘 견디지만 밝은 간접광에서 잎의 검은빛 발색이 훨씬 깊고 윤기가 납니다.',
      temperature: '16~26°C가 적당하며 겨울에는 10°C 이상 실내에서 월동합니다.',
      humidity: '건조한 실내에서도 거뜬히 자라며 별도 가습이 필요 없습니다.',
      soil: '배수가 매우 빠른 마사토·펄라이트 비율 40% 이상의 가벼운 배합토를 사용합니다.',
      fertilizer: '봄·여름에 두 달에 1회 묽게 주면 충분합니다.',
      pruningAndRepotting:
        '구근이 화분을 밀어낼 정도로 꽉 차면 2~3년에 한 번 봄에 분갈이합니다.',
      commonIssues:
        '물을 너무 자주 주면 검은 잎 줄기가 물러 썩을 수 있으니 항상 흙 건조를 먼저 확인하세요.',
    },
    funFact:
      '전 세계에서 폭발적인 인기를 얻고 있는 블랙 금전수 "레이븐(Raven)"은 사실 한국의 원예가(품종명 도원)가 개발한 자랑스러운 국산 신품종입니다.',
  },
  {
    id: 'alocasia-reginula',
    nameKo: '알로카시아 블랙 벨벳',
    nameEn: 'Alocasia Black Velvet',
    scientificName: 'Alocasia reginula',
    family: '천남성과',
    category: '관엽식물',
    origin: '보르네오 섬 (말레이시아)',
    difficulty: '보통',
    summary:
      '이름처럼 고급 검은색 벨벳 천을 만지는 듯한 보송하고 짙은 흑색 잎 위에 선명한 은백색 잎맥이 수놓아진 콤팩트한 보석 알로카시아입니다.',
    imageUrl:
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/7/7d/Alocasia_reginula_%28Philippines%29_01.jpg/960px-Alocasia_reginula_%28Philippines%29_01.jpg',
    characteristics: {
      appearance:
        '두툼하고 둥근 심장 모양 잎 표면이 빛을 흡수하는 무광 검은색 벨벳 질감이며, 은빛 잎맥과 붉은빛 뒷면이 강렬한 대비를 이룹니다.',
      colorPalette: ['#171717', '#262626', '#E5E7EB'],
      colorDescription: '빛을 머금는 검은색·검정색 벨벳 잎과 은백색 잎맥',
      scent: '향기가 거의 없는 무향 관엽식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '키 25~40cm 정도로 아담해 책상이나 선반 위 포인트로 알맞습니다.',
      bloomingSeason: '사계절 내내 블랙 벨벳 잎의 질감을 감상합니다.',
      petSafety: '천남성과 식물 특유의 독성이 있으므로 반려동물 접근을 막아주세요.',
    },
    careGuide: {
      watering:
        '구근 식물이라 물이 고이면 쉽게 무르므로 겉흙이 2~3cm 정도 말랐을 때 줍니다.',
      wateringCycle: '봄~가을 주 1회, 겨울 10~14일에 1회',
      sunlight: '직사광선은 잎을 태우므로 부드러운 밝은 간접광이나 반음지에 둡니다.',
      temperature: '18~26°C의 따뜻한 환경을 좋아하며 겨울에는 15°C 이상 유지하세요.',
      humidity: '55~70% 습도에서 잎이 깨끗하게 자랍니다. 벨벳 잎에 직접 물 분무는 피하고 주변 습도를 높여주세요.',
      soil: '바크·펄라이트·코코칩을 듬뿍 섞어 공기가 잘 통하는 청키한 흙을 씁니다.',
      fertilizer: '성장기 봄~가을에 월 1~2회 묽은 액비를 줍니다.',
      pruningAndRepotting:
        '오래된 겉잎 하나가 지면서 새 잎이 올라오는 자연스러운 순환을 보입니다.',
      commonIssues:
        '겨울철 추위와 과습이 겹치면 잎이 모두 떨어지고 휴면에 들 수 있으니 물주기를 줄이세요.',
    },
    funFact:
      '잎 표면에 빽빽하게 난 미세 돌기가 빛 반사를 억제해 일반 녹색 잎보다 훨씬 깊고 어두운 검은색 벨벳 광택을 만들어냅니다.',
  },
  {
    id: 'aeonium-arboreum-zwartkop',
    nameKo: '흑법사 (블랙 로즈 다육)',
    nameEn: 'Black Rose Succulent',
    scientificName: 'Aeonium arboreum \'Zwartkop\'',
    family: '돌나물과',
    category: '다육·선인장',
    origin: '카나리아 제도 원산 원예 품종',
    difficulty: '초보자 추천',
    summary:
      '검은 장미처럼 매혹적인 칠흑색·검붉은 잎이 둥근 로제트를 이루며 목질 줄기 끝에서 자라는 인기 다육식물입니다.',
    imageUrl:
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/6/6f/Aeonium_arboreum_%27Zwartkopf%27_Plant_2364px.jpg/960px-Aeonium_arboreum_%27Zwartkopf%27_Plant_2364px.jpg',
    characteristics: {
      appearance:
        '유연하고 단단한 목대 끝에 광택 있는 주걱 모양의 검은색·검정색 잎들이 장미꽃처럼 둥글게 펼쳐집니다.',
      colorPalette: ['#1C1417', '#3B0A1E', '#4D7C0F'],
      colorDescription: '햇빛을 받으면 짙어지는 검은색·검정색(흑자색) 로제트 잎',
      scent: '거의 무향이나 잎을 살짝 문지르면 특유의 풋풋한 다육 내음이 납니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '작은 화분 20cm부터 묵을수록 60~90cm 작은 나무처럼 멋지게 자랍니다.',
      bloomingSeason: '주로 흑장미 같은 잎을 감상하며, 성숙한 로제트에서는 노란 꽃대가 올라오기도 합니다.',
      petSafety: '독성이 거의 없어 반려동물에게 비교적 안전한 편입니다.',
    },
    careGuide: {
      watering:
        '봄·가을 성장기에 흙이 완전히 마르면 흠뻑 줍니다. 한여름 휴면기에는 물을 거의 끊고 통풍에 집중합니다.',
      wateringCycle: '봄·가을 10~14일에 1회, 여름철 단수 수준(월 1회 미만)',
      sunlight:
        '햇빛을 많이 받아야 초록색으로 빠지지 않고 강렬한 검은색을 유지합니다. 남향 창가나 노지 양지가 최고입니다.',
      temperature: '10~24°C의 서늘한 환경을 좋아하며 겨울에는 5°C 이상 실내에 둡니다.',
      humidity: '건조하고 바람이 잘 통하는 환경(30~50%)을 선호합니다.',
      soil: '마사토·펄라이트 비율이 60% 이상인 다육 전용 배수토에 심습니다.',
      fertilizer: '봄·가을 성장기에만 완효성 비료를 극소량 줍니다.',
      pruningAndRepotting:
        '가을에 적심(윗순 자르기)을 해주면 목대에서 여러 개의 검은 장미 얼굴이 풍성하게 분지됩니다.',
      commonIssues:
        '실내 빛이 부족하면 잎 중심부터 연초록색으로 변하니 가장 해가 잘 드는 자리에 두세요.',
    },
    funFact:
      '네덜란드어 품종명 "Zwartkop"은 "검은 머리"라는 뜻이며, 한국에서는 햇빛이 강할수록 칠흑같이 변해 "흑법사"라는 이름으로 불립니다.',
  },
  {
    id: 'ophiopogon-planiscapus-nigrescens',
    nameKo: '흑룡 (블랙 몬도그라스)',
    nameEn: 'Black Mondo Grass',
    scientificName: 'Ophiopogon planiscapus \'Nigrescens\'',
    family: '비짜루과',
    category: '관엽식물',
    origin: '일본 원산 원예 품종',
    difficulty: '초보자 추천',
    summary:
      '초록색 식물들 사이에서 단연 돋보이는 가늘고 윤기 흐르는 칠흑 같은 검은색 잎을 가진 동양적 미감의 미니 사초류입니다.',
    imageUrl:
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/0/0c/Ophiopogon_planiscapus_%27Nigrescens%27_kz01.jpg/960px-Ophiopogon_planiscapus_%27Nigrescens%27_kz01.jpg',
    characteristics: {
      appearance:
        '난초나 맥문동을 닮은 가늘고 길쭉한 곡선형 잎이 지면에서 아치를 그리며 검은색 깃털처럼 퍼져 자랍니다.',
      colorPalette: ['#111827', '#1F2937', '#4C1D95'],
      colorDescription: '광택 있는 순수 검은색·검정색 잎과 여름철 연보라·백색 작은 꽃, 검은 열매',
      scent: '향기가 거의 없는 단정하고 깔끔한 무향 식물입니다.',
      scentIntensity: '거의 없음',
      sizeAndGrowth: '키 15~25cm 정도로 아담해 토분·모던 화분이나 합식 포인트로 좋습니다.',
      bloomingSeason: '사계절 내내 검은 잎을 감상하며 여름에 작은 꽃과 진주 같은 흑자색 열매가 맺힙니다.',
      petSafety: '잎 자체는 독성이 거의 없으나 관상용 열매는 먹지 않도록 관리합니다.',
    },
    careGuide: {
      watering:
        '건조에도 잘 버티지만 겉흙이 마르면 규칙적으로 물을 주는 편이 잎 끝 마름을 막아줍니다.',
      wateringCycle: '봄~가을 주 1~2회, 겨울 10~14일에 1회',
      sunlight:
        '반음지에서도 자라지만 햇빛을 충분히 받을수록 잎이 훨씬 새까맣고 튼튼하게 자랍니다.',
      temperature: '추위에 매우 강해 영하권 노지 월동도 가능하며 실내에서는 사계절 무난합니다.',
      humidity: '보통 실내 습도에서도 잘 자라며 병해충이 거의 없습니다.',
      soil: '배수가 잘되는 일반 분갈이 흙에 마사토를 30% 정도 섞습니다.',
      fertilizer: '봄철 새 잎이 올라올 때 소량의 완효성 비료를 줍니다.',
      pruningAndRepotting:
        '2~3년마다 봄에 포기를 나누어 심어주면 깔끔하게 개체 수를 늘릴 수 있습니다.',
      commonIssues:
        '빛이 너무 부족하면 검은 잎이 짙은 녹색빛을 띠게 되므로 밝은 창가에 두세요.',
    },
    funFact:
      '화이트 토분이나 은빛 이끼와 함께 심으면 강렬한 모노톤 대비가 살아나 모던한 플랜테리어 연출에 자주 쓰입니다.',
  },
];
