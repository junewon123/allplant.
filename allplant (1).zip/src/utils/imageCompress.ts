import { COMMUNITY_LIMITS } from '../types/community';

export async function compressImageToDataUrl(file: File): Promise<string> {
  if (!file.type.startsWith('image/')) {
    throw new Error('이미지 파일(JPG, PNG, WebP 등)만 업로드할 수 있습니다.');
  }

  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('이미지를 읽을 수 없습니다.'));
      }
    };
    reader.onerror = () => reject(new Error('이미지 파일을 불러오지 못했습니다.'));
    reader.readAsDataURL(file);
  });

  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error('올바른 이미지 형식이 아닙니다.'));
    image.src = dataUrl;
  });

  const maxDim = 820;
  let { width, height } = img;
  if (width > maxDim || height > maxDim) {
    if (width >= height) {
      height = Math.round((height * maxDim) / width);
      width = maxDim;
    } else {
      width = Math.round((width * maxDim) / height);
      height = maxDim;
    }
  }

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('이미지 처리 컨텍스트를 초기화할 수 없습니다.');
  }
  ctx.drawImage(img, 0, 0, width, height);

  let quality = 0.78;
  let result = canvas.toDataURL('image/jpeg', quality);

  while (result.length > COMMUNITY_LIMITS.PHOTO_DATA_URL_MAX - 5000 && quality > 0.35) {
    quality -= 0.1;
    result = canvas.toDataURL('image/jpeg', quality);
  }

  let scale = 0.72;
  while (result.length > COMMUNITY_LIMITS.PHOTO_DATA_URL_MAX && scale >= 0.35) {
    canvas.width = Math.max(240, Math.round(width * scale));
    canvas.height = Math.max(180, Math.round(height * scale));
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    result = canvas.toDataURL('image/jpeg', 0.62);
    scale -= 0.12;
  }

  if (result.length > COMMUNITY_LIMITS.PHOTO_DATA_URL_MAX) {
    throw new Error('이미지 용량이 너무 큽니다. 더 작은 사진을 선택해 주세요.');
  }

  return result;
}
