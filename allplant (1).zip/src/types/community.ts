import type { Timestamp } from 'firebase/firestore';

export type CommunityCategory =
  | '관엽식물'
  | '허브·방향식물'
  | '다육·선인장'
  | '꽃·관화식물'
  | '공기정화·야자'
  | '기타·질문';

export type CommunityPostType = '사진자랑' | '키우는팁' | '정보공유' | '질문';

export const COMMUNITY_CATEGORIES: CommunityCategory[] = [
  '관엽식물',
  '허브·방향식물',
  '다육·선인장',
  '꽃·관화식물',
  '공기정화·야자',
  '기타·질문',
];

export const COMMUNITY_POST_TYPES: CommunityPostType[] = [
  '사진자랑',
  '키우는팁',
  '정보공유',
  '질문',
];

export const COMMUNITY_LIMITS = {
  AUTHOR_NAME_MAX: 60,
  AUTHOR_PHOTO_MAX: 500,
  TITLE_MAX: 120,
  CONTENT_MAX: 3000,
  PLANT_NAME_MAX: 80,
  PHOTO_DATA_URL_MAX: 220000,
  COMMENT_MAX: 1000,
} as const;

export const BOOTSTRAPPED_ADMIN_EMAIL = 'yjw201008@gmail.com';

export interface CommunityPost {
  id: string;
  authorId: string;
  authorName: string;
  authorPhotoUrl?: string;
  title: string;
  content: string;
  plantName: string;
  category: CommunityCategory;
  postType: CommunityPostType;
  photoDataUrl: string;
  likesCount: number;
  commentsCount: number;
  createdAt: Timestamp | null;
  updatedAt: Timestamp | null;
}

export interface PostComment {
  id: string;
  postId: string;
  authorId: string;
  authorName: string;
  authorPhotoUrl?: string;
  content: string;
  createdAt: Timestamp | null;
}
