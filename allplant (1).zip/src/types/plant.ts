export type PlantCategory =
  | '관엽식물'
  | '허브·방향식물'
  | '다육·선인장'
  | '꽃·관화식물'
  | '공기정화·야자';

export type CareDifficulty = '초보자 추천' | '보통' | '세심한 관리 필요';

export type PlantSeason = '봄' | '여름' | '가을' | '겨울';

export type AppPage = 'search' | 'recommend' | 'catalog' | 'community' | 'saved' | 'accounts';

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface PlantCharacteristics {
  appearance: string;
  colorPalette: string[];
  colorDescription: string;
  scent: string;
  scentIntensity: string;
  sizeAndGrowth: string;
  bloomingSeason: string;
  petSafety: string;
}

export interface PlantCareGuide {
  watering: string;
  wateringCycle: string;
  sunlight: string;
  temperature: string;
  humidity: string;
  soil: string;
  fertilizer: string;
  pruningAndRepotting: string;
  commonIssues: string;
}

export interface PlantProfile {
  id: string;
  nameKo: string;
  nameEn: string;
  scientificName: string;
  family: string;
  category: PlantCategory;
  origin: string;
  difficulty: CareDifficulty;
  summary: string;
  imageUrl?: string;
  characteristics: PlantCharacteristics;
  careGuide: PlantCareGuide;
  funFact: string;
  sources?: GroundingSource[];
  isGoogleLive?: boolean;
}

export interface PlantRecommendation {
  nameKo: string;
  nameEn: string;
  scientificName: string;
  category: PlantCategory;
  difficulty: CareDifficulty;
  matchReason: string;
  appearanceSummary: string;
  colorDescription: string;
  colorHexes: string[];
  scentSummary: string;
  quickCareTip: string;
  imageUrl?: string;
}

export interface RecommendationResponse {
  querySummary: string;
  recommendations: PlantRecommendation[];
  sources: GroundingSource[];
  sourceMode?: 'catalog' | 'google-live' | 'gemini-knowledge';
  notice?: string;
}
