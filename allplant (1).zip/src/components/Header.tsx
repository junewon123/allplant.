import { LogIn, LogOut, ShieldCheck } from 'lucide-react';
import type { AppPage } from '../types/plant';

interface HeaderProps {
  activePage: AppPage;
  savedCount: number;
  userEmail?: string | null;
  isPrimaryAdmin: boolean;
  onNavigate: (page: AppPage) => void;
  onSignIn: () => void;
  onSignOut: () => void;
}

const BASE_NAV_ITEMS: Array<{ id: AppPage; label: string }> = [
  { id: 'search', label: '식물 검색' },
  { id: 'recommend', label: '취향 추천' },
  { id: 'catalog', label: '식물 도감' },
  { id: 'community', label: '커뮤니티' },
  { id: 'saved', label: '저장함' },
];

export function Header({
  activePage,
  savedCount,
  userEmail,
  isPrimaryAdmin,
  onNavigate,
  onSignIn,
  onSignOut,
}: HeaderProps) {
  const navItems = isPrimaryAdmin
    ? [...BASE_NAV_ITEMS, { id: 'accounts' as AppPage, label: '계정 관리' }]
    : BASE_NAV_ITEMS;

  return (
    <header className="sticky top-0 z-40 bg-[#FBF9F5]/95 backdrop-blur-sm border-b border-[#E5DFD3]">
      <div className="max-w-7xl mx-auto px-6 lg:px-10 h-16 flex items-center justify-between gap-4 lg:gap-8">
        {/* Zone 1: Single text element wordmark */}
        <button
          type="button"
          onClick={() => onNavigate('search')}
          className="font-editorial text-xl font-semibold tracking-tight text-[#1C1917] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#1B4332]"
        >
          올플랜트
        </button>

        {/* Zone 2: Single-line page navigation buttons */}
        <nav
          aria-label="주요 메뉴"
          className="hidden md:flex items-center gap-5 lg:gap-6 text-sm font-medium"
        >
          {navItems.map((item) => {
            const isActive = activePage === item.id;
            const text =
              item.id === 'saved' ? `${item.label} (${savedCount})` : item.label;
            return (
              <button
                key={item.id}
                type="button"
                aria-current={isActive ? 'page' : undefined}
                onClick={() => onNavigate(item.id)}
                className={`inline-flex items-center gap-1 transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer tabular-nums ${
                  isActive
                    ? 'text-[#1B4332] font-semibold underline decoration-[#1B4332] decoration-2 underline-offset-8'
                    : 'text-[#57534E] hover:text-[#1C1917] hover:underline underline-offset-8'
                }`}
              >
                {item.id === 'accounts' && <ShieldCheck className="w-3.5 h-3.5" />}
                <span>{text}</span>
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Auth button + Primary CTA */}
        <div className="flex items-center gap-2 shrink-0">
          {userEmail ? (
            <button
              type="button"
              onClick={onSignOut}
              title={`${userEmail} 로그아웃`}
              className="inline-flex items-center gap-1.5 px-2.5 py-2 text-xs font-medium text-[#57534E] hover:text-[#1C1917] bg-white border border-[#E5DFD3] hover:border-[#1B4332]/50 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">로그아웃</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={onSignIn}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-[#1B4332] bg-white border border-[#D6CEBE] hover:border-[#1B4332] rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Google 로그인</span>
            </button>
          )}
          <button
            type="button"
            onClick={() => onNavigate('recommend')}
            className="px-4 py-2 text-xs sm:text-sm font-medium text-[#FBF9F5] bg-[#1B4332] hover:bg-[#143325] rounded-md transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1B4332]"
          >
            식물 추천받기
          </button>
        </div>
      </div>

      {/* Mobile horizontal page switcher */}
      <nav
        aria-label="모바일 페이지 메뉴"
        className="md:hidden border-t border-[#E5DFD3] px-4 py-2 flex items-center gap-4 overflow-x-auto text-xs font-medium"
      >
        {navItems.map((item) => {
          const isActive = activePage === item.id;
          const text =
            item.id === 'saved' ? `${item.label} (${savedCount})` : item.label;
          return (
            <button
              key={item.id}
              type="button"
              aria-current={isActive ? 'page' : undefined}
              onClick={() => onNavigate(item.id)}
              className={`inline-flex items-center gap-1 whitespace-nowrap shrink-0 py-1 cursor-pointer tabular-nums ${
                isActive
                  ? 'text-[#1B4332] font-semibold underline decoration-[#1B4332] decoration-2 underline-offset-4'
                  : 'text-[#57534E]'
              }`}
            >
              {item.id === 'accounts' && <ShieldCheck className="w-3 h-3" />}
              <span>{text}</span>
            </button>
          );
        })}
      </nav>
    </header>
  );
}
