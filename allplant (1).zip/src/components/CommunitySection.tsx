import { useEffect, useMemo, useRef, useState } from 'react';
import type { User } from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  increment,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  writeBatch,
} from 'firebase/firestore';
import {
  Camera,
  Heart,
  Loader2,
  LogIn,
  LogOut,
  MessageSquare,
  PenLine,
  ShieldCheck,
  Trash2,
  X,
} from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  COMMUNITY_CATEGORIES,
  COMMUNITY_LIMITS,
  COMMUNITY_POST_TYPES,
  type CommunityCategory,
  type CommunityPost,
  type CommunityPostType,
} from '../types/community';
import { compressImageToDataUrl } from '../utils/imageCompress';
import { SafeImage } from './SafeImage';
import { CommunityPostModal } from './CommunityPostModal';

interface CommunitySectionProps {
  user: User | null;
  authReady: boolean;
  isAdmin: boolean;
  onSignIn: () => Promise<boolean>;
  onSignOut: () => Promise<void>;
}

function formatShortDate(ts: CommunityPost['createdAt']): string {
  if (!ts) return '방금 전';
  try {
    return new Intl.DateTimeFormat('ko-KR', {
      month: 'short',
      day: 'numeric',
    }).format(ts.toDate());
  } catch {
    return '';
  }
}

export function CommunitySection({
  user,
  authReady,
  isAdmin,
  onSignIn,
  onSignOut,
}: CommunitySectionProps) {
  const [posts, setPosts] = useState<CommunityPost[]>([]);
  const [isLoadingPosts, setIsLoadingPosts] = useState(true);
  const [likedPostIds, setLikedPostIds] = useState<Record<string, boolean>>({});
  const [selectedCategory, setSelectedCategory] = useState<'전체' | CommunityCategory>('전체');
  const [selectedPostType, setSelectedPostType] = useState<'전체' | CommunityPostType>('전체');

  // Composer state
  const [showComposer, setShowComposer] = useState(false);
  const [title, setTitle] = useState('');
  const [plantName, setPlantName] = useState('');
  const [category, setCategory] = useState<CommunityCategory>('관엽식물');
  const [postType, setPostType] = useState<CommunityPostType>('사진자랑');
  const [content, setContent] = useState('');
  const [photoDataUrl, setPhotoDataUrl] = useState('');
  const [isCompressingPhoto, setIsCompressingPhoto] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const [composerError, setComposerError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Active post detail modal & inline delete confirmation
  const [activePostId, setActivePostId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [feedError, setFeedError] = useState<string | null>(null);
  const [publishNotice, setPublishNotice] = useState<string | null>(null);

  // Real-time posts listener
  useEffect(() => {
    const q = query(
      collection(db, 'communityPosts'),
      orderBy('createdAt', 'desc'),
      limit(60)
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const items: CommunityPost[] = snapshot.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<CommunityPost, 'id'>),
        }));
        setPosts(items);
        setFeedError(null);
        setIsLoadingPosts(false);
      },
      (error) => {
        setIsLoadingPosts(false);
        const raw = error instanceof Error ? error.message : String(error);
        if (raw.toLowerCase().includes('quota')) {
          setFeedError('일일 데이터베이스 읽기 한도를 초과했습니다. 내일 다시 이용해 주세요.');
        } else {
          setFeedError('게시글 목록을 불러오지 못했습니다. 페이지를 새로고침하거나 잠시 후 다시 시도해 주세요.');
        }
        handleFirestoreError(error, OperationType.LIST, 'communityPosts');
      }
    );

    return () => unsubscribe();
  }, []);

  // Load user's liked status for visible posts
  useEffect(() => {
    if (!user || posts.length === 0) {
      setLikedPostIds({});
      return;
    }

    let cancelled = false;
    const checkLikes = async () => {
      const entries = await Promise.all(
        posts.map(async (p) => {
          try {
            const snap = await getDoc(
              doc(db, 'communityPosts', p.id, 'likes', user.uid)
            );
            return [p.id, snap.exists()] as const;
          } catch {
            return [p.id, false] as const;
          }
        })
      );
      if (!cancelled) {
        const next: Record<string, boolean> = {};
        for (const [id, liked] of entries) {
          if (liked) next[id] = true;
        }
        setLikedPostIds(next);
      }
    };

    void checkLikes();
    return () => {
      cancelled = true;
    };
  }, [user, posts]);

  const filteredPosts = useMemo(() => {
    return posts.filter((p) => {
      if (selectedCategory !== '전체' && p.category !== selectedCategory) {
        return false;
      }
      if (selectedPostType !== '전체' && p.postType !== selectedPostType) {
        return false;
      }
      return true;
    });
  }, [posts, selectedCategory, selectedPostType]);

  const activePost = useMemo(
    () => posts.find((p) => p.id === activePostId) ?? null,
    [posts, activePostId]
  );

  const handlePhotoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setComposerError(null);
    setIsCompressingPhoto(true);
    try {
      const compressed = await compressImageToDataUrl(file);
      setPhotoDataUrl(compressed);
    } catch (err) {
      setComposerError(
        err instanceof Error ? err.message : '사진을 처리하지 못했습니다.'
      );
    } finally {
      setIsCompressingPhoto(false);
    }
  };

  const handleOpenComposer = async () => {
    setPublishNotice(null);
    if (!user) {
      const signedIn = await onSignIn();
      if (signedIn) {
        setShowComposer(true);
      }
      return;
    }
    setShowComposer((prev) => !prev);
  };

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      const signedIn = await onSignIn();
      if (!signedIn) return;
    }
    if (!user) return;

    const cleanTitle = title.trim().slice(0, COMMUNITY_LIMITS.TITLE_MAX);
    const cleanContent = content.trim().slice(0, COMMUNITY_LIMITS.CONTENT_MAX);
    const cleanPlantName = plantName
      .trim()
      .slice(0, COMMUNITY_LIMITS.PLANT_NAME_MAX);

    if (!cleanTitle || !cleanContent) {
      setComposerError('제목과 본문 내용을 모두 입력해 주세요.');
      return;
    }

    setIsPublishing(true);
    setComposerError(null);
    setPublishNotice(null);

    const postRef = doc(collection(db, 'communityPosts'));
    const authorName = (
      user.displayName?.trim() ||
      user.email?.split('@')[0]?.trim() ||
      '가드너'
    ).slice(0, COMMUNITY_LIMITS.AUTHOR_NAME_MAX);
    const authorPhotoUrl = (user.photoURL || '').slice(
      0,
      COMMUNITY_LIMITS.AUTHOR_PHOTO_MAX
    );

    try {
      await setDoc(postRef, {
        authorId: user.uid,
        authorName,
        authorPhotoUrl,
        title: cleanTitle,
        content: cleanContent,
        plantName: cleanPlantName,
        category,
        postType,
        photoDataUrl: photoDataUrl.slice(0, COMMUNITY_LIMITS.PHOTO_DATA_URL_MAX),
        likesCount: 0,
        commentsCount: 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      if (selectedCategory !== '전체' && selectedCategory !== category) {
        setSelectedCategory('전체');
      }
      if (selectedPostType !== '전체' && selectedPostType !== postType) {
        setSelectedPostType('전체');
      }

      setTitle('');
      setPlantName('');
      setContent('');
      setPhotoDataUrl('');
      if (fileInputRef.current) fileInputRef.current.value = '';
      setShowComposer(false);
      setPublishNotice('게시글이 커뮤니티에 공유되었습니다.');
    } catch (error) {
      const raw = error instanceof Error ? error.message : String(error);
      if (raw.toLowerCase().includes('quota')) {
        setComposerError('일일 데이터베이스 사용 한도를 초과했습니다. 내일 다시 시도해 주세요.');
      } else if (raw.toLowerCase().includes('permission') || raw.toLowerCase().includes('insufficient')) {
        setComposerError('게시글 등록 권한 확인에 실패했습니다. 인증된 Google 계정으로 로그인되었는지 확인해 주세요.');
      } else if (raw.toLowerCase().includes('offline') || raw.toLowerCase().includes('unavailable')) {
        setComposerError('네트워크 연결 상태를 확인한 뒤 다시 시도해 주세요.');
      } else {
        setComposerError('게시글을 등록하지 못했습니다. 잠시 후 다시 시도해 주세요.');
      }
      handleFirestoreError(
        error,
        OperationType.CREATE,
        `communityPosts/${postRef.id}`
      );
    } finally {
      setIsPublishing(false);
    }
  };

  const handleToggleLike = async (post: CommunityPost) => {
    if (!user) {
      await onSignIn();
      return;
    }

    const currentlyLiked = Boolean(likedPostIds[post.id]);
    const likeRef = doc(db, 'communityPosts', post.id, 'likes', user.uid);
    const postRef = doc(db, 'communityPosts', post.id);

    setLikedPostIds((prev) => ({ ...prev, [post.id]: !currentlyLiked }));

    try {
      const batch = writeBatch(db);
      if (currentlyLiked) {
        batch.delete(likeRef);
        batch.update(postRef, {
          likesCount: increment(-1),
          updatedAt: serverTimestamp(),
        });
      } else {
        batch.set(likeRef, {
          userId: user.uid,
          createdAt: serverTimestamp(),
        });
        batch.update(postRef, {
          likesCount: increment(1),
          updatedAt: serverTimestamp(),
        });
      }
      await batch.commit();
    } catch (error) {
      setLikedPostIds((prev) => ({ ...prev, [post.id]: currentlyLiked }));
      handleFirestoreError(
        error,
        OperationType.UPDATE,
        `communityPosts/${post.id}`
      );
    }
  };

  const handleDeletePost = async (post: CommunityPost) => {
    if (!user) return;
    const postPath = `communityPosts/${post.id}`;
    try {
      await deleteDoc(doc(db, 'communityPosts', post.id));
      setConfirmDeleteId(null);
      if (activePostId === post.id) setActivePostId(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, postPath);
    }
  };

  return (
    <section
      id="community"
      className="py-10 lg:py-14 bg-[#FBF9F5] flex-1"
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        {/* Header & Auth Control */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-8 border-b border-[#E5DFD3]">
          <div className="max-w-2xl">
            <p className="text-xs font-medium text-[#57534E] mb-2">
              04 · 식물 가드너 커뮤니티 게시판
            </p>
            <h2 className="font-editorial text-2xl sm:text-3xl font-semibold text-[#1C1917] text-balance">
              반려식물 사진 자랑과 키우는 팁을 나누어 보세요
            </h2>
            <p className="mt-2.5 text-sm sm:text-[15px] text-[#57534E] leading-relaxed">
              직접 기른 식물의 사진, 물주기 노하우, 분갈이 팁을 카테고리별로 공유하고
              댓글과 좋아요로 소통할 수 있습니다.
            </p>
            {isAdmin && (
              <p className="mt-2.5 text-xs font-medium text-[#1B4332]">
                관리자 계정({user?.email})으로 로그인되었습니다 · 모든 게시글과 댓글을 직접 삭제할 수 있습니다.
              </p>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            {authReady && user ? (
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <div className="text-xs font-medium text-[#1C1917] flex items-center gap-1.5">
                    <span>{user.displayName || user.email?.split('@')[0]}</span>
                    {isAdmin && (
                      <span className="inline-flex items-center gap-1 text-[#1B4332] font-semibold">
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>관리자</span>
                      </span>
                    )}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => void onSignOut()}
                  className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-[#44403C] bg-white border border-[#D6CEBE] hover:border-[#1C1917] rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>로그아웃</span>
                </button>
              </div>
            ) : (
              <button
                type="button"
                disabled={!authReady}
                onClick={() => void onSignIn()}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-medium text-[#1C1917] bg-white border border-[#D6CEBE] hover:border-[#1B4332] rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                <span>Google 로그인</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => void handleOpenComposer()}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-medium text-[#FBF9F5] bg-[#1B4332] hover:bg-[#143325] rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <PenLine className="w-4 h-4" />
              <span>{showComposer ? '작성 닫기' : '새 글 작성'}</span>
            </button>
          </div>
        </div>

        {/* Post Composer */}
        {showComposer && user && (
          <form
            onSubmit={(e) => void handleCreatePost(e)}
            className="mt-8 bg-white border border-[#E5DFD3] rounded-lg p-6 sm:p-8 space-y-5"
          >
            <div className="flex items-center justify-between border-b border-[#E5DFD3] pb-4">
              <h3 className="font-editorial text-xl font-semibold text-[#1C1917]">
                새 커뮤니티 글 작성
              </h3>
              <button
                type="button"
                onClick={() => setShowComposer(false)}
                className="text-xs text-[#57534E] hover:text-[#1C1917] cursor-pointer"
              >
                닫기
              </button>
            </div>

            {composerError && (
              <div className="p-3.5 bg-[#FEF2F2] border border-[#FECACA] rounded-md text-xs text-[#991B1B]">
                {composerError}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-[#57534E] mb-1.5">
                  식물 카테고리
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as CommunityCategory)}
                  className="w-full h-10 px-3 text-sm bg-[#FBF9F5] border border-[#D6CEBE] rounded-md text-[#1C1917] focus:outline-none focus:border-[#1B4332]"
                >
                  {COMMUNITY_CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#57534E] mb-1.5">
                  글 성격
                </label>
                <select
                  value={postType}
                  onChange={(e) => setPostType(e.target.value as CommunityPostType)}
                  className="w-full h-10 px-3 text-sm bg-[#FBF9F5] border border-[#D6CEBE] rounded-md text-[#1C1917] focus:outline-none focus:border-[#1B4332]"
                >
                  {COMMUNITY_POST_TYPES.map((pt) => (
                    <option key={pt} value={pt}>
                      {pt}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#57534E] mb-1.5">
                  식물 이름 (선택)
                </label>
                <input
                  type="text"
                  value={plantName}
                  maxLength={COMMUNITY_LIMITS.PLANT_NAME_MAX}
                  onChange={(e) => setPlantName(e.target.value)}
                  placeholder="예: 몬스테라, 잉글리시 라벤더"
                  className="w-full h-10 px-3 text-sm bg-[#FBF9F5] border border-[#D6CEBE] rounded-md text-[#1C1917] placeholder:text-[#78716C] focus:outline-none focus:border-[#1B4332]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#57534E] mb-1.5">
                제목
              </label>
              <input
                type="text"
                required
                value={title}
                maxLength={COMMUNITY_LIMITS.TITLE_MAX}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="예: 2년 키운 몬스테라 새 잎이 예쁘게 갈라졌어요"
                className="w-full h-11 px-3.5 text-sm bg-[#FBF9F5] border border-[#D6CEBE] rounded-md text-[#1C1917] placeholder:text-[#78716C] focus:outline-none focus:border-[#1B4332]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#57534E] mb-1.5">
                내용 및 키우는 팁
              </label>
              <textarea
                required
                rows={4}
                value={content}
                maxLength={COMMUNITY_LIMITS.CONTENT_MAX}
                onChange={(e) => setContent(e.target.value)}
                placeholder="물주기 주기, 햇빛 위치, 흙 배합 팁이나 자랑하고 싶은 성장 이야기를 자유롭게 적어 주세요."
                className="w-full p-3.5 text-sm bg-[#FBF9F5] border border-[#D6CEBE] rounded-md text-[#1C1917] placeholder:text-[#78716C] focus:outline-none focus:border-[#1B4332] leading-relaxed"
              />
            </div>

            {/* Photo Upload */}
            <div>
              <label className="block text-xs font-medium text-[#57534E] mb-2">
                식물 사진 첨부 (선택 · 자동 최적화)
              </label>
              <div className="flex flex-wrap items-center gap-3">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={(e) => void handlePhotoChange(e)}
                  className="hidden"
                  id="community-photo-upload"
                />
                <label
                  htmlFor="community-photo-upload"
                  className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-[#1C1917] bg-[#FBF9F5] border border-[#D6CEBE] hover:border-[#1B4332] rounded-md cursor-pointer transition-colors"
                >
                  {isCompressingPhoto ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Camera className="w-4 h-4" />
                  )}
                  <span>{photoDataUrl ? '다른 사진 선택' : '사진 올리기'}</span>
                </label>

                {photoDataUrl && (
                  <button
                    type="button"
                    onClick={() => {
                      setPhotoDataUrl('');
                      if (fileInputRef.current) fileInputRef.current.value = '';
                    }}
                    className="inline-flex items-center gap-1 text-xs text-[#991B1B] hover:underline cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>사진 제거</span>
                  </button>
                )}
              </div>

              {photoDataUrl && (
                <div className="mt-3 w-48 overflow-hidden rounded-md border border-[#E5DFD3] bg-[#F3EFE6]">
                  <img
                    src={photoDataUrl}
                    alt="업로드 미리보기"
                    className="w-full aspect-[4/3] object-cover"
                  />
                </div>
              )}
            </div>

            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowComposer(false)}
                className="px-4 py-2 text-sm text-[#57534E] hover:text-[#1C1917] cursor-pointer"
              >
                취소
              </button>
              <button
                type="submit"
                disabled={isPublishing || isCompressingPhoto}
                className="px-5 py-2.5 inline-flex items-center gap-2 text-sm font-medium text-[#FBF9F5] bg-[#1B4332] hover:bg-[#143325] disabled:opacity-45 rounded-md transition-colors cursor-pointer"
              >
                {isPublishing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>게시 중</span>
                  </>
                ) : (
                  <span>게시글 올리기</span>
                )}
              </button>
            </div>
          </form>
        )}

        {/* Filter Bar */}
        <div className="mt-8 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Category Segmented Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-[#F3EFE6] border border-[#E5DFD3] rounded-lg">
            {(['전체', ...COMMUNITY_CATEGORIES] as const).map((cat) => {
              const active = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? 'bg-white text-[#1C1917] shadow-xs'
                      : 'text-[#57534E] hover:text-[#1C1917]'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>

          {/* Post Type Filter */}
          <div className="flex flex-wrap items-center gap-1.5">
            {(['전체', ...COMMUNITY_POST_TYPES] as const).map((pt) => {
              const active = selectedPostType === pt;
              return (
                <button
                  key={pt}
                  type="button"
                  onClick={() => setSelectedPostType(pt)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? 'bg-[#1B4332] text-[#FBF9F5] border-[#1B4332]'
                      : 'bg-white text-[#44403C] border-[#D6CEBE] hover:border-[#1B4332]'
                  }`}
                >
                  {pt === '전체' ? '모든 글' : pt}
                </button>
              );
            })}
          </div>
        </div>

        {publishNotice && (
          <div className="mt-6 p-3.5 bg-[#ECFDF5] border border-[#A7F3D0] rounded-md text-xs text-[#1B4332] flex items-center justify-between gap-3">
            <span>{publishNotice}</span>
            <button
              type="button"
              onClick={() => setPublishNotice(null)}
              className="text-[#1B4332] hover:underline cursor-pointer shrink-0"
            >
              닫기
            </button>
          </div>
        )}

        {feedError && (
          <div className="mt-6 p-4 bg-[#FEF2F2] border border-[#FECACA] rounded-md text-xs text-[#991B1B]">
            {feedError}
          </div>
        )}

        {/* Feed */}
        {isLoadingPosts ? (
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((n) => (
              <div
                key={n}
                className="bg-white border border-[#E5DFD3] rounded-lg p-6 animate-pulse space-y-4"
              >
                <div className="h-36 bg-[#F3EFE6] rounded" />
                <div className="h-4 w-28 bg-[#EAE4D8] rounded" />
                <div className="h-5 w-48 bg-[#EAE4D8] rounded" />
              </div>
            ))}
          </div>
        ) : filteredPosts.length === 0 ? (
          <div className="mt-8 py-14 px-6 bg-white border border-[#E5DFD3] rounded-lg text-center">
            <p className="font-editorial text-lg text-[#1C1917]">
              아직 등록된 게시글이 없습니다
            </p>
            <p className="mt-1.5 text-sm text-[#57534E]">
              첫 번째 식물 사진이나 나만의 키우는 팁을 공유해 보세요.
            </p>
            <button
              type="button"
              onClick={() => void handleOpenComposer()}
              className="mt-4 px-4 py-2 text-xs font-medium bg-[#1B4332] text-[#FBF9F5] rounded-md hover:bg-[#143325] transition-colors cursor-pointer"
            >
              {user ? '첫 글 작성하기' : 'Google 로그인 후 글 작성하기'}
            </button>
          </div>
        ) : (
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPosts.map((post) => {
              const liked = Boolean(likedPostIds[post.id]);
              const canDelete = Boolean(
                user && (user.uid === post.authorId || isAdmin)
              );
              const isAdminModerating = Boolean(
                user && isAdmin && user.uid !== post.authorId
              );
              const isConfirmingDelete = confirmDeleteId === post.id;

              return (
                <article
                  key={post.id}
                  className="bg-white border border-[#E5DFD3] rounded-lg overflow-hidden flex flex-col justify-between"
                >
                  <div>
                    {post.photoDataUrl && (
                      <button
                        type="button"
                        onClick={() => setActivePostId(post.id)}
                        className="w-full block overflow-hidden aspect-[4/3] bg-[#F3EFE6] border-b border-[#E5DFD3] cursor-pointer"
                      >
                        <SafeImage
                          src={post.photoDataUrl}
                          alt={post.title}
                          fallbackLabel={post.plantName || post.title}
                          className="w-full h-full object-cover hover:scale-[1.02] transition-transform duration-200"
                        />
                      </button>
                    )}

                    <div className="p-6">
                      {/* Unboxed Metadata */}
                      <div className="flex items-center gap-2 text-xs text-[#78716C] mb-2 truncate">
                        <span>{post.category}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-medium text-[#1B4332]">
                          {post.postType}
                        </span>
                        {post.plantName && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="truncate">{post.plantName}</span>
                          </>
                        )}
                      </div>

                      <button
                        type="button"
                        onClick={() => setActivePostId(post.id)}
                        className="text-left w-full group cursor-pointer"
                      >
                        <h3 className="font-editorial text-lg font-semibold text-[#1C1917] group-hover:text-[#1B4332] transition-colors line-clamp-2">
                          {post.title}
                        </h3>
                        <p className="mt-2 text-sm text-[#44403C] leading-relaxed line-clamp-3">
                          {post.content}
                        </p>
                      </button>
                    </div>
                  </div>

                  {/* Card Footer */}
                  <div className="px-6 py-3.5 border-t border-[#F0EBE1] bg-[#FAF8F4] flex items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-2 text-[#57534E] min-w-0 truncate">
                      <span className="font-medium text-[#1C1917] truncate">
                        {post.authorName}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums shrink-0">
                        {formatShortDate(post.createdAt)}
                      </span>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <button
                        type="button"
                        onClick={() => void handleToggleLike(post)}
                        aria-label={`좋아요 ${post.likesCount}`}
                        className={`inline-flex items-center gap-1 transition-colors cursor-pointer tabular-nums ${
                          liked
                            ? 'text-[#1B4332] font-semibold'
                            : 'text-[#57534E] hover:text-[#1C1917]'
                        }`}
                      >
                        <Heart
                          className={`w-3.5 h-3.5 ${liked ? 'fill-current' : ''}`}
                        />
                        <span>{post.likesCount}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setActivePostId(post.id)}
                        aria-label={`댓글 ${post.commentsCount}`}
                        className="inline-flex items-center gap-1 text-[#57534E] hover:text-[#1C1917] transition-colors cursor-pointer tabular-nums"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>{post.commentsCount}</span>
                      </button>

                      {canDelete && !isConfirmingDelete && (
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(post.id)}
                          title={isAdminModerating ? '관리자 권한으로 글 삭제' : '내 글 삭제'}
                          className="inline-flex items-center gap-1 text-[#991B1B] hover:underline cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          {isAdminModerating && <span>관리자 삭제</span>}
                        </button>
                      )}

                      {isConfirmingDelete && (
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => void handleDeletePost(post)}
                            className="px-2 py-0.5 text-[11px] font-medium bg-[#991B1B] text-white rounded cursor-pointer"
                          >
                            삭제
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteId(null)}
                            className="px-2 py-0.5 text-[11px] text-[#57534E] bg-white border border-[#D6CEBE] rounded cursor-pointer"
                          >
                            취소
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>

      {/* Post Detail & Comments Modal */}
      <CommunityPostModal
        post={activePost}
        user={user}
        isAdmin={isAdmin}
        isLiked={activePost ? Boolean(likedPostIds[activePost.id]) : false}
        onClose={() => setActivePostId(null)}
        onToggleLike={(post) => void handleToggleLike(post)}
        onDeletePost={handleDeletePost}
        onRequireSignIn={() => void onSignIn()}
      />
    </section>
  );
}
