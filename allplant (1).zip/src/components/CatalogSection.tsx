import { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, ArrowRight, Search } from 'lucide-react';
import type { PlantCategory, PlantProfile } from '../types/plant';
import { CATEGORY_VISUALS } from '../data/botanicalCatalog';
import { SafeImage } from './SafeImage';

interface CatalogSectionProps {
  plants: PlantProfile[];
  onSelectPlant: (plant: PlantProfile) => void;
}

const CATEGORIES: Array<'전체' | PlantCategory> = [
  '전체',
  '관엽식물',
  '허브·방향식물',
  '다육·선인장',
  '꽃·관화식물',
  '공기정화·야자',
];

const ITEMS_PER_PAGE = 12;

export function CatalogSection({ plants, onSelectPlant }: CatalogSectionProps) {
  const [selectedCategory, setSelectedCategory] = useState<'전체' | PlantCategory>('전체');
  const [onlyFragrant, setOnlyFragrant] = useState(false);
  const [onlyBeginner, setOnlyBeginner] = useState(false);
  const [filterText, setFilterText] = useState('');
  const [catalogPage, setCatalogPage] = useState(1);

  const filteredPlants = useMemo(() => {
    const q = filterText.trim().toLowerCase();
    return plants.filter((plant) => {
      if (selectedCategory !== '전체' && plant.category !== selectedCategory) {
        return false;
      }
      if (onlyFragrant && plant.characteristics.scentIntensity === '거의 없음') {
        return false;
      }
      if (onlyBeginner && plant.difficulty !== '초보자 추천') {
        return false;
      }
      if (q) {
        const haystack = [
          plant.nameKo,
          plant.nameEn,
          plant.scientificName,
          plant.summary,
          plant.characteristics.appearance,
          plant.characteristics.colorDescription,
          plant.characteristics.scent,
        ]
          .join(' ')
          .toLowerCase();
        return haystack.includes(q);
      }
      return true;
    });
  }, [plants, selectedCategory, onlyFragrant, onlyBeginner, filterText]);

  useEffect(() => {
    setCatalogPage(1);
  }, [selectedCategory, onlyFragrant, onlyBeginner, filterText]);

  const totalPages = Math.max(1, Math.ceil(filteredPlants.length / ITEMS_PER_PAGE));
  const safePage = Math.min(catalogPage, totalPages);
  const pagedPlants = useMemo(() => {
    const start = (safePage - 1) * ITEMS_PER_PAGE;
    return filteredPlants.slice(start, start + ITEMS_PER_PAGE);
  }, [filteredPlants, safePage]);

  const changeCatalogPage = (nextPage: number) => {
    setCatalogPage(nextPage);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const categoryCards: Array<{ category: PlantCategory; title: string }> = [
    { category: '관엽식물', title: '관엽식물' },
    { category: '허브·방향식물', title: '허브·방향식물' },
    { category: '다육·선인장', title: '다육·선인장' },
    { category: '꽃·관화식물', title: '꽃·관화식물' },
  ];

  return (
    <section id="catalog" className="py-10 lg:py-14 flex-1">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        {/* Section Heading */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-8 border-b border-[#E5DFD3]">
          <div className="max-w-2xl">
            <p className="text-xs font-medium text-[#57534E] mb-2">
              03 · 주요 식물 분류 및 생육 도감
            </p>
            <h2 className="font-editorial text-2xl sm:text-3xl font-semibold text-[#1C1917] text-balance">
              구글 원예 기준에 따라 정리한 식물 표본 아카이브
            </h2>
            <p className="mt-2.5 text-sm sm:text-[15px] text-[#57534E] leading-relaxed">
              분류나 향기, 난이도별로 식물을 둘러보고 카드를 선택해 물주기·광량·토양 관리법과
              실시간 구글 출처를 확인하세요.
            </p>
          </div>
          <div className="text-xs text-[#78716C] tabular-nums shrink-0">
            총 {filteredPlants.length}종 중 {safePage} / {totalPages} 페이지
          </div>
        </div>

        {/* 4 Category Editorial Photographic Plates */}
        <div className="mt-8 grid grid-cols-2 lg:grid-cols-4 gap-4">
          {categoryCards.map(({ category, title }) => {
            const visual = CATEGORY_VISUALS[category];
            const isSelected = selectedCategory === category;
            return (
              <button
                key={category}
                type="button"
                onClick={() =>
                  setSelectedCategory(isSelected ? '전체' : category)
                }
                className={`group text-left overflow-hidden rounded-lg border transition-colors cursor-pointer ${
                  isSelected
                    ? 'border-[#1B4332] bg-[#F5F1E8]'
                    : 'border-[#E5DFD3] bg-white hover:border-[#1B4332]/60'
                }`}
              >
                <div className="overflow-hidden aspect-[4/3] bg-[#F3EFE6]">
                  <SafeImage
                    src={visual.imageUrl}
                    alt={title}
                    fallbackLabel={title}
                    className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-200"
                  />
                </div>
                <div className="px-4 py-3 flex items-center justify-between gap-2">
                  <span className="font-editorial text-sm sm:text-base font-semibold text-[#1C1917] truncate">
                    {title}
                  </span>
                  <span className="text-xs text-[#1B4332] whitespace-nowrap shrink-0">
                    {isSelected ? '선택됨' : '모아보기'}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Filter Controls */}
        <div className="mt-8 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Segmented Category Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-[#F3EFE6] border border-[#E5DFD3] rounded-lg">
            {CATEGORIES.map((category) => {
              const active = selectedCategory === category;
              return (
                <button
                  key={category}
                  type="button"
                  onClick={() => setSelectedCategory(category)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? 'bg-white text-[#1C1917] shadow-xs'
                      : 'text-[#57534E] hover:text-[#1C1917]'
                  }`}
                >
                  {category}
                </button>
              );
            })}
          </div>

          {/* Sensory Filter Toggles + Inline Search */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => setOnlyFragrant((prev) => !prev)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                onlyFragrant
                  ? 'bg-[#1B4332] text-[#FBF9F5] border-[#1B4332]'
                  : 'bg-white text-[#44403C] border-[#D6CEBE] hover:border-[#1B4332]'
              }`}
            >
              향기 있는 식물만
            </button>
            <button
              type="button"
              onClick={() => setOnlyBeginner((prev) => !prev)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                onlyBeginner
                  ? 'bg-[#1B4332] text-[#FBF9F5] border-[#1B4332]'
                  : 'bg-white text-[#44403C] border-[#D6CEBE] hover:border-[#1B4332]'
              }`}
            >
              초보자 추천만
            </button>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-[#78716C] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={filterText}
                onChange={(e) => setFilterText(e.target.value)}
                placeholder="도감 내 이름·색·향 필터"
                className="h-8 pl-8 pr-3 text-xs bg-white border border-[#D6CEBE] rounded-md text-[#1C1917] placeholder:text-[#78716C] focus:outline-none focus:border-[#1B4332] w-48"
              />
            </div>
          </div>
        </div>

        {/* Specimen Grid */}
        {filteredPlants.length === 0 ? (
          <div className="mt-10 py-14 text-center bg-white border border-[#E5DFD3] rounded-lg">
            <p className="font-editorial text-lg text-[#1C1917]">
              조건에 맞는 도감 표본이 없습니다
            </p>
            <p className="mt-1.5 text-sm text-[#57534E]">
              필터를 초기화하거나 식물 검색 페이지에서 구글 실시간 식물 검색을 이용해 보세요.
            </p>
            <button
              type="button"
              onClick={() => {
                setSelectedCategory('전체');
                setOnlyFragrant(false);
                setOnlyBeginner(false);
                setFilterText('');
              }}
              className="mt-4 px-4 py-2 text-xs font-medium bg-[#1B4332] text-[#FBF9F5] rounded-md hover:bg-[#143325] transition-colors cursor-pointer"
            >
              필터 초기화
            </button>
          </div>
        ) : (
          <>
            <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {pagedPlants.map((plant) => {
                const cardImage =
                  plant.imageUrl || CATEGORY_VISUALS[plant.category]?.imageUrl;
                return (
                  <button
                    key={plant.id}
                    type="button"
                    onClick={() => onSelectPlant(plant)}
                    className="group text-left bg-white border border-[#E5DFD3] hover:border-[#1B4332] rounded-lg overflow-hidden transition-colors duration-150 flex flex-col justify-between cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1B4332]"
                  >
                    <div>
                      {/* Species Photo Plate */}
                      <div className="aspect-[16/10] w-full overflow-hidden bg-[#F3EFE6] border-b border-[#E5DFD3]">
                        <SafeImage
                          src={cardImage}
                          alt={`${plant.nameKo} (${plant.scientificName})`}
                          fallbackLabel={plant.nameKo}
                          className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-200"
                        />
                      </div>

                      <div className="p-6 pb-0">
                        {/* Unboxed Metadata */}
                        <div className="flex items-center gap-2 text-xs text-[#78716C] mb-2">
                          <span>{plant.category}</span>
                          <span aria-hidden="true">·</span>
                          <span className="text-[#1B4332] font-medium">{plant.difficulty}</span>
                        </div>

                        {/* Title & Scientific Name */}
                        <h3 className="font-editorial text-xl font-semibold text-[#1C1917] group-hover:text-[#1B4332] transition-colors">
                          {plant.nameKo}
                        </h3>
                        <p className="font-binomial italic text-sm text-[#57534E] mt-0.5">
                          {plant.scientificName}
                        </p>

                        {/* Summary */}
                        <p className="mt-3 text-sm text-[#292524] leading-relaxed line-clamp-2">
                          {plant.summary}
                        </p>

                        {/* Sensory Specs */}
                        <div className="mt-4 pt-4 border-t border-[#F0EBE1] space-y-2 text-xs">
                          <div className="flex items-center gap-2">
                            <span className="text-[#78716C] shrink-0">색조</span>
                            <div className="flex items-center gap-1.5 min-w-0">
                              {plant.characteristics.colorPalette.map((hex, i) => (
                                <span
                                  key={`${hex}-${i}`}
                                  className="w-3 h-3 rounded-full border border-[#D6CEBE] shrink-0"
                                  style={{ backgroundColor: hex }}
                                />
                              ))}
                              <span className="text-[#292524] truncate">
                                {plant.characteristics.colorDescription}
                              </span>
                            </div>
                          </div>
                          <div className="flex items-baseline gap-2">
                            <span className="text-[#78716C] shrink-0">향기</span>
                            <span className="text-[#292524] truncate">
                              {plant.characteristics.scentIntensity} · {plant.characteristics.scent}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Footer Action */}
                    <div className="mx-6 mb-6 mt-5 pt-3 border-t border-[#E5DFD3] flex items-center justify-between text-xs text-[#57534E]">
                      <span className="truncate pr-2">{plant.careGuide.wateringCycle}</span>
                      <span className="inline-flex items-center gap-1 font-medium text-[#1B4332] whitespace-nowrap shrink-0 group-hover:translate-x-0.5 transition-transform">
                        <span>도감 열기</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Catalog Pagination Controls */}
            {totalPages > 1 && (
              <div className="mt-8 pt-6 border-t border-[#E5DFD3] flex items-center justify-between gap-4">
                <button
                  type="button"
                  disabled={safePage <= 1}
                  onClick={() => changeCatalogPage(safePage - 1)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-[#1C1917] bg-white border border-[#D6CEBE] hover:border-[#1B4332] disabled:opacity-40 disabled:cursor-not-allowed rounded-md transition-colors cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>이전 목록</span>
                </button>

                <div className="flex items-center gap-1.5 tabular-nums">
                  {Array.from({ length: totalPages }, (_, idx) => idx + 1).map((pageNum) => (
                    <button
                      key={pageNum}
                      type="button"
                      onClick={() => changeCatalogPage(pageNum)}
                      className={`w-8 h-8 text-xs font-medium rounded-md border transition-colors cursor-pointer ${
                        safePage === pageNum
                          ? 'bg-[#1B4332] text-[#FBF9F5] border-[#1B4332]'
                          : 'bg-white text-[#44403C] border-[#E5DFD3] hover:border-[#1B4332]'
                      }`}
                    >
                      {pageNum}
                    </button>
                  ))}
                </div>

                <button
                  type="button"
                  disabled={safePage >= totalPages}
                  onClick={() => changeCatalogPage(safePage + 1)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-[#1C1917] bg-white border border-[#D6CEBE] hover:border-[#1B4332] disabled:opacity-40 disabled:cursor-not-allowed rounded-md transition-colors cursor-pointer"
                >
                  <span>다음 목록</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </section>
  );
}
