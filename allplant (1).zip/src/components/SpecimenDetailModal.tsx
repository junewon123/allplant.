import { useEffect } from 'react';
import {
  Bookmark,
  BookmarkCheck,
  ExternalLink,
  Loader2,
  RefreshCw,
  X,
} from 'lucide-react';
import type { PlantProfile, PlantRecommendation } from '../types/plant';
import { CATEGORY_VISUALS } from '../data/botanicalCatalog';
import { PLANT_SPECIES_PHOTOS } from '../data/plantPhotos';
import { SafeImage } from './SafeImage';

interface SpecimenDetailModalProps {
  plant: PlantProfile | null;
  previewRecommendation?: PlantRecommendation | null;
  searchingQuery?: string | null;
  isLoading: boolean;
  error: string | null;
  isSaved: boolean;
  onClose: () => void;
  onToggleSave: (plant: PlantProfile) => void;
  onRefreshFromGoogle: (plantName: string) => void;
}

export function SpecimenDetailModal({
  plant,
  previewRecommendation,
  searchingQuery,
  isLoading,
  error,
  isSaved,
  onClose,
  onToggleSave,
  onRefreshFromGoogle,
}: SpecimenDetailModalProps) {
  useEffect(() => {
    if (!plant && !isLoading && !error) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [plant, isLoading, error, onClose]);

  if (!plant && !isLoading && !error) return null;

  const displayImage =
    (plant?.id ? PLANT_SPECIES_PHOTOS[plant.id] : undefined) ||
    plant?.imageUrl ||
    previewRecommendation?.imageUrl ||
    (plant?.category ? CATEGORY_VISUALS[plant.category]?.imageUrl : undefined) ||
    (previewRecommendation?.category
      ? CATEGORY_VISUALS[previewRecommendation.category]?.imageUrl
      : undefined);

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center bg-[#1C1917]/55 backdrop-blur-[2px] overflow-y-auto p-4 sm:p-6 lg:p-10"
      role="dialog"
      aria-modal="true"
      aria-labelledby="specimen-modal-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative w-full max-w-5xl bg-[#FBF9F5] border border-[#DED7C8] rounded-lg shadow-xl my-auto overflow-hidden">
        {/* Top utility bar */}
        <div className="flex items-center justify-between gap-4 px-6 sm:px-8 py-4 border-b border-[#E5DFD3] bg-[#F5F1E8]">
          <div className="flex items-center gap-2 text-xs text-[#57534E] min-w-0 truncate">
            <span>
              {plant?.category ||
                previewRecommendation?.category ||
                (searchingQuery ? `검색: ${searchingQuery}` : '식물 표본')}
            </span>
            <span aria-hidden="true">·</span>
            <span className="truncate">
              {plant?.origin || '구글 검색 기반 생육 정보'}
            </span>
            <span aria-hidden="true">·</span>
            <span className="font-medium text-[#1B4332]">
              {plant?.difficulty || previewRecommendation?.difficulty || '식물 찾는 중'}
            </span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {plant && !isLoading && (
              <>
                <button
                  type="button"
                  onClick={() => onRefreshFromGoogle(plant.nameKo)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#44403C] hover:text-[#1C1917] border border-[#D6CEBE] bg-[#FBF9F5] hover:bg-white rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  title="구글 실시간 검색으로 최신 관리법 다시 조회"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>구글 최신 조회</span>
                </button>
                <button
                  type="button"
                  onClick={() => onToggleSave(plant)}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    isSaved
                      ? 'bg-[#1B4332] text-[#FBF9F5] border border-[#1B4332]'
                      : 'bg-white text-[#1C1917] border border-[#D6CEBE] hover:border-[#1B4332]'
                  }`}
                >
                  {isSaved ? (
                    <BookmarkCheck className="w-3.5 h-3.5" />
                  ) : (
                    <Bookmark className="w-3.5 h-3.5" />
                  )}
                  <span>{isSaved ? '저장됨' : '도감에 저장'}</span>
                </button>
              </>
            )}

            <button
              type="button"
              onClick={onClose}
              aria-label="상세 정보 닫기"
              className="p-2 text-[#57534E] hover:text-[#1C1917] hover:bg-[#EBE6DC] rounded-md transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Loading state */}
        {isLoading && (
          <div className="p-8 sm:p-12">
            <div className="max-w-xl mx-auto text-center py-8">
              <Loader2 className="w-8 h-8 text-[#1B4332] animate-spin mx-auto mb-4" />
              <h3
                id="specimen-modal-title"
                className="font-editorial text-2xl font-semibold text-[#1C1917] mb-2"
              >
                {previewRecommendation
                  ? `‘${previewRecommendation.nameKo}’ 식물을 찾는 중입니다`
                  : searchingQuery
                    ? `‘${searchingQuery}’ 식물을 찾는 중입니다`
                    : '구글에서 식물 정보와 키우는 방법을 찾는 중입니다'}
              </h3>
              <p className="text-sm text-[#57534E] leading-relaxed">
                물주기, 햇빛 조건, 토양 배합, 향기와 생김새 특징을 정리하고 있습니다.
              </p>
              {previewRecommendation && (
                <div className="mt-6 pt-6 border-t border-[#E5DFD3] text-left">
                  <p className="text-xs text-[#78716C] mb-1">추천 요약</p>
                  <p className="text-sm text-[#292524] leading-relaxed">
                    {previewRecommendation.matchReason}
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Error state */}
        {!isLoading && error && (
          <div className="p-8 sm:p-12 text-center">
            <h3
              id="specimen-modal-title"
              className="font-editorial text-xl font-semibold text-[#1C1917] mb-2"
            >
              식물 정보를 불러오지 못했습니다
            </h3>
            <p className="text-sm text-[#991B1B] mb-6 max-w-md mx-auto leading-relaxed">
              {error}
            </p>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium bg-[#1B4332] text-[#FBF9F5] rounded-md hover:bg-[#143325] transition-colors cursor-pointer"
            >
              돌아가기
            </button>
          </div>
        )}

        {/* Loaded Monograph */}
        {!isLoading && !error && plant && (
          <div className="p-6 sm:p-8 lg:p-10">
            {/* Title Header */}
            <div className="pb-6 border-b border-[#E5DFD3]">
              <div className="flex flex-wrap items-baseline justify-between gap-4">
                <div>
                  <h2
                    id="specimen-modal-title"
                    className="font-editorial text-3xl sm:text-4xl font-semibold text-[#1C1917] tracking-tight"
                  >
                    {plant.nameKo}
                  </h2>
                  <p className="mt-1.5 flex flex-wrap items-center gap-2 text-base text-[#57534E]">
                    <span className="font-binomial italic text-lg text-[#292524]">
                      {plant.scientificName}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="text-sm">{plant.nameEn}</span>
                    <span aria-hidden="true">·</span>
                    <span className="text-sm">{plant.family}</span>
                  </p>
                </div>
                {plant.isGoogleLive && (
                  <span className="text-xs font-medium text-[#1B4332]">
                    구글 검색 정보 반영됨
                  </span>
                )}
              </div>
              <p className="mt-4 text-[15px] sm:text-base text-[#292524] leading-relaxed max-w-3xl">
                {plant.summary}
              </p>
            </div>

            {/* 2-Column Museum Monograph Grid */}
            <div className="mt-8 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10">
              {/* Left Column: Visual & Accession Metadata */}
              <div className="lg:col-span-5 space-y-6">
                <figure className="overflow-hidden rounded-md border border-[#E5DFD3] bg-[#F3EFE6]">
                  <SafeImage
                    key={displayImage || plant.id}
                    src={displayImage}
                    alt={`${plant.nameKo} (${plant.scientificName})`}
                    fallbackLabel={plant.nameKo}
                    className="w-full aspect-[4/3] object-cover"
                  />
                  <figcaption className="px-4 py-2.5 text-xs text-[#57534E] border-t border-[#E5DFD3] bg-[#F9F6F0]">
                    {plant.nameKo} ({plant.scientificName}) · {plant.category} 표본 사진
                  </figcaption>
                </figure>

                {/* Color Palette Swatches */}
                <div className="pt-2">
                  <h3 className="text-xs font-semibold text-[#57534E] tracking-wide mb-2.5">
                    색감 팔레트 및 외형 색조
                  </h3>
                  <div className="flex items-center gap-2.5 mb-2">
                    {(plant.characteristics.colorPalette ?? []).map((hex, i) => (
                      <span
                        key={`${hex}-${i}`}
                        className="w-6 h-6 rounded-full border border-[#D6CEBE]"
                        style={{ backgroundColor: hex }}
                        title={hex}
                      />
                    ))}
                    <span className="text-sm text-[#292524]">
                      {plant.characteristics.colorDescription}
                    </span>
                  </div>
                </div>

                {/* Accession Metadata Definition List */}
                <dl className="divide-y divide-[#E5DFD3] border-y border-[#E5DFD3] text-sm">
                  <div className="py-3 grid grid-cols-3 gap-3">
                    <dt className="text-[#78716C] font-medium">생김새 특징</dt>
                    <dd className="col-span-2 text-[#1C1917] leading-relaxed">
                      {plant.characteristics.appearance}
                    </dd>
                  </div>
                  <div className="py-3 grid grid-cols-3 gap-3">
                    <dt className="text-[#78716C] font-medium">향기 · 냄새</dt>
                    <dd className="col-span-2 text-[#1C1917] leading-relaxed">
                      <span className="font-medium text-[#1B4332]">
                        [{plant.characteristics.scentIntensity}]
                      </span>{' '}
                      {plant.characteristics.scent}
                    </dd>
                  </div>
                  <div className="py-3 grid grid-cols-3 gap-3">
                    <dt className="text-[#78716C] font-medium">크기 · 성장</dt>
                    <dd className="col-span-2 text-[#1C1917] leading-relaxed">
                      {plant.characteristics.sizeAndGrowth}
                    </dd>
                  </div>
                  <div className="py-3 grid grid-cols-3 gap-3">
                    <dt className="text-[#78716C] font-medium">개화 시기</dt>
                    <dd className="col-span-2 text-[#1C1917] leading-relaxed">
                      {plant.characteristics.bloomingSeason}
                    </dd>
                  </div>
                  <div className="py-3 grid grid-cols-3 gap-3">
                    <dt className="text-[#78716C] font-medium">반려동물 안전</dt>
                    <dd className="col-span-2 text-[#1C1917] leading-relaxed">
                      {plant.characteristics.petSafety}
                    </dd>
                  </div>
                </dl>

                {/* Google Search Grounding Sources */}
                {plant.sources && plant.sources.length > 0 && (
                  <div className="pt-2">
                    <h3 className="text-xs font-semibold text-[#57534E] tracking-wide mb-2.5">
                      구글 검색 참고 출처
                    </h3>
                    <ul className="space-y-1.5">
                      {plant.sources.map((src) => (
                        <li key={src.uri}>
                          <a
                            href={src.uri}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1.5 text-xs text-[#1B4332] hover:underline break-all"
                          >
                            <ExternalLink className="w-3 h-3 shrink-0" />
                            <span className="line-clamp-1">{src.title}</span>
                          </a>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Right Column: Complete Care Monograph */}
              <div className="lg:col-span-7">
                <div className="flex items-baseline justify-between pb-4 border-b border-[#E5DFD3]">
                  <h3 className="font-editorial text-2xl font-semibold text-[#1C1917]">
                    키우는 방법 상세 가이드
                  </h3>
                  <span className="text-xs text-[#78716C] tabular-nums">
                    총 7항목 생육 매뉴얼
                  </span>
                </div>

                {/* Quick Summary Strip */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 py-5 border-b border-[#E5DFD3]">
                  <div>
                    <div className="text-xs text-[#78716C] mb-1">물주기 주기</div>
                    <div className="text-sm font-medium text-[#1C1917] leading-snug">
                      {plant.careGuide.wateringCycle}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-[#78716C] mb-1">적정 온도</div>
                    <div className="text-sm font-medium text-[#1C1917] leading-snug">
                      {plant.careGuide.temperature}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-[#78716C] mb-1">선호 습도</div>
                    <div className="text-sm font-medium text-[#1C1917] leading-snug">
                      {plant.careGuide.humidity}
                    </div>
                  </div>
                </div>

                {/* Numbered Editorial Care Sections */}
                <div className="divide-y divide-[#E5DFD3]">
                  <section className="py-4">
                    <h4 className="text-sm font-semibold text-[#1B4332] mb-1.5">
                      01. 물주기 (Watering)
                    </h4>
                    <p className="text-[15px] text-[#292524] leading-relaxed">
                      {plant.careGuide.watering}
                    </p>
                  </section>

                  <section className="py-4">
                    <h4 className="text-sm font-semibold text-[#1B4332] mb-1.5">
                      02. 햇빛과 배치 (Sunlight)
                    </h4>
                    <p className="text-[15px] text-[#292524] leading-relaxed">
                      {plant.careGuide.sunlight}
                    </p>
                  </section>

                  <section className="py-4">
                    <h4 className="text-sm font-semibold text-[#1B4332] mb-1.5">
                      03. 토양 배합 (Soil)
                    </h4>
                    <p className="text-[15px] text-[#292524] leading-relaxed">
                      {plant.careGuide.soil}
                    </p>
                  </section>

                  <section className="py-4">
                    <h4 className="text-sm font-semibold text-[#1B4332] mb-1.5">
                      04. 비료 관리 (Fertilizer)
                    </h4>
                    <p className="text-[15px] text-[#292524] leading-relaxed">
                      {plant.careGuide.fertilizer}
                    </p>
                  </section>

                  <section className="py-4">
                    <h4 className="text-sm font-semibold text-[#1B4332] mb-1.5">
                      05. 가지치기 및 분갈이 (Pruning & Repotting)
                    </h4>
                    <p className="text-[15px] text-[#292524] leading-relaxed">
                      {plant.careGuide.pruningAndRepotting}
                    </p>
                  </section>

                  <section className="py-4">
                    <h4 className="text-sm font-semibold text-[#1B4332] mb-1.5">
                      06. 병해충 및 자주 겪는 문제
                    </h4>
                    <p className="text-[15px] text-[#292524] leading-relaxed">
                      {plant.careGuide.commonIssues}
                    </p>
                  </section>

                  <section className="pt-4 pb-1">
                    <h4 className="text-sm font-semibold text-[#57534E] mb-1.5">
                      07. 식물학 노트
                    </h4>
                    <p className="text-sm text-[#44403C] leading-relaxed italic">
                      {plant.funFact}
                    </p>
                  </section>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
