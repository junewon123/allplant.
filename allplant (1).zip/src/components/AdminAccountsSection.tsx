import { useEffect, useMemo, useState } from 'react';
import {
  collection,
  deleteField,
  doc,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  updateDoc,
  type Timestamp,
} from 'firebase/firestore';
import {
  Ban,
  CheckCircle2,
  Loader2,
  Search,
  ShieldCheck,
  UserX,
  Users,
  X,
} from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { BOOTSTRAPPED_ADMIN_EMAIL } from '../types/community';

export interface UserAccountRecord {
  uid: string;
  email: string;
  displayName: string;
  photoUrl: string;
  loginCount: number;
  firstLoginAt?: Timestamp | null;
  lastLoginAt?: Timestamp | null;
  isBanned?: boolean;
  banReason?: string;
  bannedAt?: Timestamp | null;
  kickedAt?: Timestamp | null;
}

export interface GuestVisitRecord {
  visitorId: string;
  label: string;
  visitCount: number;
  firstVisitAt?: Timestamp | null;
  lastVisitAt?: Timestamp | null;
  isBanned?: boolean;
  banReason?: string;
  bannedAt?: Timestamp | null;
  kickedAt?: Timestamp | null;
}

interface UnifiedVisitorEntry {
  kind: 'member' | 'guest';
  collectionName: 'userAccounts' | 'guestVisits';
  docId: string;
  displayName: string;
  emailOrLabel: string;
  photoUrl: string;
  count: number;
  firstAt?: Timestamp | null;
  lastAt?: Timestamp | null;
  isBanned?: boolean;
  banReason?: string;
  bannedAt?: Timestamp | null;
  kickedAt?: Timestamp | null;
  isOwnerAdmin: boolean;
}

function formatDateTime(ts?: Timestamp | null): string {
  if (!ts) return '방금 전';
  try {
    return new Intl.DateTimeFormat('ko-KR', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    }).format(ts.toDate());
  } catch {
    return '-';
  }
}

export function AdminAccountsSection() {
  const [accounts, setAccounts] = useState<UserAccountRecord[]>([]);
  const [guestVisits, setGuestVisits] = useState<GuestVisitRecord[]>([]);
  const [accountsLoaded, setAccountsLoaded] = useState(false);
  const [guestsLoaded, setGuestsLoaded] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [actionNotice, setActionNotice] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'member' | 'guest' | 'banned'>('all');

  const [pendingKickKey, setPendingKickKey] = useState<string | null>(null);
  const [pendingUnbanKey, setPendingUnbanKey] = useState<string | null>(null);
  const [banTarget, setBanTarget] = useState<UnifiedVisitorEntry | null>(null);
  const [banReasonInput, setBanReasonInput] = useState('');
  const [busyKey, setBusyKey] = useState<string | null>(null);

  useEffect(() => {
    const accountsQuery = query(
      collection(db, 'userAccounts'),
      orderBy('lastLoginAt', 'desc'),
      limit(100)
    );

    const guestsQuery = query(
      collection(db, 'guestVisits'),
      orderBy('lastVisitAt', 'desc'),
      limit(100)
    );

    const unsubAccounts = onSnapshot(
      accountsQuery,
      (snapshot) => {
        const items: UserAccountRecord[] = snapshot.docs.map((d) => ({
          uid: d.id,
          ...(d.data() as Omit<UserAccountRecord, 'uid'>),
        }));
        setAccounts(items);
        setError(null);
        setAccountsLoaded(true);
      },
      (err) => {
        setAccountsLoaded(true);
        const raw = err instanceof Error ? err.message : String(err);
        if (raw.toLowerCase().includes('quota')) {
          setError('일일 데이터베이스 읽기 한도를 초과했습니다. 내일 다시 확인해 주세요.');
        } else {
          setError(
            '로그인한 계정 목록을 불러오지 못했습니다. 관리자 권한 및 로그인 상태를 확인해 주세요.'
          );
        }
        try {
          handleFirestoreError(err, OperationType.LIST, 'userAccounts');
        } catch {
          // Handled via local UI error banner
        }
      }
    );

    const unsubGuests = onSnapshot(
      guestsQuery,
      (snapshot) => {
        const items: GuestVisitRecord[] = snapshot.docs.map((d) => ({
          visitorId: d.id,
          ...(d.data() as Omit<GuestVisitRecord, 'visitorId'>),
        }));
        setGuestVisits(items);
        setGuestsLoaded(true);
      },
      (err) => {
        setGuestsLoaded(true);
        try {
          handleFirestoreError(err, OperationType.LIST, 'guestVisits');
        } catch {
          // Non-blocking error logging
        }
      }
    );

    return () => {
      unsubAccounts();
      unsubGuests();
    };
  }, []);

  const isLoading = !accountsLoaded || !guestsLoaded;

  const allEntries = useMemo<UnifiedVisitorEntry[]>(() => {
    const memberEntries: UnifiedVisitorEntry[] = accounts.map((acc) => ({
      kind: 'member',
      collectionName: 'userAccounts',
      docId: acc.uid,
      displayName: acc.displayName,
      emailOrLabel: acc.email,
      photoUrl: acc.photoUrl,
      count: Number(acc.loginCount) || 1,
      firstAt: acc.firstLoginAt,
      lastAt: acc.lastLoginAt,
      isBanned: acc.isBanned,
      banReason: acc.banReason,
      bannedAt: acc.bannedAt,
      kickedAt: acc.kickedAt,
      isOwnerAdmin: acc.email.toLowerCase() === BOOTSTRAPPED_ADMIN_EMAIL.toLowerCase(),
    }));

    const guestEntries: UnifiedVisitorEntry[] = guestVisits.map((g) => ({
      kind: 'guest',
      collectionName: 'guestVisits',
      docId: g.visitorId,
      displayName: '비로그인',
      emailOrLabel: '비로그인 방문',
      photoUrl: '',
      count: Number(g.visitCount) || 1,
      firstAt: g.firstVisitAt,
      lastAt: g.lastVisitAt,
      isBanned: g.isBanned,
      banReason: g.banReason,
      bannedAt: g.bannedAt,
      kickedAt: g.kickedAt,
      isOwnerAdmin: false,
    }));

    return [...memberEntries, ...guestEntries].sort((a, b) => {
      const aMs = a.lastAt?.toMillis?.() ?? 0;
      const bMs = b.lastAt?.toMillis?.() ?? 0;
      return bMs - aMs;
    });
  }, [accounts, guestVisits]);

  const filteredEntries = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return allEntries.filter((entry) => {
      if (statusFilter === 'member' && entry.kind !== 'member') return false;
      if (statusFilter === 'guest' && entry.kind !== 'guest') return false;
      if (statusFilter === 'banned' && !entry.isBanned) return false;
      if (!q) return true;
      return (
        entry.displayName.toLowerCase().includes(q) ||
        entry.emailOrLabel.toLowerCase().includes(q) ||
        entry.docId.toLowerCase().includes(q)
      );
    });
  }, [allEntries, searchQuery, statusFilter]);

  const totalVisits = useMemo(
    () => allEntries.reduce((sum, entry) => sum + entry.count, 0),
    [allEntries]
  );

  const activeTodayCount = useMemo(() => {
    const cutoff = Date.now() - 24 * 60 * 60 * 1000;
    return allEntries.filter((entry) => (entry.lastAt?.toMillis?.() ?? 0) >= cutoff).length;
  }, [allEntries]);

  const bannedCount = useMemo(
    () => allEntries.filter((entry) => entry.isBanned === true).length,
    [allEntries]
  );

  const entryKey = (entry: UnifiedVisitorEntry) => `${entry.collectionName}:${entry.docId}`;

  const handleKickEntry = async (entry: UnifiedVisitorEntry) => {
    const key = entryKey(entry);
    setBusyKey(key);
    setActionNotice(null);
    try {
      await updateDoc(doc(db, entry.collectionName, entry.docId), {
        kickedAt: serverTimestamp(),
      });
      setPendingKickKey(null);
      setActionNotice({
        type: 'success',
        message:
          entry.kind === 'guest'
            ? `비로그인 방문자(${entry.docId})를 강제 퇴장(쫓아내기) 처리했습니다.`
            : `${entry.displayName} (${entry.emailOrLabel}) 계정을 강제 로그아웃(쫓아내기) 처리했습니다.`,
      });
    } catch (err) {
      setActionNotice({
        type: 'error',
        message: `${entry.displayName} 쫓아내기 처리 중 오류가 발생했습니다.`,
      });
      try {
        handleFirestoreError(
          err,
          OperationType.UPDATE,
          `${entry.collectionName}/${entry.docId}`
        );
      } catch {
        // Logged via handleFirestoreError
      }
    } finally {
      setBusyKey(null);
    }
  };

  const handleConfirmBan = async () => {
    if (!banTarget) return;
    const key = entryKey(banTarget);
    setBusyKey(key);
    setActionNotice(null);
    const cleanedReason =
      banReasonInput.trim().slice(0, 200) || '관리자에 의해 서비스 이용이 정지되었습니다.';

    try {
      await updateDoc(doc(db, banTarget.collectionName, banTarget.docId), {
        isBanned: true,
        banReason: cleanedReason,
        bannedAt: serverTimestamp(),
      });
      setActionNotice({
        type: 'success',
        message:
          banTarget.kind === 'guest'
            ? `비로그인 방문자(${banTarget.docId})의 접속을 정지(벤) 처리했습니다.`
            : `${banTarget.displayName} (${banTarget.emailOrLabel}) 계정을 이용 정지(벤) 처리했습니다.`,
      });
      setBanTarget(null);
      setBanReasonInput('');
    } catch (err) {
      setActionNotice({
        type: 'error',
        message: `${banTarget.displayName} 벤 처리 중 오류가 발생했습니다.`,
      });
      try {
        handleFirestoreError(
          err,
          OperationType.UPDATE,
          `${banTarget.collectionName}/${banTarget.docId}`
        );
      } catch {
        // Logged via handleFirestoreError
      }
    } finally {
      setBusyKey(null);
    }
  };

  const handleUnbanEntry = async (entry: UnifiedVisitorEntry) => {
    const key = entryKey(entry);
    setBusyKey(key);
    setActionNotice(null);
    try {
      await updateDoc(doc(db, entry.collectionName, entry.docId), {
        isBanned: false,
        banReason: deleteField(),
        bannedAt: deleteField(),
      });
      setPendingUnbanKey(null);
      setActionNotice({
        type: 'success',
        message:
          entry.kind === 'guest'
            ? `비로그인 방문자(${entry.docId})의 이용 정지(벤)를 해제했습니다.`
            : `${entry.displayName} (${entry.emailOrLabel}) 계정의 이용 정지(벤)를 해제했습니다.`,
      });
    } catch (err) {
      setActionNotice({
        type: 'error',
        message: `${entry.displayName} 벤 해제 중 오류가 발생했습니다.`,
      });
      try {
        handleFirestoreError(
          err,
          OperationType.UPDATE,
          `${entry.collectionName}/${entry.docId}`
        );
      } catch {
        // Logged via handleFirestoreError
      }
    } finally {
      setBusyKey(null);
    }
  };

  return (
    <section id="admin-accounts" className="py-10 lg:py-14 bg-[#F5F1E8]/40 flex-1">
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 pb-6 border-b border-[#E5DFD3]">
          <div>
            <p className="inline-flex items-center gap-1.5 text-xs font-medium text-[#1B4332] mb-1.5">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>관리자 전용 ({BOOTSTRAPPED_ADMIN_EMAIL})</span>
            </p>
            <h2 className="font-editorial text-2xl sm:text-3xl font-semibold text-[#1C1917]">
              올플랜트 방문 · 계정 관리 ({allEntries.length})
            </h2>
            <p className="mt-1.5 text-sm text-[#57534E]">
              Google 로그인 회원과 비로그인 방문 기록을 실시간으로 확인하고, 필요 시 쫓아내기 및 벤을 관리합니다.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
            <div className="inline-flex items-center gap-1 p-1 bg-[#F3EFE6] border border-[#E5DFD3] rounded-md self-start sm:self-auto overflow-x-auto max-w-full">
              {(
                [
                  { id: 'all', label: `전체 (${allEntries.length})` },
                  { id: 'member', label: `로그인 (${accounts.length})` },
                  { id: 'guest', label: `비로그인 (${guestVisits.length})` },
                  { id: 'banned', label: `벤 (${bannedCount})` },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setStatusFilter(tab.id)}
                  className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap cursor-pointer ${
                    statusFilter === tab.id
                      ? 'bg-white text-[#1C1917] shadow-xs'
                      : 'text-[#57534E] hover:text-[#1C1917]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="relative w-full sm:w-60">
              <Search className="w-4 h-4 text-[#78716C] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="이름, 이메일 또는 비로그인 검색"
                className="w-full h-10 pl-10 pr-3 text-sm bg-white border border-[#D6CEBE] rounded-md text-[#1C1917] placeholder:text-[#78716C] focus:outline-none focus:border-[#1B4332] focus:ring-1 focus:ring-[#1B4332]"
              />
            </div>
          </div>
        </div>

        {/* Summary Metrics */}
        <div className="mt-6 grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white border border-[#E5DFD3] rounded-lg p-5">
            <div className="text-xs text-[#78716C]">전체 방문 기록</div>
            <div className="mt-1 font-editorial text-2xl font-semibold text-[#1C1917] tabular-nums">
              {allEntries.length}건
            </div>
            <div className="mt-1 text-[11px] text-[#57534E] tabular-nums">
              로그인 {accounts.length}명 · 비로그인 {guestVisits.length}건
            </div>
          </div>
          <div className="bg-white border border-[#E5DFD3] rounded-lg p-5">
            <div className="text-xs text-[#78716C]">최근 24시간 내 접속</div>
            <div className="mt-1 font-editorial text-2xl font-semibold text-[#1B4332] tabular-nums">
              {activeTodayCount}건
            </div>
          </div>
          <div className="bg-white border border-[#E5DFD3] rounded-lg p-5">
            <div className="text-xs text-[#78716C]">누적 접속 · 방문 횟수</div>
            <div className="mt-1 font-editorial text-2xl font-semibold text-[#1C1917] tabular-nums">
              {totalVisits}회
            </div>
          </div>
          <div className="bg-white border border-[#E5DFD3] rounded-lg p-5">
            <div className="text-xs text-[#78716C]">이용 정지(벤)</div>
            <div className="mt-1 font-editorial text-2xl font-semibold text-[#991B1B] tabular-nums">
              {bannedCount}건
            </div>
          </div>
        </div>

        {actionNotice && (
          <div
            className={`mt-5 p-3.5 rounded-md border flex items-center justify-between gap-3 text-sm ${
              actionNotice.type === 'success'
                ? 'bg-[#ECFDF5] border-[#A7F3D0] text-[#065F46]'
                : 'bg-[#FEF2F2] border-[#FECACA] text-[#991B1B]'
            }`}
          >
            <div className="flex items-center gap-2">
              {actionNotice.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0" />
              ) : (
                <Ban className="w-4 h-4 shrink-0" />
              )}
              <span>{actionNotice.message}</span>
            </div>
            <button
              type="button"
              onClick={() => setActionNotice(null)}
              aria-label="알림 닫기"
              className="p-1 opacity-70 hover:opacity-100 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {error && (
          <div className="mt-6 p-4 bg-[#FEF2F2] border border-[#FECACA] rounded-md text-sm text-[#991B1B]">
            {error}
          </div>
        )}

        {isLoading ? (
          <div className="mt-8 bg-white border border-[#E5DFD3] rounded-lg p-12 text-center">
            <Loader2 className="w-7 h-7 text-[#1B4332] animate-spin mx-auto mb-3" />
            <p className="text-sm text-[#57534E]">방문 및 계정 목록을 불러오는 중입니다...</p>
          </div>
        ) : filteredEntries.length === 0 ? (
          <div className="mt-8 bg-white border border-[#E5DFD3] rounded-lg p-12 text-center">
            <Users className="w-8 h-8 text-[#78716C] mx-auto mb-3" />
            <p className="font-editorial text-lg text-[#1C1917]">
              {searchQuery || statusFilter !== 'all'
                ? '조건과 일치하는 방문 기록이 없습니다'
                : '아직 기록된 방문 기록이 없습니다'}
            </p>
          </div>
        ) : (
          <div className="mt-6 bg-white border border-[#E5DFD3] rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-[#E5DFD3] bg-[#F9F6F0] text-xs font-semibold text-[#57534E]">
                    <th className="py-3.5 px-5">구분 / 이름</th>
                    <th className="py-3.5 px-5">이메일 / 방문 형태</th>
                    <th className="py-3.5 px-5">상태</th>
                    <th className="py-3.5 px-5">방문 횟수</th>
                    <th className="py-3.5 px-5">최근 접속</th>
                    <th className="py-3.5 px-5 text-right">관리 작업</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E5DFD3] text-sm">
                  {filteredEntries.map((entry) => {
                    const key = entryKey(entry);
                    const isRowBusy = busyKey === key;
                    const isConfirmingKick = pendingKickKey === key;
                    const isConfirmingUnban = pendingUnbanKey === key;
                    const isGuest = entry.kind === 'guest';

                    return (
                      <tr
                        key={key}
                        className={`transition-colors ${
                          entry.isBanned ? 'bg-[#FEF2F2]/40' : 'hover:bg-[#FBF9F5]'
                        }`}
                      >
                        <td className="py-3.5 px-5">
                          <div className="flex items-center gap-3">
                            {entry.photoUrl ? (
                              <img
                                src={entry.photoUrl}
                                alt={entry.displayName}
                                className="w-8 h-8 rounded-full object-cover border border-[#E5DFD3] shrink-0"
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              <div
                                className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold shrink-0 ${
                                  isGuest
                                    ? 'bg-[#E5DFD3] text-[#44403C]'
                                    : 'bg-[#1B4332] text-[#FBF9F5]'
                                }`}
                              >
                                {isGuest ? '비' : entry.displayName.slice(0, 1)}
                              </div>
                            )}
                            <div className="min-w-0">
                              <div className="font-medium text-[#1C1917] flex items-center gap-1.5">
                                <span className="truncate">{entry.displayName}</span>
                                {entry.isOwnerAdmin && (
                                  <span className="text-[11px] font-medium text-[#1B4332]">
                                    (관리자)
                                  </span>
                                )}
                              </div>
                              <div className="text-[11px] text-[#78716C] truncate max-w-[180px]">
                                {isGuest ? `ID: ${entry.docId}` : `UID: ${entry.docId}`}
                              </div>
                            </div>
                          </div>
                        </td>

                        <td className="py-3.5 px-5">
                          {isGuest ? (
                            <span className="text-xs font-medium text-[#57534E]">
                              비로그인 방문
                            </span>
                          ) : (
                            <span className="text-[#292524]">{entry.emailOrLabel}</span>
                          )}
                        </td>

                        <td className="py-3.5 px-5">
                          {entry.isBanned ? (
                            <div>
                              <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#991B1B]">
                                <Ban className="w-3.5 h-3.5" />
                                <span>이용 정지(벤)</span>
                              </span>
                              {entry.banReason && (
                                <p
                                  className="mt-0.5 text-[11px] text-[#7F1D1D] max-w-[200px] truncate"
                                  title={entry.banReason}
                                >
                                  사유: {entry.banReason}
                                </p>
                              )}
                            </div>
                          ) : (
                            <div>
                              <span className="text-xs font-medium text-[#1B4332]">정상</span>
                              {entry.kickedAt && (
                                <p className="mt-0.5 text-[11px] text-[#78716C] whitespace-nowrap">
                                  최근 추방: {formatDateTime(entry.kickedAt)}
                                </p>
                              )}
                            </div>
                          )}
                        </td>

                        <td className="py-3.5 px-5 font-medium text-[#1B4332] tabular-nums whitespace-nowrap">
                          {entry.count}회
                        </td>

                        <td className="py-3.5 px-5 text-xs text-[#1C1917] tabular-nums whitespace-nowrap">
                          <div>{formatDateTime(entry.lastAt)}</div>
                          <div className="text-[11px] text-[#78716C]">
                            최초: {formatDateTime(entry.firstAt)}
                          </div>
                        </td>

                        <td className="py-3.5 px-5 text-right whitespace-nowrap">
                          {entry.isOwnerAdmin ? (
                            <span className="text-xs text-[#78716C]">보호됨 (관리자)</span>
                          ) : (
                            <div className="inline-flex items-center justify-end gap-2">
                              {isConfirmingKick ? (
                                <div className="inline-flex items-center gap-1.5 bg-[#FFFBEB] border border-[#FDE68A] px-2 py-1 rounded-md">
                                  <span className="text-[11px] text-[#92400E]">추방할까요?</span>
                                  <button
                                    type="button"
                                    disabled={isRowBusy}
                                    onClick={() => void handleKickEntry(entry)}
                                    className="px-2 py-0.5 text-[11px] font-medium bg-[#B45309] text-white rounded hover:bg-[#92400E] disabled:opacity-50 cursor-pointer"
                                  >
                                    {isRowBusy ? '처리 중' : '확인'}
                                  </button>
                                  <button
                                    type="button"
                                    disabled={isRowBusy}
                                    onClick={() => setPendingKickKey(null)}
                                    className="px-2 py-0.5 text-[11px] text-[#57534E] hover:text-[#1C1917] cursor-pointer"
                                  >
                                    취소
                                  </button>
                                </div>
                              ) : (
                                <button
                                  type="button"
                                  disabled={isRowBusy}
                                  onClick={() => {
                                    setPendingUnbanKey(null);
                                    setPendingKickKey(key);
                                  }}
                                  className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-[#92400E] bg-[#FFFBEB] border border-[#FDE68A] hover:bg-[#FEF3C7] rounded-md transition-colors disabled:opacity-50 cursor-pointer"
                                >
                                  <UserX className="w-3.5 h-3.5" />
                                  <span>쫓아내기</span>
                                </button>
                              )}

                              {entry.isBanned ? (
                                isConfirmingUnban ? (
                                  <div className="inline-flex items-center gap-1.5 bg-[#ECFDF5] border border-[#A7F3D0] px-2 py-1 rounded-md">
                                    <span className="text-[11px] text-[#065F46]">해제할까요?</span>
                                    <button
                                      type="button"
                                      disabled={isRowBusy}
                                      onClick={() => void handleUnbanEntry(entry)}
                                      className="px-2 py-0.5 text-[11px] font-medium bg-[#1B4332] text-white rounded hover:bg-[#143325] disabled:opacity-50 cursor-pointer"
                                    >
                                      {isRowBusy ? '처리 중' : '해제'}
                                    </button>
                                    <button
                                      type="button"
                                      disabled={isRowBusy}
                                      onClick={() => setPendingUnbanKey(null)}
                                      className="px-2 py-0.5 text-[11px] text-[#57534E] hover:text-[#1C1917] cursor-pointer"
                                    >
                                      취소
                                    </button>
                                  </div>
                                ) : (
                                  <button
                                    type="button"
                                    disabled={isRowBusy}
                                    onClick={() => {
                                      setPendingKickKey(null);
                                      setPendingUnbanKey(key);
                                    }}
                                    className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-[#1B4332] bg-[#ECFDF5] border border-[#A7F3D0] hover:bg-[#D1FAE5] rounded-md transition-colors disabled:opacity-50 cursor-pointer"
                                  >
                                    <CheckCircle2 className="w-3.5 h-3.5" />
                                    <span>벤 해제</span>
                                  </button>
                                )
                              ) : (
                                <button
                                  type="button"
                                  disabled={isRowBusy}
                                  onClick={() => {
                                    setPendingKickKey(null);
                                    setPendingUnbanKey(null);
                                    setBanTarget(entry);
                                    setBanReasonInput('');
                                  }}
                                  className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-[#991B1B] bg-[#FEF2F2] border border-[#FECACA] hover:bg-[#FEE2E2] rounded-md transition-colors disabled:opacity-50 cursor-pointer"
                                >
                                  <Ban className="w-3.5 h-3.5" />
                                  <span>벤하기</span>
                                </button>
                              )}
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Ban Confirmation Modal */}
      {banTarget && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="ban-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 px-4"
        >
          <div className="w-full max-w-md bg-[#FBF9F5] border border-[#E5DFD3] rounded-lg shadow-xl p-6">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-xs font-medium text-[#991B1B] flex items-center gap-1">
                  <Ban className="w-3.5 h-3.5" />
                  <span>접속 이용 정지 (벤)</span>
                </p>
                <h3
                  id="ban-modal-title"
                  className="mt-1 font-editorial text-xl font-semibold text-[#1C1917]"
                >
                  {banTarget.kind === 'guest'
                    ? '비로그인 방문자를 벤할까요?'
                    : `${banTarget.displayName} 계정을 벤할까요?`}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setBanTarget(null)}
                aria-label="창 닫기"
                className="p-1 text-[#78716C] hover:text-[#1C1917] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="mt-2 text-xs text-[#57534E] leading-relaxed">
              대상:{' '}
              <strong className="text-[#1C1917]">
                {banTarget.kind === 'guest'
                  ? `비로그인 (${banTarget.docId})`
                  : banTarget.emailOrLabel}
              </strong>
              <br />
              벤 처리되면 즉시 이용이 차단되며, 벤을 해제하기 전까지 올플랜트에 접속할 수
              없습니다.
            </p>

            <div className="mt-4">
              <label
                htmlFor="ban-reason-input"
                className="block text-xs font-medium text-[#44403C] mb-1.5"
              >
                정지 사유 (선택)
              </label>
              <input
                id="ban-reason-input"
                type="text"
                maxLength={200}
                value={banReasonInput}
                onChange={(e) => setBanReasonInput(e.target.value)}
                placeholder="관리자에 의해 서비스 이용이 정지되었습니다."
                className="w-full h-10 px-3 text-sm bg-white border border-[#D6CEBE] rounded-md text-[#1C1917] placeholder:text-[#78716C] focus:outline-none focus:border-[#991B1B] focus:ring-1 focus:ring-[#991B1B]"
              />
            </div>

            <div className="mt-6 flex items-center justify-end gap-2.5">
              <button
                type="button"
                disabled={busyKey === entryKey(banTarget)}
                onClick={() => setBanTarget(null)}
                className="px-4 py-2 text-xs font-medium text-[#44403C] bg-white border border-[#D6CEBE] hover:border-[#1C1917] rounded-md transition-colors cursor-pointer"
              >
                취소
              </button>
              <button
                type="button"
                disabled={busyKey === entryKey(banTarget)}
                onClick={() => void handleConfirmBan()}
                className="px-4 py-2 text-xs font-medium text-white bg-[#991B1B] hover:bg-[#7F1D1D] disabled:opacity-50 rounded-md transition-colors inline-flex items-center gap-1.5 cursor-pointer"
              >
                {busyKey === entryKey(banTarget) && (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                )}
                <span>벤 확정</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
