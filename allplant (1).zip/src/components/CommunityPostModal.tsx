import { useEffect, useState } from 'react';
import type { User } from 'firebase/auth';
import {
  collection,
  doc,
  increment,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  writeBatch,
} from 'firebase/firestore';
import { Heart, Loader2, MessageSquare, Trash2, X } from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  COMMUNITY_LIMITS,
  type CommunityPost,
  type PostComment,
} from '../types/community';
import { SafeImage } from './SafeImage';

interface CommunityPostModalProps {
  post: CommunityPost | null;
  user: User | null;
  isAdmin: boolean;
  isLiked: boolean;
  onClose: () => void;
  onToggleLike: (post: CommunityPost) => void;
  onDeletePost: (post: CommunityPost) => Promise<void>;
  onRequireSignIn: () => void;
}

function formatDate(ts: CommunityPost['createdAt']): string {
  if (!ts) return '방금 전';
  try {
    const date = ts.toDate();
    return new Intl.DateTimeFormat('ko-KR', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(date);
  } catch {
    return '';
  }
}

export function CommunityPostModal({
  post,
  user,
  isAdmin,
  isLiked,
  onClose,
  onToggleLike,
  onDeletePost,
  onRequireSignIn,
}: CommunityPostModalProps) {
  const [comments, setComments] = useState<PostComment[]>([]);
  const [commentText, setCommentText] = useState('');
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);
  const [confirmDeletePost, setConfirmDeletePost] = useState(false);
  const [isDeletingPost, setIsDeletingPost] = useState(false);
  const [commentError, setCommentError] = useState<string | null>(null);

  useEffect(() => {
    if (!post) return;
    setConfirmDeletePost(false);
    setCommentError(null);

    const commentsPath = `communityPosts/${post.id}/comments`;
    const q = query(
      collection(db, 'communityPosts', post.id, 'comments'),
      orderBy('createdAt', 'asc'),
      limit(100)
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const items: PostComment[] = snapshot.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<PostComment, 'id'>),
        }));
        setComments(items);
        setCommentError(null);
      },
      (error) => {
        setCommentError('댓글 목록을 불러오지 못했습니다. 새로고침 후 다시 시도해 주세요.');
        handleFirestoreError(error, OperationType.LIST, commentsPath);
      }
    );

    return () => unsubscribe();
  }, [post]);

  useEffect(() => {
    if (!post) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [post, onClose]);

  if (!post) return null;

  const canDeletePost = Boolean(
    user && (user.uid === post.authorId || isAdmin)
  );
  const isAdminModerating = Boolean(
    user && isAdmin && user.uid !== post.authorId
  );

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      onRequireSignIn();
      return;
    }

    const trimmed = commentText.trim().slice(0, COMMUNITY_LIMITS.COMMENT_MAX);
    if (!trimmed) return;

    setIsSubmittingComment(true);
    setCommentError(null);

    const commentRef = doc(collection(db, 'communityPosts', post.id, 'comments'));
    const postRef = doc(db, 'communityPosts', post.id);
    const authorName = (user.displayName || user.email?.split('@')[0] || '가드너')
      .trim()
      .slice(0, COMMUNITY_LIMITS.AUTHOR_NAME_MAX);
    const authorPhotoUrl = (user.photoURL || '').slice(
      0,
      COMMUNITY_LIMITS.AUTHOR_PHOTO_MAX
    );

    try {
      const batch = writeBatch(db);
      batch.set(commentRef, {
        postId: post.id,
        authorId: user.uid,
        authorName,
        authorPhotoUrl,
        content: trimmed,
        createdAt: serverTimestamp(),
      });
      batch.update(postRef, {
        commentsCount: increment(1),
        updatedAt: serverTimestamp(),
      });
      await batch.commit();
      setCommentText('');
    } catch (error) {
      setCommentError('댓글을 등록하지 못했습니다. 다시 시도해 주세요.');
      handleFirestoreError(
        error,
        OperationType.CREATE,
        `communityPosts/${post.id}/comments/${commentRef.id}`
      );
    } finally {
      setIsSubmittingComment(false);
    }
  };

  const handleDeleteComment = async (comment: PostComment) => {
    if (!user) return;
    const commentRef = doc(
      db,
      'communityPosts',
      post.id,
      'comments',
      comment.id
    );
    const postRef = doc(db, 'communityPosts', post.id);

    try {
      const batch = writeBatch(db);
      batch.delete(commentRef);
      batch.update(postRef, {
        commentsCount: increment(-1),
        updatedAt: serverTimestamp(),
      });
      await batch.commit();
    } catch (error) {
      handleFirestoreError(
        error,
        OperationType.DELETE,
        `communityPosts/${post.id}/comments/${comment.id}`
      );
    }
  };

  const handleConfirmDeletePost = async () => {
    setIsDeletingPost(true);
    try {
      await onDeletePost(post);
      onClose();
    } finally {
      setIsDeletingPost(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center bg-[#1C1917]/55 backdrop-blur-[2px] overflow-y-auto p-4 sm:p-6 lg:p-10"
      role="dialog"
      aria-modal="true"
      aria-labelledby="community-post-modal-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative w-full max-w-3xl bg-[#FBF9F5] border border-[#DED7C8] rounded-lg shadow-xl my-auto overflow-hidden">
        {/* Top bar */}
        <div className="flex items-center justify-between gap-4 px-6 py-4 border-b border-[#E5DFD3] bg-[#F5F1E8]">
          <div className="flex items-center gap-2 text-xs text-[#57534E] min-w-0 truncate">
            <span>{post.category}</span>
            <span aria-hidden="true">·</span>
            <span className="font-medium text-[#1B4332]">{post.postType}</span>
            {post.plantName && (
              <>
                <span aria-hidden="true">·</span>
                <span className="truncate">{post.plantName}</span>
              </>
            )}
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {canDeletePost && !confirmDeletePost && (
              <button
                type="button"
                onClick={() => setConfirmDeletePost(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#991B1B] bg-white border border-[#FECACA] hover:bg-[#FEF2F2] rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{isAdminModerating ? '관리자 삭제' : '게시글 삭제'}</span>
              </button>
            )}

            {confirmDeletePost && (
              <div className="flex items-center gap-2">
                <span className="text-xs text-[#991B1B] font-medium">
                  정말 삭제할까요?
                </span>
                <button
                  type="button"
                  disabled={isDeletingPost}
                  onClick={() => void handleConfirmDeletePost()}
                  className="px-2.5 py-1 text-xs font-medium text-white bg-[#991B1B] hover:bg-[#7F1D1D] rounded transition-colors cursor-pointer"
                >
                  {isDeletingPost ? '삭제 중' : '삭제'}
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmDeletePost(false)}
                  className="px-2.5 py-1 text-xs text-[#57534E] bg-white border border-[#D6CEBE] rounded hover:text-[#1C1917] cursor-pointer"
                >
                  취소
                </button>
              </div>
            )}

            <button
              type="button"
              onClick={onClose}
              aria-label="게시글 닫기"
              className="p-1.5 text-[#57534E] hover:text-[#1C1917] hover:bg-[#EBE6DC] rounded-md transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Post Body */}
        <div className="p-6 sm:p-8">
          <h2
            id="community-post-modal-title"
            className="font-editorial text-2xl sm:text-3xl font-semibold text-[#1C1917] leading-snug"
          >
            {post.title}
          </h2>

          <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-[#57534E] pb-5 border-b border-[#E5DFD3]">
            <span className="font-medium text-[#1C1917]">{post.authorName}</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">{formatDate(post.createdAt)}</span>
          </div>

          {post.photoDataUrl && (
            <figure className="mt-6 overflow-hidden rounded-lg border border-[#E5DFD3] bg-[#F3EFE6]">
              <SafeImage
                src={post.photoDataUrl}
                alt={post.title}
                fallbackLabel={post.plantName || post.title}
                className="w-full max-h-[460px] object-contain mx-auto bg-[#F3EFE6]"
              />
            </figure>
          )}

          <div className="mt-6 text-[15px] text-[#292524] leading-relaxed whitespace-pre-wrap break-words">
            {post.content}
          </div>

          {/* Like & Comment Summary Bar */}
          <div className="mt-8 pt-4 border-t border-[#E5DFD3] flex items-center gap-4">
            <button
              type="button"
              onClick={() => onToggleLike(post)}
              className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-md border transition-colors cursor-pointer ${
                isLiked
                  ? 'bg-[#1B4332] text-[#FBF9F5] border-[#1B4332]'
                  : 'bg-white text-[#1C1917] border-[#D6CEBE] hover:border-[#1B4332]'
              }`}
            >
              <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-current' : ''}`} />
              <span className="tabular-nums">좋아요 {post.likesCount}</span>
            </button>

            <div className="inline-flex items-center gap-1.5 text-xs text-[#57534E] tabular-nums">
              <MessageSquare className="w-3.5 h-3.5" />
              <span>댓글 {comments.length}</span>
            </div>
          </div>

          {/* Comments Section */}
          <div className="mt-8 pt-6 border-t border-[#E5DFD3]">
            <h3 className="font-editorial text-lg font-semibold text-[#1C1917] mb-4">
              댓글 ({comments.length})
            </h3>

            {comments.length === 0 ? (
              <p className="text-sm text-[#78716C] py-4">
                아직 댓글이 없습니다. 첫 번째 가드닝 팁이나 응원의 말을 남겨 보세요.
              </p>
            ) : (
              <ul className="divide-y divide-[#E5DFD3] mb-6">
                {comments.map((comment) => {
                  const canDeleteComment = Boolean(
                    user && (user.uid === comment.authorId || isAdmin)
                  );
                  return (
                    <li key={comment.id} className="py-3.5">
                      <div className="flex items-center justify-between gap-2 text-xs">
                        <div className="flex items-center gap-2 text-[#57534E]">
                          <span className="font-medium text-[#1C1917]">
                            {comment.authorName}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span className="tabular-nums">
                            {formatDate(comment.createdAt)}
                          </span>
                        </div>
                        {canDeleteComment && (
                          <button
                            type="button"
                            onClick={() => void handleDeleteComment(comment)}
                            className="text-xs text-[#991B1B] hover:underline cursor-pointer"
                          >
                            {isAdmin && user?.uid !== comment.authorId
                              ? '관리자 삭제'
                              : '삭제'}
                          </button>
                        )}
                      </div>
                      <p className="mt-1.5 text-sm text-[#292524] leading-relaxed whitespace-pre-wrap break-words">
                        {comment.content}
                      </p>
                    </li>
                  );
                })}
              </ul>
            )}

            {/* Comment Composer */}
            <form onSubmit={(e) => void handleAddComment(e)} className="space-y-3">
              {commentError && (
                <p className="text-xs text-[#991B1B]">{commentError}</p>
              )}
              <div className="flex flex-col sm:flex-row gap-2.5">
                <input
                  type="text"
                  value={commentText}
                  maxLength={COMMUNITY_LIMITS.COMMENT_MAX}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder={
                    user
                      ? '식물에 대한 팁이나 감상평을 남겨 주세요'
                      : '댓글을 작성하려면 Google 로그인이 필요합니다'
                  }
                  className="flex-1 h-11 px-4 text-sm bg-white border border-[#D6CEBE] rounded-md text-[#1C1917] placeholder:text-[#78716C] focus:outline-none focus:border-[#1B4332]"
                />
                {user ? (
                  <button
                    type="submit"
                    disabled={!commentText.trim() || isSubmittingComment}
                    className="h-11 px-5 inline-flex items-center justify-center gap-1.5 text-sm font-medium bg-[#1B4332] text-[#FBF9F5] hover:bg-[#143325] disabled:opacity-45 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    {isSubmittingComment ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>등록 중</span>
                      </>
                    ) : (
                      <span>댓글 등록</span>
                    )}
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={onRequireSignIn}
                    className="h-11 px-5 text-sm font-medium bg-[#1B4332] text-[#FBF9F5] hover:bg-[#143325] rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    로그인 후 댓글 쓰기
                  </button>
                )}
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
