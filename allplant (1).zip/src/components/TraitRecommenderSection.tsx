import { useRef, useState } from 'react';
import {
  ArrowRight,
  Calendar,
  ExternalLink,
  Loader2,
  RotateCcw,
  Search,
  Sparkles,
} from 'lucide-react';
import {
  CATEGORY_VISUALS,
  detectPlantNameReference,
  getCurrentSeason,
} from '../data/botanicalCatalog';
import { SafeImage } from './SafeImage';
import type {
  PlantRecommendation,
  PlantSeason,
  RecommendationResponse,
} from '../types/plant';

interface TraitRecommenderSectionProps {
  description: string;
  onDescriptionChange: (value: string) => void;
  selectedTraits: {
    appearance: string;
    color: string;
    scent: string;
    environment: string;
    season: string;
  };
  onTraitChange: (
    key: 'appearance' | 'color' | 'scent' | 'environment' | 'season',
    value: string
  ) => void;
  onResetTraits: () => void;
  onSubmitRecommend: (overrideDesc?: string, useLiveGoogle?: boolean) => void;
  isLoading: boolean;
  isLoadingLive: boolean;
  error: string | null;
  result: RecommendationResponse | null;
  onSelectRecommendation: (rec: PlantRecommendation) => void;
}

const SEASON_OPTIONS: PlantSeason[] = ['봄', '여름', '가을', '겨울'];

const APPEARANCE_OPTIONS = [
  '구멍 뚫린 큰 잎',
  '동그란 동전 잎',
  '가늘고 뾰족한 잎',
  '통통한 다육 로제트',
  '늘어지는 덩굴형',
  '풍성한 작은 꽃송이',
];

const COLOR_OPTIONS = [
  '짙은 초록색',
  '은청색 · 회녹색',
  '하늘색 · 파란색',
  '보라색',
  '순백색',
  '분홍 · 붉은색',
  '검은색 · 블랙',
  '무늬 잎',
];

const SCENT_OPTIONS = [
  '달콤한 꽃향기',
  '상쾌한 허브향',
  '시트러스 · 멘톨향',
  '은은한 차 · 과일향',
  '무향 (냄새 없음)',
];

const ENV_OPTIONS = [
  '초보자 추천',
  '실내 반음지',
  '햇빛 잘 드는 창가',
  '반려동물 안전',
];

const EXAMPLE_QUERIES = [
  '몬스테라',
  '라벤더',
  '보라색 꽃이 피고 은은한 허브 향기가 나는 식물',
  '벚꽃처럼 화사한 봄 꽃',
];

export function TraitRecommenderSection({
  description,
  onDescriptionChange,
  selectedTraits,
  onTraitChange,
  onResetTraits,
  onSubmitRecommend,
  isLoading,
  isLoadingLive,
  error,
  result,
  onSelectRecommendation,
}: TraitRecommenderSectionProps) {
  const [showBuilder, setShowBuilder] = useState(true);
  const resultsRef = useRef<HTMLDivElement | null>(null);
  const currentCalendarSeason = getCurrentSeason();

  const toggleTrait = (
    key: 'appearance' | 'color' | 'scent' | 'environment' | 'season',
    val: string
  ) => {
    onTraitChange(key, selectedTraits[key] === val ? '' : val);
  };

  const hasAnyInput =
    description.trim().length > 0 ||
    Object.values(selectedTraits).some((v) => v.trim().length > 0);

  const scrollToResults = () => {
    setTimeout(() => {
      resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 60);
  };

  return (
    <section
      id="recommend"
      className="py-10 lg:py-14 bg-[#F5F1E8]/50 flex-1"
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-8 border-b border-[#E5DFD3]">
          <div className="max-w-2xl">
            <p className="text-xs font-medium text-[#57534E] mb-2">
              02 · 생김새 · 색상 · 향기 기반 큐레이션
            </p>
            <h2 className="font-editorial text-2xl sm:text-3xl font-semibold text-[#1C1917] text-balance">
              원하는 생김새와 색, 향기로 나만의 식물을 찾아보세요
            </h2>
            <p className="mt-2.5 text-sm sm:text-[15px] text-[#57534E] leading-relaxed">
              원하는 색깔, 향기, 분위기나 <strong>식물 이름</strong>(예:{' '}
              <strong>몬스테라</strong>, <strong>라벤더</strong>, <strong>벚꽃</strong>,{' '}
              <strong>해피트리</strong>)을 입력하면 <strong>그 식물과 비슷한 식물</strong>이나
              키워드(예: <strong>흰색</strong>, <strong>숙면</strong>, <strong>모기</strong>)에
              맞는 식물을 추천해 드립니다. 카드를 누르면 키우는 방법을 볼 수 있습니다.
            </p>
          </div>
          <div className="flex items-center gap-4 self-start lg:self-auto">
            {hasAnyInput && (
              <button
                type="button"
                onClick={onResetTraits}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-[#57534E] hover:text-[#1C1917] whitespace-nowrap shrink-0 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>조건 초기화</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => setShowBuilder((prev) => !prev)}
              className="text-xs font-medium text-[#1B4332] hover:underline underline-offset-4 whitespace-nowrap shrink-0 cursor-pointer"
            >
              {showBuilder ? '세부 조건 선택 접기' : '세부 조건 선택 펼치기'}
            </button>
          </div>
        </div>

        {/* Recommendation Input Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (hasAnyInput && !isLoading) {
              onSubmitRecommend(undefined, false);
              scrollToResults();
            }
          }}
          className="mt-8 bg-white border border-[#E5DFD3] rounded-lg p-6 sm:p-8"
        >
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-[#78716C] absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={description}
                onChange={(e) => onDescriptionChange(e.target.value)}
                placeholder="식물 이름(예: 몬스테라, 라벤더, 벚꽃)이나 원하는 키워드·색·향기 입력"
                className="w-full h-12 pl-11 pr-4 text-sm sm:text-[15px] bg-[#FBF9F5] border border-[#D6CEBE] rounded-md text-[#1C1917] placeholder:text-[#78716C] focus:outline-none focus:border-[#1B4332] focus:ring-1 focus:ring-[#1B4332]"
              />
            </div>
            <button
              type="submit"
              disabled={!hasAnyInput || isLoading}
              className="h-12 px-6 inline-flex items-center justify-center gap-2 text-sm font-medium text-[#FBF9F5] bg-[#1B4332] hover:bg-[#143325] disabled:opacity-45 disabled:cursor-not-allowed rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>식물 찾는 중</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>조건에 맞는 식물 추천받기</span>
                </>
              )}
            </button>
          </div>

          {/* Example prompt shortcuts */}
          <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-[#57534E]">
            <span className="font-medium text-[#78716C] shrink-0">추천 검색 예시:</span>
            {EXAMPLE_QUERIES.map((example) => (
              <button
                key={example}
                type="button"
                onClick={() => {
                  onDescriptionChange(example);
                  onSubmitRecommend(example, false);
                  scrollToResults();
                }}
                className="text-left text-[#2D6A4F] hover:text-[#1B4332] hover:underline underline-offset-2 transition-colors cursor-pointer"
              >
                “{example}”
              </button>
            ))}
          </div>

          {/* Season + 4-Dimension Trait Selectors */}
          {showBuilder && (
            <div className="mt-6 pt-6 border-t border-[#E5DFD3] space-y-6">
              {/* Current Season Filter */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-5 border-b border-[#F0EBE1]">
                <div className="flex items-center gap-2">
                  <Calendar className="w-3.5 h-3.5 text-[#1B4332] shrink-0" />
                  <span className="text-xs font-semibold text-[#1C1917]">
                    현재 계절
                  </span>
                  <span className="text-xs text-[#78716C]">
                    · 오늘 기준 {currentCalendarSeason} (선택 시 계절 맞춤 식물 우선 추천)
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-1.5">
                  {SEASON_OPTIONS.map((season) => {
                    const active = selectedTraits.season === season;
                    const isTodaySeason = season === currentCalendarSeason;
                    return (
                      <button
                        key={season}
                        type="button"
                        onClick={() => toggleTrait('season', season)}
                        className={`px-3 py-1.5 text-xs rounded-md border transition-colors whitespace-nowrap cursor-pointer ${
                          active
                            ? 'bg-[#1B4332] text-[#FBF9F5] border-[#1B4332]'
                            : 'bg-[#FBF9F5] text-[#44403C] border-[#E5DFD3] hover:border-[#1B4332]/50'
                        }`}
                      >
                        {season}
                        {isTodaySeason ? ' (현재)' : ''}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div>
                <div className="text-xs font-semibold text-[#1C1917] mb-2.5">
                  생김새 · 수형
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {APPEARANCE_OPTIONS.map((opt) => {
                    const active = selectedTraits.appearance === opt;
                    return (
                      <button
                        key={opt}
                        type="button"
                        onClick={() => toggleTrait('appearance', opt)}
                        className={`px-2.5 py-1.5 text-xs rounded-md border transition-colors whitespace-nowrap cursor-pointer ${
                          active
                            ? 'bg-[#1B4332] text-[#FBF9F5] border-[#1B4332]'
                            : 'bg-[#FBF9F5] text-[#44403C] border-[#E5DFD3] hover:border-[#1B4332]/50'
                        }`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <div className="text-xs font-semibold text-[#1C1917] mb-2.5">
                  잎 · 꽃 색상
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {COLOR_OPTIONS.map((opt) => {
                    const active = selectedTraits.color === opt;
                    return (
                      <button
                        key={opt}
                        type="button"
                        onClick={() => toggleTrait('color', opt)}
                        className={`px-2.5 py-1.5 text-xs rounded-md border transition-colors whitespace-nowrap cursor-pointer ${
                          active
                            ? 'bg-[#1B4332] text-[#FBF9F5] border-[#1B4332]'
                            : 'bg-[#FBF9F5] text-[#44403C] border-[#E5DFD3] hover:border-[#1B4332]/50'
                        }`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <div className="text-xs font-semibold text-[#1C1917] mb-2.5">
                  향기 · 냄새
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {SCENT_OPTIONS.map((opt) => {
                    const active = selectedTraits.scent === opt;
                    return (
                      <button
                        key={opt}
                        type="button"
                        onClick={() => toggleTrait('scent', opt)}
                        className={`px-2.5 py-1.5 text-xs rounded-md border transition-colors whitespace-nowrap cursor-pointer ${
                          active
                            ? 'bg-[#1B4332] text-[#FBF9F5] border-[#1B4332]'
                            : 'bg-[#FBF9F5] text-[#44403C] border-[#E5DFD3] hover:border-[#1B4332]/50'
                        }`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <div className="text-xs font-semibold text-[#1C1917] mb-2.5">
                  생육 환경 · 난이도
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {ENV_OPTIONS.map((opt) => {
                    const active = selectedTraits.environment === opt;
                    return (
                      <button
                        key={opt}
                        type="button"
                        onClick={() => toggleTrait('environment', opt)}
                        className={`px-2.5 py-1.5 text-xs rounded-md border transition-colors whitespace-nowrap cursor-pointer ${
                          active
                            ? 'bg-[#1B4332] text-[#FBF9F5] border-[#1B4332]'
                            : 'bg-[#FBF9F5] text-[#44403C] border-[#E5DFD3] hover:border-[#1B4332]/50'
                        }`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>
              </div>
              </div>
            </div>
          )}
        </form>

        {/* Error Display */}
        {error && (
          <div className="mt-6 p-4 bg-[#FEF2F2] border border-[#FECACA] rounded-md text-sm text-[#991B1B]">
            {error}
          </div>
        )}

        {/* Recommendation Results */}
        <div id="recommend-results" ref={resultsRef}>
          {(isLoading || isLoadingLive) && (
            <div className="mt-10 bg-white border border-[#E5DFD3] rounded-lg p-8 text-center">
              <Loader2 className="w-7 h-7 text-[#1B4332] animate-spin mx-auto mb-3" />
              <h3 className="font-editorial text-xl font-semibold text-[#1C1917]">
                {(() => {
                  const detectedPlant = detectPlantNameReference(description);
                  if (detectedPlant) {
                    return `‘${detectedPlant}’와 비슷한 식물을 찾는 중입니다`;
                  }
                  const targetLabel =
                    description.trim() ||
                    Object.values(selectedTraits).filter(Boolean).join(' · ');
                  return targetLabel
                    ? `‘${targetLabel}’에 맞는 식물을 찾는 중입니다`
                    : '조건에 맞는 식물을 찾는 중입니다';
                })()}
              </h3>
              <p className="mt-1.5 text-sm text-[#57534E]">
                {(() => {
                  const detectedPlant = detectPlantNameReference(description);
                  if (isLoadingLive) {
                    return detectedPlant
                      ? `구글 웹에서 ‘${detectedPlant}’와 생김새·색감·특성이 비슷한 실존 식물을 추가로 찾는 중입니다.`
                      : '구글 웹에서 해당 키워드와 어울리는 실존 식물을 추가로 찾는 중입니다.';
                  }
                  return detectedPlant
                    ? `‘${detectedPlant}’의 생김새·색감·향기·분류를 비교해 가장 비슷한 다른 식물을 찾는 중입니다.`
                    : '입력하신 키워드와 생김새·색감·향기 특성을 대조해 어울리는 식물을 찾는 중입니다.';
                })()}
              </p>
            </div>
          )}

          {!isLoading && result && result.recommendations.length === 0 && (
            <div className="mt-10 bg-white border border-[#E5DFD3] rounded-lg p-8 text-center">
              <h3 className="font-editorial text-xl font-semibold text-[#1C1917]">
                입력하신 조건과 정확히 일치하는 식물을 도감에서 찾지 못했습니다
              </h3>
              <p className="mt-2 text-sm text-[#57534E]">
                조건: {result.querySummary} · 구글 웹에서 실시간으로 검색하거나 조건을 초기화해 다시 찾아보세요.
              </p>
              <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
                <button
                  type="button"
                  disabled={isLoadingLive}
                  onClick={() => onSubmitRecommend(undefined, true)}
                  className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-[#FBF9F5] bg-[#1B4332] hover:bg-[#143325] disabled:opacity-50 rounded-md transition-colors cursor-pointer"
                >
                  {isLoadingLive ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>구글 웹 추가 탐색 중</span>
                    </>
                  ) : (
                    <span>구글 웹에서 직접 추천 찾기</span>
                  )}
                </button>
                <button
                  type="button"
                  onClick={onResetTraits}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-[#1C1917] bg-[#FBF9F5] border border-[#D6CEBE] hover:border-[#1B4332] rounded-md transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>조건 초기화</span>
                </button>
              </div>
            </div>
          )}

          {!isLoading && result && result.recommendations.length > 0 && (
            <div className="mt-10">
              <div className="flex flex-wrap items-baseline justify-between gap-4 mb-6">
                <div>
                  <h3 className="font-editorial text-xl font-semibold text-[#1C1917]">
                    추천 식물 {result.recommendations.length}종
                </h3>
                <p className="text-xs sm:text-sm text-[#57534E] mt-1">
                  조건: {result.querySummary} · 카드를 클릭하면 키우는 방법과 상세 특징을 볼 수 있습니다.
                </p>
                {result.notice && (
                  <p className="text-xs text-[#78716C] mt-1">{result.notice}</p>
                )}
              </div>

              {result.sourceMode === 'catalog' && (
                <button
                  type="button"
                  disabled={isLoadingLive}
                  onClick={() => onSubmitRecommend(undefined, true)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-[#1B4332] bg-white border border-[#D6CEBE] hover:border-[#1B4332] rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50"
                >
                  {isLoadingLive ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>구글 웹 추가 탐색 중</span>
                    </>
                  ) : (
                    <span>구글 웹에서 추가 식물 더 찾기</span>
                  )}
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {result.recommendations.map((rec) => {
                const cardImage =
                  rec.imageUrl || CATEGORY_VISUALS[rec.category]?.imageUrl;
                return (
                  <button
                    key={`${rec.nameKo}-${rec.scientificName}`}
                    type="button"
                    onClick={() => onSelectRecommendation(rec)}
                    className="group text-left bg-white border border-[#E5DFD3] hover:border-[#1B4332] rounded-lg overflow-hidden transition-colors duration-150 flex flex-col justify-between cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1B4332]"
                  >
                    <div>
                      {/* Species Photo Plate */}
                      <div className="aspect-[16/10] w-full overflow-hidden bg-[#F3EFE6] border-b border-[#E5DFD3]">
                        <SafeImage
                          src={cardImage}
                          alt={`${rec.nameKo} (${rec.scientificName})`}
                          fallbackLabel={rec.nameKo}
                          className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-200"
                        />
                      </div>

                      <div className="p-6 pb-0">
                        {/* Unboxed metadata line */}
                        <div className="flex items-center gap-2 text-xs text-[#78716C] mb-2">
                          <span>{rec.category}</span>
                          <span aria-hidden="true">·</span>
                          <span className="text-[#1B4332] font-medium">{rec.difficulty}</span>
                        </div>

                        {/* Title & Binomial */}
                        <h4 className="font-editorial text-xl font-semibold text-[#1C1917] group-hover:text-[#1B4332] transition-colors">
                          {rec.nameKo}
                        </h4>
                        <p className="font-binomial italic text-sm text-[#57534E] mt-0.5">
                          {rec.scientificName}
                        </p>

                        {/* Match Reason */}
                        <p className="mt-3 text-sm text-[#292524] leading-relaxed">
                          {rec.matchReason}
                        </p>

                        {/* Color + Appearance + Scent details */}
                        <dl className="mt-4 pt-4 border-t border-[#F0EBE1] space-y-2 text-xs">
                          <div className="flex items-center gap-2">
                            <dt className="text-[#78716C] shrink-0">색상</dt>
                            <dd className="flex items-center gap-1.5 text-[#292524] min-w-0">
                              {(rec.colorHexes ?? []).slice(0, 3).map((hex, idx) => (
                                <span
                                  key={`${hex}-${idx}`}
                                  className="w-3 h-3 rounded-full border border-[#D6CEBE] shrink-0"
                                  style={{ backgroundColor: hex }}
                                />
                              ))}
                              <span className="truncate">{rec.colorDescription}</span>
                            </dd>
                          </div>
                          <div className="flex items-baseline gap-2">
                            <dt className="text-[#78716C] shrink-0">생김새</dt>
                            <dd className="text-[#292524] line-clamp-2">{rec.appearanceSummary}</dd>
                          </div>
                          <div className="flex items-baseline gap-2">
                            <dt className="text-[#78716C] shrink-0">향기</dt>
                            <dd className="text-[#292524] line-clamp-1">{rec.scentSummary}</dd>
                          </div>
                        </dl>
                      </div>
                    </div>

                    {/* Click Cue */}
                    <div className="mx-6 mb-6 mt-5 pt-3 border-t border-[#E5DFD3] flex items-center justify-between text-xs font-medium text-[#1B4332]">
                      <span className="truncate pr-2">{rec.quickCareTip}</span>
                      <span className="inline-flex items-center gap-1 whitespace-nowrap shrink-0 group-hover:translate-x-0.5 transition-transform">
                        <span>키우는 법 보기</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Grounding Sources */}
            {result.sources && result.sources.length > 0 && (
              <div className="mt-6 pt-5 border-t border-[#E5DFD3]">
                <p className="text-xs font-medium text-[#57534E] mb-2">
                  구글 검색 참고 출처
                </p>
                <div className="flex flex-wrap gap-x-5 gap-y-2">
                  {result.sources.map((src) => (
                    <a
                      key={src.uri}
                      href={src.uri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs text-[#1B4332] hover:underline"
                    >
                      <ExternalLink className="w-3 h-3 shrink-0" />
                      <span className="max-w-xs truncate">{src.title}</span>
                    </a>
                  ))}
                </div>
              </div>
            )}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
