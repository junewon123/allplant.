import { useEffect, useMemo, useRef, useState } from 'react';
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  limit,
  onSnapshot,
  orderBy,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  type Timestamp,
} from 'firebase/firestore';
import { ArrowLeft, ArrowRight, Ban, BookmarkX, Download, Loader2, LogIn, Search, ShieldCheck, Sparkles, UserX } from 'lucide-react';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from './firebase';
import {
  BOTANICAL_CATALOG,
  CATEGORY_VISUALS,
  TRAIT_RECOMMENDATION_CATALOG,
  detectPlantNameReference,
  findBestCatalogPlantMatch,
  recommendFromCatalog,
} from './data/botanicalCatalog';
import { PLANT_SPECIES_PHOTOS } from './data/plantPhotos';
import { BOOTSTRAPPED_ADMIN_EMAIL } from './types/community';
import type {
  AppPage,
  PlantProfile,
  PlantRecommendation,
  RecommendationResponse,
} from './types/plant';
import { Header } from './components/Header';
import { SafeImage } from './components/SafeImage';
import { TraitRecommenderSection } from './components/TraitRecommenderSection';
import { CatalogSection } from './components/CatalogSection';
import { CommunitySection } from './components/CommunitySection';
import { AdminAccountsSection } from './components/AdminAccountsSection';
import { SpecimenDetailModal } from './components/SpecimenDetailModal';

const HERO_IMAGE = '/src/assets/images/hero_botanical_conservatory_1795403760157.jpg';
const SAVED_STORAGE_KEY = 'chomokrok_saved_plants_v1';

const DEFAULT_POPULAR_QUERIES = [
  '몬스테라',
  '올리브나무',
  '바질',
  '수국',
  '고무나무',
  '여인초',
];

interface PopularSearchEntry {
  term: string;
  count: number;
  lastSearchedAt: number;
}

function normalizePopularTerm(raw: string): string | null {
  const cleaned = raw
    .replace(/<[^>]*>/g, '')
    .replace(/\s*\([^)]*\)\s*/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (!cleaned || cleaned.length > 35) return null;
  if (/^[ㄱ-ㅎㅏ-ㅣ]$/.test(cleaned)) return null;
  return cleaned;
}

function toPopularTermDocId(term: string): string {
  const lower = term.toLowerCase();
  let h1 = 2166136261;
  let h2 = 33554467;
  for (let i = 0; i < lower.length; i++) {
    const c = lower.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 16777619) >>> 0;
    h2 = Math.imul(h2 ^ (c + i), 2654435761) >>> 0;
  }
  return `term_${h1.toString(36)}_${h2.toString(36)}`;
}

const PAGE_ORDER: Array<{ id: AppPage; num: string; label: string }> = [
  { id: 'search', num: '01', label: '식물 검색' },
  { id: 'recommend', num: '02', label: '취향 추천' },
  { id: 'catalog', num: '03', label: '식물 도감' },
  { id: 'community', num: '04', label: '커뮤니티' },
  { id: 'saved', num: '05', label: '저장함' },
];

const GUEST_VISITOR_STORAGE_KEY = 'allplant_guest_visitor_id_v1';

function getOrCreateGuestVisitorId(): string {
  if (typeof window === 'undefined') return 'guest_ssrvisitor01';
  try {
    const existing = window.localStorage.getItem(GUEST_VISITOR_STORAGE_KEY);
    if (existing && /^guest_[a-zA-Z0-9_-]{8,64}$/.test(existing)) {
      return existing;
    }
    const rawRandom =
      typeof window.crypto?.randomUUID === 'function'
        ? window.crypto.randomUUID().replace(/-/g, '')
        : `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 12)}`;
    const nextId = `guest_${rawRandom}`.slice(0, 48);
    window.localStorage.setItem(GUEST_VISITOR_STORAGE_KEY, nextId);
    return nextId;
  } catch {
    return `guest_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`;
  }
}

function getInitialPage(): AppPage {
  if (typeof window === 'undefined') return 'search';
  const hash = window.location.hash.replace('#', '') as AppPage;
  if (hash === 'accounts' || PAGE_ORDER.some((p) => p.id === hash)) {
    return hash;
  }
  return 'search';
}

export default function App() {
  const [activePage, setActivePage] = useState<AppPage>(getInitialPage);

  // Firebase Auth & Admin Role State
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [banNotice, setBanNotice] = useState<{ reason?: string } | null>(null);
  const [kickedNotice, setKickedNotice] = useState<string | null>(null);
  const [guestBanNotice, setGuestBanNotice] = useState<{ reason?: string } | null>(null);
  const [guestKicked, setGuestKicked] = useState(false);
  const [sessionSyncedUid, setSessionSyncedUid] = useState<string | null>(null);
  const recordedSessionUidRef = useRef<string | null>(null);
  const recordedGuestSessionRef = useRef(false);
  const freshSignInRef = useRef(false);

  const isPrimaryAdmin = Boolean(
    user?.emailVerified &&
      user.email?.toLowerCase() === BOOTSTRAPPED_ADMIN_EMAIL.toLowerCase()
  );

  useEffect(() => {
    const recordUserAccountLogin = async (signedInUser: User) => {
      if (!signedInUser.emailVerified) return;
      if (!signedInUser.email) {
        setSessionSyncedUid(signedInUser.uid);
        return;
      }
      if (recordedSessionUidRef.current === signedInUser.uid) return;
      recordedSessionUidRef.current = signedInUser.uid;

      const isFreshSignIn = freshSignInRef.current;
      freshSignInRef.current = false;

      const userRef = doc(db, 'userAccounts', signedInUser.uid);
      const safeName = (
        signedInUser.displayName ||
        signedInUser.email.split('@')[0] ||
        '가드너'
      )
        .trim()
        .slice(0, 80);
      const safePhoto = (signedInUser.photoURL || '').slice(0, 500);
      const safeEmail = signedInUser.email.slice(0, 200);
      const isOwnerAdminAccount =
        signedInUser.email.toLowerCase() === BOOTSTRAPPED_ADMIN_EMAIL.toLowerCase();

      try {
        const outcome = await runTransaction(db, async (tx) => {
          const snap = await tx.get(userRef);
          if (!snap.exists()) {
            tx.set(userRef, {
              uid: signedInUser.uid,
              email: safeEmail,
              displayName: safeName,
              photoUrl: safePhoto,
              loginCount: 1,
              firstLoginAt: serverTimestamp(),
              lastLoginAt: serverTimestamp(),
            });
            return { status: 'ok' as const };
          }

          const data = snap.data();
          if (!isOwnerAdminAccount && data?.isBanned === true) {
            return {
              status: 'banned' as const,
              reason: typeof data.banReason === 'string' ? data.banReason : undefined,
            };
          }

          const kickedMs = (data?.kickedAt as Timestamp | undefined)?.toMillis?.() ?? 0;
          const lastLoginMs = (data?.lastLoginAt as Timestamp | undefined)?.toMillis?.() ?? 0;
          if (!isOwnerAdminAccount && kickedMs > lastLoginMs && !isFreshSignIn) {
            return { status: 'kicked' as const };
          }

          const existingCount = Number(data?.loginCount ?? 0);
          tx.update(userRef, {
            email: safeEmail,
            displayName: safeName,
            photoUrl: safePhoto,
            loginCount: existingCount + 1,
            lastLoginAt: serverTimestamp(),
          });
          return { status: 'ok' as const };
        });

        if (outcome.status === 'banned') {
          recordedSessionUidRef.current = null;
          setSessionSyncedUid(null);
          setKickedNotice(null);
          setBanNotice({ reason: outcome.reason });
          await signOut(auth);
          return;
        }

        if (outcome.status === 'kicked') {
          recordedSessionUidRef.current = null;
          setSessionSyncedUid(null);
          setBanNotice(null);
          setKickedNotice(
            '관리자에 의해 로그아웃(쫓아내기) 처리되었습니다. 계속 이용하려면 다시 로그인해 주세요.'
          );
          await signOut(auth);
          return;
        }

        setBanNotice(null);
        setKickedNotice(null);
        setSessionSyncedUid(signedInUser.uid);
      } catch (err) {
        setSessionSyncedUid(signedInUser.uid);
        try {
          handleFirestoreError(err, OperationType.WRITE, `userAccounts/${signedInUser.uid}`);
        } catch {
          // Non-blocking user account log
        }
      }
    };

    const unsubscribe = onAuthStateChanged(auth, (nextUser) => {
      setUser(nextUser);
      setAuthReady(true);

      if (!nextUser) {
        recordedSessionUidRef.current = null;
        freshSignInRef.current = false;
        setSessionSyncedUid(null);
        setIsAdmin(false);
        return;
      }

      void recordUserAccountLogin(nextUser);

      if (
        nextUser.emailVerified &&
        nextUser.email?.toLowerCase() === BOOTSTRAPPED_ADMIN_EMAIL.toLowerCase()
      ) {
        setIsAdmin(true);
        const adminRef = doc(db, 'admins', nextUser.uid);
        void getDoc(adminRef)
          .then((snap) => {
            if (!snap.exists()) {
              return setDoc(adminRef, {
                uid: nextUser.uid,
                role: 'admin',
                createdAt: serverTimestamp(),
              });
            }
            return undefined;
          })
          .catch(() => {
            // Admin email privilege remains active via token rules
          });
        return;
      }

      void getDoc(doc(db, 'admins', nextUser.uid))
        .then((snap) => {
          setIsAdmin(snap.exists() && Boolean(nextUser.emailVerified));
        })
        .catch(() => {
          setIsAdmin(false);
        });
    });

    return () => unsubscribe();
  }, []);

  // Real-time Kick & Ban watcher for active logged-in users
  useEffect(() => {
    if (
      !authReady ||
      !user ||
      !user.emailVerified ||
      isPrimaryAdmin ||
      sessionSyncedUid !== user.uid
    ) {
      return;
    }

    const userRef = doc(db, 'userAccounts', user.uid);
    const unsubscribe = onSnapshot(
      userRef,
      (snap) => {
        if (!snap.exists() || snap.metadata.hasPendingWrites) return;
        const data = snap.data();

        if (data?.isBanned === true) {
          recordedSessionUidRef.current = null;
          setSessionSyncedUid(null);
          setKickedNotice(null);
          setBanNotice({
            reason: typeof data.banReason === 'string' ? data.banReason : undefined,
          });
          void signOut(auth);
          return;
        }

        const kickedMs = (data?.kickedAt as Timestamp | undefined)?.toMillis?.() ?? 0;
        const lastLoginMs = (data?.lastLoginAt as Timestamp | undefined)?.toMillis?.() ?? 0;
        if (kickedMs > lastLoginMs) {
          recordedSessionUidRef.current = null;
          setSessionSyncedUid(null);
          setBanNotice(null);
          setKickedNotice(
            '관리자에 의해 현재 접속이 종료(쫓아내기)되었습니다. 다시 로그인해 주세요.'
          );
          void signOut(auth);
        }
      },
      (err) => {
        try {
          handleFirestoreError(err, OperationType.GET, `userAccounts/${user.uid}`);
        } catch {
          // Handled silently unless debugging permission issues
        }
      }
    );

    return () => unsubscribe();
  }, [authReady, user, isPrimaryAdmin, sessionSyncedUid]);

  // Record & watch unauthenticated ('비로그인') visits when browsing without login
  useEffect(() => {
    if (!authReady || user || guestKicked) return;

    const visitorId = getOrCreateGuestVisitorId();
    const guestRef = doc(db, 'guestVisits', visitorId);
    let cancelled = false;

    const recordGuestVisit = async () => {
      if (recordedGuestSessionRef.current) {
        return;
      }
      recordedGuestSessionRef.current = true;

      try {
        const outcome = await runTransaction(db, async (tx) => {
          const snap = await tx.get(guestRef);
          if (!snap.exists()) {
            tx.set(guestRef, {
              visitorId,
              label: '비로그인',
              visitCount: 1,
              firstVisitAt: serverTimestamp(),
              lastVisitAt: serverTimestamp(),
            });
            return { status: 'ok' as const };
          }

          const data = snap.data();
          if (data?.isBanned === true) {
            return {
              status: 'banned' as const,
              reason: typeof data.banReason === 'string' ? data.banReason : undefined,
            };
          }

          const existingCount = Number(data?.visitCount ?? 0);
          tx.update(guestRef, {
            visitCount: existingCount + 1,
            lastVisitAt: serverTimestamp(),
          });
          return { status: 'ok' as const };
        });

        if (cancelled) return;
        if (outcome.status === 'banned') {
          setGuestBanNotice({ reason: outcome.reason });
        } else {
          setGuestBanNotice(null);
        }
      } catch (err) {
        if (cancelled) return;
        try {
          handleFirestoreError(err, OperationType.WRITE, `guestVisits/${visitorId}`);
        } catch {
          // Non-blocking guest visit log
        }
      }
    };

    void recordGuestVisit();

    const unsubscribe = onSnapshot(
      guestRef,
      (snap) => {
        if (cancelled || !snap.exists() || snap.metadata.hasPendingWrites) return;
        const data = snap.data();

        if (data?.isBanned === true) {
          setGuestBanNotice({
            reason: typeof data.banReason === 'string' ? data.banReason : undefined,
          });
          return;
        }

        if (data?.isBanned === false) {
          setGuestBanNotice(null);
        }

        const kickedMs = (data?.kickedAt as Timestamp | undefined)?.toMillis?.() ?? 0;
        const lastVisitMs = (data?.lastVisitAt as Timestamp | undefined)?.toMillis?.() ?? 0;
        if (kickedMs > lastVisitMs) {
          recordedGuestSessionRef.current = false;
          setActivePlant(null);
          setGuestKicked(true);
        }
      },
      (err) => {
        try {
          handleFirestoreError(err, OperationType.GET, `guestVisits/${visitorId}`);
        } catch {
          // Non-blocking listener error log
        }
      }
    );

    return () => {
      cancelled = true;
      unsubscribe();
    };
  }, [authReady, user, guestKicked]);

  const handleSignIn = async (): Promise<boolean> => {
    setAuthError(null);
    setBanNotice(null);
    setKickedNotice(null);
    setIsSigningIn(true);
    freshSignInRef.current = true;
    try {
      await signInWithPopup(auth, googleProvider);
      return true;
    } catch (err) {
      freshSignInRef.current = false;
      const code = (err as { code?: string })?.code;
      if (code === 'auth/popup-closed-by-user') return false;
      setAuthError('Google 로그인에 실패했습니다. 팝업 차단을 확인 후 다시 시도해 주세요.');
      return false;
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleSignOut = async () => {
    setAuthError(null);
    setBanNotice(null);
    setKickedNotice(null);
    recordedSessionUidRef.current = null;
    freshSignInRef.current = false;
    setSessionSyncedUid(null);
    await signOut(auth);
  };

  // Hero workbench mode & inputs
  const [heroMode, setHeroMode] = useState<'name' | 'trait'>('name');
  const [nameQuery, setNameQuery] = useState('');

  // Trait recommender state (shared between Hero 'trait' mode and Recommender section)
  const [traitDescription, setTraitDescription] = useState('');
  const [selectedTraits, setSelectedTraits] = useState({
    appearance: '',
    color: '',
    scent: '',
    environment: '',
    season: '',
  });
  const [isRecommending, setIsRecommending] = useState(false);
  const [isLoadingLiveRecommend, setIsLoadingLiveRecommend] = useState(false);
  const [recommendError, setRecommendError] = useState<string | null>(null);
  const [recommendResult, setRecommendResult] =
    useState<RecommendationResponse | null>(null);

  // Specimen modal & Google lookup cache
  const [activePlant, setActivePlant] = useState<PlantProfile | null>(null);
  const [previewRec, setPreviewRec] = useState<PlantRecommendation | null>(null);
  const [searchingQuery, setSearchingQuery] = useState<string | null>(null);
  const [isSearchingPlant, setIsSearchingPlant] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [plantCache, setPlantCache] = useState<Record<string, PlantProfile>>({});
  const searchTimerRef = useRef<number | null>(null);
  const recommendTimerRef = useRef<number | null>(null);

  // Real-time popular search terms (Server SSE + Firestore persistence)
  const [serverPopularTerms, setServerPopularTerms] = useState<PopularSearchEntry[]>([]);
  const [firestorePopularTerms, setFirestorePopularTerms] = useState<PopularSearchEntry[]>([]);

  useEffect(() => {
    let cancelled = false;

    fetch('/api/searches/popular')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (!cancelled && Array.isArray(data?.terms)) {
          setServerPopularTerms(data.terms as PopularSearchEntry[]);
        }
      })
      .catch(() => {
        // Keep defaults/Firestore if network unavailable
      });

    let es: EventSource | null = null;
    if (typeof EventSource !== 'undefined') {
      es = new EventSource('/api/searches/stream');
      es.onmessage = (event) => {
        if (cancelled) return;
        try {
          const parsed = JSON.parse(event.data) as { terms?: PopularSearchEntry[] };
          if (Array.isArray(parsed.terms)) {
            setServerPopularTerms(parsed.terms);
          }
        } catch {
          // Ignore malformed keepalive events
        }
      };
    }

    const q = query(
      collection(db, 'popularSearches'),
      orderBy('count', 'desc'),
      limit(15)
    );
    const unsubFirestore = onSnapshot(
      q,
      (snapshot) => {
        if (cancelled) return;
        const docs: PopularSearchEntry[] = snapshot.docs.map((d) => {
          const data = d.data() as {
            term?: string;
            count?: number;
            lastSearchedAt?: Timestamp;
          };
          return {
            term: data.term || '',
            count: typeof data.count === 'number' ? data.count : 1,
            lastSearchedAt: data.lastSearchedAt?.toMillis?.() ?? 0,
          };
        });
        setFirestorePopularTerms(docs.filter((item) => item.term.length > 0));
      },
      (error) => {
        try {
          handleFirestoreError(error, OperationType.LIST, 'popularSearches');
        } catch {
          // Keep live server popular stream active even if Firestore read hits quota/offline
        }
      }
    );

    return () => {
      cancelled = true;
      es?.close();
      unsubFirestore();
    };
  }, []);

  const popularPlantQueries = useMemo(() => {
    const merged = new Map<string, PopularSearchEntry>();
    const absorb = (list: PopularSearchEntry[]) => {
      for (const item of list) {
        const clean = normalizePopularTerm(item.term);
        if (!clean) continue;
        const key = clean.toLowerCase();
        const prev = merged.get(key);
        if (!prev) {
          merged.set(key, {
            term: clean,
            count: item.count,
            lastSearchedAt: item.lastSearchedAt,
          });
        } else {
          merged.set(key, {
            term: prev.lastSearchedAt >= item.lastSearchedAt ? prev.term : clean,
            count: Math.max(prev.count, item.count),
            lastSearchedAt: Math.max(prev.lastSearchedAt, item.lastSearchedAt),
          });
        }
      }
    };

    absorb(firestorePopularTerms);
    absorb(serverPopularTerms);

    const ranked = Array.from(merged.values())
      .sort((a, b) => b.count - a.count || b.lastSearchedAt - a.lastSearchedAt)
      .map((item) => item.term);

    const seen = new Set(ranked.map((t) => t.toLowerCase()));
    const result = [...ranked];
    for (const fallback of DEFAULT_POPULAR_QUERIES) {
      if (result.length >= 6) break;
      if (!seen.has(fallback.toLowerCase())) {
        seen.add(fallback.toLowerCase());
        result.push(fallback);
      }
    }
    return result.slice(0, 6);
  }, [firestorePopularTerms, serverPopularTerms]);

  useEffect(() => {
    return () => {
      if (searchTimerRef.current !== null) {
        window.clearTimeout(searchTimerRef.current);
      }
      if (recommendTimerRef.current !== null) {
        window.clearTimeout(recommendTimerRef.current);
      }
    };
  }, []);

  // Saved herbarium
  const [savedPlants, setSavedPlants] = useState<PlantProfile[]>(() => {
    try {
      const raw = localStorage.getItem(SAVED_STORAGE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(SAVED_STORAGE_KEY, JSON.stringify(savedPlants));
    } catch {
      // Ignore storage quota errors cleanly
    }
  }, [savedPlants]);

  const isPlantSaved = (plant: PlantProfile | null) => {
    if (!plant) return false;
    return savedPlants.some(
      (p) =>
        p.id === plant.id ||
        p.scientificName.toLowerCase() === plant.scientificName.toLowerCase()
    );
  };

  const handleToggleSave = (plant: PlantProfile) => {
    setSavedPlants((prev) => {
      const exists = prev.some(
        (p) =>
          p.id === plant.id ||
          p.scientificName.toLowerCase() === plant.scientificName.toLowerCase()
      );
      if (exists) {
        return prev.filter(
          (p) =>
            p.id !== plant.id &&
            p.scientificName.toLowerCase() !== plant.scientificName.toLowerCase()
        );
      }
      return [plant, ...prev];
    });
  };

  const clearSearchTimer = () => {
    if (searchTimerRef.current !== null) {
      window.clearTimeout(searchTimerRef.current);
      searchTimerRef.current = null;
    }
  };

  const clearRecommendTimer = () => {
    if (recommendTimerRef.current !== null) {
      window.clearTimeout(recommendTimerRef.current);
      recommendTimerRef.current = null;
    }
  };

  const fetchPlantFromGoogle = async (
    queryText: string,
    options?: { forceRefresh?: boolean; preview?: PlantRecommendation | null }
  ) => {
    const trimmed = queryText.trim();
    if (!trimmed) return;

    clearSearchTimer();
    const cacheKey = trimmed.toLowerCase();
    const cachedPlant = !options?.forceRefresh ? plantCache[cacheKey] : undefined;
    const catalogMatch = !options?.forceRefresh
      ? findBestCatalogPlantMatch(trimmed)
      : undefined;
    const instantMatch = cachedPlant || catalogMatch;

    setSearchingQuery(trimmed);
    setPreviewRec(options?.preview ?? null);
    setActivePlant(null);
    setSearchError(null);
    setIsSearchingPlant(true);

    // Show "'식물' 식물을 찾는 중입니다" briefly even for catalog/cached plants
    if (instantMatch) {
      if (!options?.forceRefresh) {
        void recordPopularSearch(trimmed);
      }
      searchTimerRef.current = window.setTimeout(() => {
        searchTimerRef.current = null;
        setActivePlant(instantMatch);
        setPreviewRec(null);
        setIsSearchingPlant(false);
        setSearchingQuery(null);
      }, 400);
      return;
    }

    try {
      const res = await fetch('/api/plants/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: trimmed }),
      });
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || '식물 정보를 불러오는 데 실패했습니다.');
      }

      const loadedPlant = data.plant as PlantProfile;
      if (!loadedPlant?.nameKo) {
        throw new Error('해당 이름의 식물 정보를 찾지 못했습니다.');
      }

      // Only record into real-time popular searches when a valid plant result was found
      if (!options?.forceRefresh) {
        void recordPopularSearch(trimmed);
      }

      setPlantCache((prev) => ({
        ...prev,
        [cacheKey]: loadedPlant,
        [loadedPlant.nameKo.toLowerCase()]: loadedPlant,
        [loadedPlant.scientificName.toLowerCase()]: loadedPlant,
      }));
      setActivePlant(loadedPlant);
      setPreviewRec(null);
    } catch (err) {
      setSearchError(
        err instanceof Error ? err.message : '식물 정보를 조회하는 중 오류가 발생했습니다.'
      );
    } finally {
      setIsSearchingPlant(false);
      setSearchingQuery(null);
    }
  };

  const recordPopularSearch = async (rawQuery: string) => {
    const cleanTerm = normalizePopularTerm(rawQuery);
    if (!cleanTerm) return;

    try {
      const res = await fetch('/api/searches/record', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: cleanTerm }),
      });
      if (res.ok) {
        const data = (await res.json()) as { terms?: PopularSearchEntry[] };
        if (Array.isArray(data.terms)) {
          setServerPopularTerms(data.terms);
        }
      }
    } catch {
      // Non-blocking server stat sync
    }

    if (user && user.emailVerified) {
      const docId = toPopularTermDocId(cleanTerm);
      const docRef = doc(db, 'popularSearches', docId);
      try {
        await runTransaction(db, async (tx) => {
          const snap = await tx.get(docRef);
          if (!snap.exists()) {
            tx.set(docRef, {
              term: cleanTerm.slice(0, 40),
              count: 1,
              lastSearchedAt: serverTimestamp(),
              lastSearcherId: user.uid,
            });
          } else {
            const existingCount = Number(snap.data()?.count ?? 0);
            tx.update(docRef, {
              count: existingCount + 1,
              lastSearchedAt: serverTimestamp(),
              lastSearcherId: user.uid,
            });
          }
        });
      } catch (err) {
        try {
          handleFirestoreError(err, OperationType.WRITE, `popularSearches/${docId}`);
        } catch {
          // Non-blocking Firestore search stat sync
        }
      }
    }
  };

  const handleNameSearchSubmit = (queryOverride?: string) => {
    const target = (queryOverride ?? nameQuery).trim();
    if (!target) return;
    if (queryOverride) setNameQuery(queryOverride);
    void fetchPlantFromGoogle(target);
  };

  const handleTraitDescriptionChange = (value: string) => {
    clearRecommendTimer();
    setIsRecommending(false);
    setTraitDescription(value);
    setRecommendError(null);

    const trimmed = value.trim();
    const hasTraits = Object.values(selectedTraits).some((v) => v.trim().length > 0);

    if (!trimmed && !hasTraits) {
      setRecommendResult(null);
      return;
    }

    // Match immediately on any complete syllable/character (skip only incomplete single Hangul jamo)
    const isIncompleteJamo = trimmed.length === 1 && /^[ㄱ-ㅎㅏ-ㅣ]$/.test(trimmed);
    if (!hasTraits && isIncompleteJamo) {
      return;
    }

    const localResult = recommendFromCatalog(trimmed, selectedTraits);
    setRecommendResult({
      ...localResult,
      sourceMode: 'catalog',
      notice:
        localResult.notice ||
        `구글 원예 정보 기반으로 구축된 식물 도감(${BOTANICAL_CATALOG.length}종)에서 입력한 키워드·조건에 맞는 식물을 찾았습니다.`,
    });
  };

  const handleTraitChange = (
    key: 'appearance' | 'color' | 'scent' | 'environment' | 'season',
    value: string
  ) => {
    clearRecommendTimer();
    setIsRecommending(false);
    const nextTraits = { ...selectedTraits, [key]: value };
    setSelectedTraits(nextTraits);
    setRecommendError(null);

    const trimmedDesc = traitDescription.trim();
    const hasAny =
      trimmedDesc.length > 0 ||
      Object.values(nextTraits).some((v) => v.trim().length > 0);
    if (!hasAny) {
      setRecommendResult(null);
      return;
    }

    const localResult = recommendFromCatalog(trimmedDesc, nextTraits);
    setRecommendResult({
      ...localResult,
      sourceMode: 'catalog',
      notice:
        localResult.notice ||
        `구글 원예 정보 기반으로 구축된 식물 도감(${BOTANICAL_CATALOG.length}종)에서 조건에 맞는 비슷한 식물을 찾았습니다.`,
    });
  };

  const handleResetTraits = () => {
    clearRecommendTimer();
    setIsRecommending(false);
    setTraitDescription('');
    setSelectedTraits({
      appearance: '',
      color: '',
      scent: '',
      environment: '',
      season: '',
    });
    setRecommendResult(null);
    setRecommendError(null);
  };

  const handleTraitRecommendSubmit = async (
    descriptionOverride?: string,
    useLiveGoogle = false
  ) => {
    const desc = (descriptionOverride ?? traitDescription).trim();
    if (descriptionOverride !== undefined) {
      setTraitDescription(descriptionOverride);
    }

    const hasTraits = Object.values(selectedTraits).some((v) => v.trim().length > 0);
    if (!desc && !hasTraits) return;

    clearRecommendTimer();
    setRecommendError(null);

    if (!useLiveGoogle) {
      // Show brief "식물을 찾는 중입니다" state before presenting matched plants
      setIsRecommending(true);
      recommendTimerRef.current = window.setTimeout(() => {
        recommendTimerRef.current = null;
        const localResult = recommendFromCatalog(desc, selectedTraits);
        setRecommendResult({
          ...localResult,
          sourceMode: 'catalog',
          notice:
            localResult.notice ||
            `구글 원예 정보 기반으로 구축된 식물 도감(${BOTANICAL_CATALOG.length}종)에서 조건에 맞는 비슷한 식물을 찾았습니다.`,
        });
        setIsRecommending(false);
      }, 320);
      return;
    }

    // Explicit live Google Search expansion
    setIsLoadingLiveRecommend(true);
    try {
      const similarToPlant = detectPlantNameReference(desc) ?? undefined;
      const res = await fetch('/api/plants/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          description: desc,
          traits: selectedTraits,
          ...(similarToPlant ? { similarToPlant } : {}),
        }),
      });
      const data = await res.json();

      if (!res.ok) {
        setRecommendError(
          data.error ||
            '현재 실시간 AI 요청 한도에 도달하여 내장 식물 도감의 추천 결과를 표시합니다.'
        );
        return;
      }

      setRecommendResult({
        ...(data as RecommendationResponse),
        notice:
          data.sourceMode === 'google-live'
            ? similarToPlant
              ? `구글 실시간 웹 검색을 바탕으로 ‘${similarToPlant}’와 비슷한 실존 식물을 추가로 불러왔습니다.`
              : '구글 실시간 웹 검색을 바탕으로 추가 추천 식물을 불러왔습니다.'
            : similarToPlant
              ? `식물 지식 데이터베이스를 바탕으로 ‘${similarToPlant}’와 비슷한 추천 식물을 불러왔습니다.`
              : '식물 지식 데이터베이스를 바탕으로 추천 식물을 불러왔습니다.',
      });
    } catch (err) {
      setRecommendError(
        err instanceof Error
          ? err.message
          : '실시간 조회 중 오류가 발생해 내장 식물 도감 추천을 표시합니다.'
      );
    } finally {
      setIsLoadingLiveRecommend(false);
    }
  };

  const handleSelectRecommendation = (rec: PlantRecommendation) => {
    const byKo = plantCache[rec.nameKo.toLowerCase()];
    const bySci = plantCache[rec.scientificName.toLowerCase()];
    if (byKo || bySci) {
      setPreviewRec(null);
      setSearchError(null);
      setActivePlant(byKo || bySci);
      return;
    }

    const catalogMatch =
      TRAIT_RECOMMENDATION_CATALOG.find(
        (p) =>
          p.scientificName.toLowerCase() === rec.scientificName.toLowerCase() ||
          p.nameKo.replace(/\s*\(.*?\)\s*/g, '').trim() ===
            rec.nameKo.replace(/\s*\(.*?\)\s*/g, '').trim()
      ) || findBestCatalogPlantMatch(rec.nameKo);

    if (catalogMatch) {
      setPreviewRec(null);
      setSearchError(null);
      setActivePlant(catalogMatch);
      return;
    }

    void fetchPlantFromGoogle(`${rec.nameKo} (${rec.scientificName})`, {
      preview: rec,
    });
  };

  const navigateToPage = (page: AppPage) => {
    setActivePage(page);
    if (typeof window !== 'undefined') {
      try {
        window.history.replaceState(null, '', `#${page}`);
      } catch {
        // Ignore history restriction in embedded frames
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const visiblePageOrder = isPrimaryAdmin
    ? [...PAGE_ORDER, { id: 'accounts' as AppPage, num: '06', label: '계정 관리' }]
    : PAGE_ORDER;

  const effectivePage: AppPage =
    activePage === 'accounts' && !isPrimaryAdmin ? 'search' : activePage;

  const currentPageIdx = visiblePageOrder.findIndex((p) => p.id === effectivePage);
  const prevPage = currentPageIdx > 0 ? visiblePageOrder[currentPageIdx - 1] : null;
  const nextPage =
    currentPageIdx >= 0 && currentPageIdx < visiblePageOrder.length - 1
      ? visiblePageOrder[currentPageIdx + 1]
      : null;

  if (!authReady || (user && user.emailVerified && sessionSyncedUid !== user.uid)) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#FBF9F5] text-[#1C1917] px-6">
        <Loader2 className="w-7 h-7 text-[#1B4332] animate-spin mb-3" />
        <p className="font-editorial text-lg font-semibold text-[#1C1917]">올플랜트</p>
        <p className="mt-1 text-xs text-[#57534E]">접속 권한을 확인하고 있습니다...</p>
      </div>
    );
  }

  if (!user && guestBanNotice) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#FBF9F5] text-[#1C1917] px-6">
        <div className="max-w-md w-full bg-white border border-[#FECACA] rounded-lg p-7 text-center shadow-xs">
          <div className="w-11 h-11 rounded-full bg-[#FEF2F2] text-[#991B1B] flex items-center justify-center mx-auto mb-4">
            <Ban className="w-5 h-5" />
          </div>
          <h1 className="font-editorial text-2xl font-semibold text-[#1C1917]">
            접속이 정지(벤)되었습니다
          </h1>
          <p className="mt-2.5 text-sm text-[#44403C] leading-relaxed">
            사유: {guestBanNotice.reason || '관리자에 의해 서비스 이용이 정지되었습니다.'}
          </p>
          <p className="mt-2 text-xs text-[#78716C]">
            관리자({BOOTSTRAPPED_ADMIN_EMAIL})의 정지 해제 후 다시 이용하실 수 있습니다.
          </p>
          <div className="mt-6 flex justify-center">
            <button
              type="button"
              disabled={isSigningIn}
              onClick={() => void handleSignIn()}
              className="h-10 px-5 inline-flex items-center gap-2 text-xs font-medium text-[#FBF9F5] bg-[#1B4332] hover:bg-[#143325] disabled:opacity-50 rounded-md transition-colors cursor-pointer"
            >
              {isSigningIn ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <LogIn className="w-3.5 h-3.5" />}
              <span>Google 계정으로 로그인하기</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!user && guestKicked) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#FBF9F5] text-[#1C1917] px-6">
        <div className="max-w-md w-full bg-white border border-[#FDE68A] rounded-lg p-7 text-center shadow-xs">
          <div className="w-11 h-11 rounded-full bg-[#FFFBEB] text-[#92400E] flex items-center justify-center mx-auto mb-4">
            <UserX className="w-5 h-5" />
          </div>
          <h1 className="font-editorial text-2xl font-semibold text-[#1C1917]">
            관리자에 의해 퇴장(쫓아내기) 처리되었습니다
          </h1>
          <p className="mt-2.5 text-sm text-[#44403C] leading-relaxed">
            현재 비로그인 세션이 관리자 요청으로 종료되었습니다. 계속 이용하려면 다시 접속하거나 Google 계정으로 로그인해 주세요.
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-2.5">
            <button
              type="button"
              onClick={() => {
                recordedGuestSessionRef.current = false;
                setGuestKicked(false);
              }}
              className="h-10 px-4 text-xs font-medium text-[#1C1917] bg-white border border-[#D6CEBE] hover:border-[#1B4332] rounded-md transition-colors cursor-pointer"
            >
              비로그인으로 다시 접속하기
            </button>
            <button
              type="button"
              disabled={isSigningIn}
              onClick={() => void handleSignIn()}
              className="h-10 px-4 inline-flex items-center gap-2 text-xs font-medium text-[#FBF9F5] bg-[#1B4332] hover:bg-[#143325] disabled:opacity-50 rounded-md transition-colors cursor-pointer"
            >
              {isSigningIn ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <LogIn className="w-3.5 h-3.5" />}
              <span>Google 계정으로 로그인</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div id="top" className="min-h-screen flex flex-col bg-[#FBF9F5] text-[#1C1917]">
      <Header
        activePage={effectivePage}
        savedCount={savedPlants.length}
        userEmail={user?.email}
        isPrimaryAdmin={isPrimaryAdmin}
        onNavigate={navigateToPage}
        onSignIn={() => void handleSignIn()}
        onSignOut={() => void handleSignOut()}
      />

      {banNotice && (
        <div className="bg-[#FEF2F2] border-b border-[#FECACA] px-6 py-3 text-center text-xs text-[#991B1B]">
          <strong className="font-semibold">계정 이용이 정지(벤)되었습니다.</strong>{' '}
          사유: {banNotice.reason || '관리자에 의해 서비스 이용이 정지되었습니다.'} (다른 계정으로 로그인하거나 관리자 {BOOTSTRAPPED_ADMIN_EMAIL}에게 문의해 주세요.)
        </div>
      )}

      {!banNotice && kickedNotice && (
        <div className="bg-[#FFFBEB] border-b border-[#FDE68A] px-6 py-3 text-center text-xs text-[#92400E]">
          {kickedNotice}
        </div>
      )}

      {authError && (
        <div className="bg-[#FEF2F2] border-b border-[#FECACA] px-6 py-2.5 text-center text-xs text-[#991B1B]">
          {authError}
        </div>
      )}

      {user && !user.emailVerified && (
        <div className="bg-[#FFFBEB] border-b border-[#FDE68A] px-6 py-2.5 text-center text-xs text-[#92400E]">
          이메일 인증이 완료된 Google 계정으로 로그인하면 커뮤니티 글 작성 및 좋아요를 이용할 수 있습니다.
        </div>
      )}

      <main className="flex-1 flex flex-col">
        {/* Page 01: Plant Name Search & Dual Workbench */}
        {effectivePage === 'search' && (
          <section id="search-workbench" className="py-10 lg:py-14 flex-1">
            <div className="max-w-7xl mx-auto px-6 lg:px-10">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
                {/* Left Column: Editorial Lead & Search Workbench */}
                <div className="lg:col-span-7 flex flex-col justify-between">
                  <div>
                    <p className="text-xs font-medium text-[#57534E] mb-3">
                      01 · 구글 검색 기반 식물 아카이브 &amp; 가드닝 커뮤니티
                    </p>
                    <h1 className="font-editorial text-3xl sm:text-4xl lg:text-[2.75rem] font-semibold text-[#1C1917] leading-[1.2] tracking-tight text-balance">
                      식물의 이름부터 취향의 향기까지, 정확한 생육 기록을 찾습니다
                    </h1>
                    <p className="mt-4 text-[15px] sm:text-base text-[#44403C] leading-relaxed max-w-2xl">
                      식물 이름을 검색하면 구글 정보를 바탕으로 물주기·햇빛·토양 관리법과
                      특징을 알려드리며, 원하는 생김새·색상·냄새를 입력하면 어울리는 식물을
                      추천해 드립니다.
                    </p>
                  </div>

                  {/* Interactive Dual-Mode Search Box */}
                  <div className="mt-8 bg-white border border-[#E5DFD3] rounded-lg p-5 sm:p-6">
                    {/* Segmented Mode Tabs */}
                    <div className="inline-flex items-center gap-1 p-1 bg-[#F3EFE6] border border-[#E5DFD3] rounded-md mb-4">
                      <button
                        type="button"
                        onClick={() => setHeroMode('name')}
                        className={`px-3.5 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                          heroMode === 'name'
                            ? 'bg-white text-[#1C1917] shadow-xs'
                            : 'text-[#57534E] hover:text-[#1C1917]'
                        }`}
                      >
                        식물 이름으로 검색
                      </button>
                      <button
                        type="button"
                        onClick={() => setHeroMode('trait')}
                        className={`px-3.5 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                          heroMode === 'trait'
                            ? 'bg-white text-[#1C1917] shadow-xs'
                            : 'text-[#57534E] hover:text-[#1C1917]'
                        }`}
                      >
                        생김새 · 색 · 향기로 추천
                      </button>
                    </div>

                    {heroMode === 'name' ? (
                      <form
                        onSubmit={(e) => {
                          e.preventDefault();
                          handleNameSearchSubmit();
                        }}
                      >
                        <div className="flex flex-col sm:flex-row gap-2.5">
                          <div className="relative flex-1">
                            <Search className="w-4 h-4 text-[#78716C] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                            <input
                              type="text"
                              value={nameQuery}
                              onChange={(e) => setNameQuery(e.target.value)}
                              placeholder="식물 이름 또는 학명 입력 (예: 몬스테라, 바질, 은목서)"
                              className="w-full h-11 pl-10 pr-4 text-sm bg-[#FBF9F5] border border-[#D6CEBE] rounded-md text-[#1C1917] placeholder:text-[#78716C] focus:outline-none focus:border-[#1B4332] focus:ring-1 focus:ring-[#1B4332]"
                            />
                          </div>
                          <button
                            type="submit"
                            disabled={!nameQuery.trim() || isSearchingPlant}
                            className="h-11 px-5 inline-flex items-center justify-center gap-2 text-sm font-medium text-[#FBF9F5] bg-[#1B4332] hover:bg-[#143325] disabled:opacity-45 disabled:cursor-not-allowed rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                          >
                            {isSearchingPlant ? (
                              <>
                                <Loader2 className="w-4 h-4 animate-spin" />
                                <span>식물 찾는 중</span>
                              </>
                            ) : (
                              <span>키우는 법 찾기</span>
                            )}
                          </button>
                        </div>

                        <div className="mt-3.5 flex flex-wrap items-center gap-x-3.5 gap-y-1.5 text-xs text-[#57534E]">
                          <span className="font-medium text-[#78716C] shrink-0">
                            실시간 인기 검색어:
                          </span>
                          {popularPlantQueries.map((q) => (
                            <button
                              key={q}
                              type="button"
                              onClick={() => handleNameSearchSubmit(q)}
                              className="text-[#2D6A4F] hover:text-[#1B4332] hover:underline underline-offset-2 cursor-pointer"
                            >
                              {q}
                            </button>
                          ))}
                        </div>
                      </form>
                    ) : (
                      <form
                        onSubmit={(e) => {
                          e.preventDefault();
                          void handleTraitRecommendSubmit(undefined, false);
                          navigateToPage('recommend');
                        }}
                      >
                        <div className="flex flex-col sm:flex-row gap-2.5">
                          <div className="relative flex-1">
                            <Sparkles className="w-4 h-4 text-[#78716C] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                            <input
                              type="text"
                              value={traitDescription}
                              onChange={(e) => handleTraitDescriptionChange(e.target.value)}
                              placeholder="식물 이름(예: 몬스테라)이나 원하는 색·향기·키워드 입력 (예: 보라색 꽃, 숙면)"
                              className="w-full h-11 pl-10 pr-4 text-sm bg-[#FBF9F5] border border-[#D6CEBE] rounded-md text-[#1C1917] placeholder:text-[#78716C] focus:outline-none focus:border-[#1B4332] focus:ring-1 focus:ring-[#1B4332]"
                            />
                          </div>
                          <button
                            type="submit"
                            disabled={
                              (!traitDescription.trim() &&
                                !Object.values(selectedTraits).some((v) => v.trim().length > 0)) ||
                              isRecommending
                            }
                            className="h-11 px-5 inline-flex items-center justify-center gap-2 text-sm font-medium text-[#FBF9F5] bg-[#1B4332] hover:bg-[#143325] disabled:opacity-45 disabled:cursor-not-allowed rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                          >
                            {isRecommending ? (
                              <>
                                <Loader2 className="w-4 h-4 animate-spin" />
                                <span>식물 찾는 중</span>
                              </>
                            ) : (
                              <span>맞춤 추천받기</span>
                            )}
                          </button>
                        </div>

                        <div className="mt-3.5 flex flex-wrap items-center justify-between gap-2 text-xs text-[#57534E]">
                          <span>계절·생김새·색·향기를 고르려면 취향 추천 페이지를 여세요.</span>
                          <button
                            type="button"
                            onClick={() => navigateToPage('recommend')}
                            className="inline-flex items-center gap-1 font-medium text-[#1B4332] hover:underline whitespace-nowrap shrink-0 cursor-pointer"
                          >
                            <span>취향 추천 페이지로 이동</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </form>
                    )}
                  </div>
                </div>

                {/* Right Column: Editorial Conservatory Figure */}
                <div className="lg:col-span-5 flex flex-col">
                  <figure className="flex-1 flex flex-col overflow-hidden rounded-lg border border-[#E5DFD3] bg-[#F3EFE6]">
                    <div className="flex-1 min-h-[260px] lg:min-h-0 overflow-hidden">
                      <SafeImage
                        src={HERO_IMAGE}
                        alt="햇살이 비치는 온실 테이블 위의 몬스테라, 라벤더, 다육 식물 표본"
                        fallbackLabel="온실 식물 표본실"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <figcaption className="px-4 py-3 text-xs text-[#57534E] border-t border-[#E5DFD3] bg-[#F9F6F0] leading-relaxed">
                      Fig. 01 — 온실 표본실: 관엽·허브·다육 식물의 광량과 배수 환경 연구
                    </figcaption>
                  </figure>
                </div>
              </div>

              {/* Full-Width 4-Column Interactive Page Shortcuts Strip */}
              <div className="mt-10 grid grid-cols-2 lg:grid-cols-4 border border-[#E5DFD3] rounded-lg bg-white divide-y lg:divide-y-0 lg:divide-x divide-[#E5DFD3] overflow-hidden">
                <button
                  type="button"
                  onClick={() => setHeroMode('name')}
                  className="p-4 sm:p-5 text-left hover:bg-[#F9F6F0] transition-colors cursor-pointer"
                >
                  <div className="text-xs text-[#78716C] tabular-nums mb-1">01 · 이름 검색</div>
                  <div className="text-sm font-semibold text-[#1C1917]">
                    물주기 · 광량 · 토양 매뉴얼
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => navigateToPage('recommend')}
                  className="p-4 sm:p-5 text-left hover:bg-[#F9F6F0] transition-colors cursor-pointer group"
                >
                  <div className="text-xs text-[#78716C] tabular-nums mb-1 flex items-center justify-between">
                    <span>02 · 취향 추천</span>
                    <ArrowRight className="w-3.5 h-3.5 text-[#1B4332] opacity-70 group-hover:translate-x-0.5 transition-transform" />
                  </div>
                  <div className="text-sm font-semibold text-[#1C1917]">
                    계절 · 생김새 · 색감 · 향기 매칭
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => navigateToPage('catalog')}
                  className="p-4 sm:p-5 text-left hover:bg-[#F9F6F0] transition-colors cursor-pointer group"
                >
                  <div className="text-xs text-[#78716C] tabular-nums mb-1 flex items-center justify-between">
                    <span>03 · 식물 도감</span>
                    <ArrowRight className="w-3.5 h-3.5 text-[#1B4332] opacity-70 group-hover:translate-x-0.5 transition-transform" />
                  </div>
                  <div className="text-sm font-semibold text-[#1C1917] tabular-nums">
                    {BOTANICAL_CATALOG.length}종 기본 표본 &amp; 구글 출처
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => navigateToPage('community')}
                  className="p-4 sm:p-5 text-left hover:bg-[#F9F6F0] transition-colors cursor-pointer group"
                >
                  <div className="text-xs text-[#78716C] tabular-nums mb-1 flex items-center justify-between">
                    <span>04 · 커뮤니티</span>
                    <ArrowRight className="w-3.5 h-3.5 text-[#1B4332] opacity-70 group-hover:translate-x-0.5 transition-transform" />
                  </div>
                  <div className="text-sm font-semibold text-[#1C1917]">
                    사진 자랑 · 키우는 팁 · 댓글 공유
                  </div>
                </button>
              </div>
            </div>
          </section>
        )}

        {/* Page 02: Trait Discovery & Recommendation Studio */}
        {effectivePage === 'recommend' && (
          <TraitRecommenderSection
            description={traitDescription}
            onDescriptionChange={handleTraitDescriptionChange}
            selectedTraits={selectedTraits}
            onTraitChange={handleTraitChange}
            onResetTraits={handleResetTraits}
            onSubmitRecommend={(overrideDesc, useLiveGoogle) => {
              void handleTraitRecommendSubmit(overrideDesc, Boolean(useLiveGoogle));
            }}
            isLoading={isRecommending}
            isLoadingLive={isLoadingLiveRecommend}
            error={recommendError}
            result={recommendResult}
            onSelectRecommendation={handleSelectRecommendation}
          />
        )}

        {/* Page 03: Curated Botanical Species Catalog */}
        {effectivePage === 'catalog' && (
          <CatalogSection
            plants={BOTANICAL_CATALOG}
            onSelectPlant={(plant) => {
              setPreviewRec(null);
              setSearchError(null);
              setActivePlant(plant);
            }}
          />
        )}

        {/* Page 04: Real-time Gardener Community Board */}
        {effectivePage === 'community' && (
          <CommunitySection
            user={user}
            authReady={authReady}
            isAdmin={isAdmin}
            onSignIn={handleSignIn}
            onSignOut={handleSignOut}
          />
        )}

        {/* Page 05: Saved Herbarium Section */}
        {effectivePage === 'saved' && (
          <section id="saved" className="py-10 lg:py-14 bg-[#F5F1E8]/40 flex-1">
            <div className="max-w-7xl mx-auto px-6 lg:px-10">
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-[#E5DFD3]">
                <div>
                  <p className="text-xs font-medium text-[#57534E] mb-1.5">
                    05 · 개인 표본 저장함
                  </p>
                  <h2 className="font-editorial text-2xl sm:text-3xl font-semibold text-[#1C1917]">
                    내가 저장한 식물 ({savedPlants.length})
                  </h2>
                </div>
                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => navigateToPage('catalog')}
                    className="px-3.5 py-2 text-xs font-medium text-[#1C1917] bg-white border border-[#D6CEBE] hover:border-[#1B4332] rounded-md transition-colors cursor-pointer"
                  >
                    식물 도감 둘러보기
                  </button>
                  <button
                    type="button"
                    onClick={() => navigateToPage('recommend')}
                    className="px-3.5 py-2 text-xs font-medium text-[#FBF9F5] bg-[#1B4332] hover:bg-[#143325] rounded-md transition-colors cursor-pointer"
                  >
                    취향 추천받기
                  </button>
                </div>
              </div>

              {savedPlants.length === 0 ? (
                <div className="mt-8 py-14 px-6 bg-white border border-[#E5DFD3] rounded-lg text-center">
                  <p className="font-editorial text-lg text-[#1C1917]">
                    아직 저장한 식물이 없습니다
                  </p>
                  <p className="mt-2 text-sm text-[#44403C]">
                    식물 상세 보기 화면에서{' '}
                    <strong className="font-medium text-[#1C1917]">도감에 저장</strong>을 누르면
                    여기에 모아두고 언제든 다시 키우는 법을 꺼내 볼 수 있습니다.
                  </p>
                  <div className="mt-5 flex items-center justify-center gap-3">
                    <button
                      type="button"
                      onClick={() => navigateToPage('search')}
                      className="px-4 py-2 text-xs font-medium text-[#1C1917] bg-[#FBF9F5] border border-[#D6CEBE] hover:border-[#1B4332] rounded-md transition-colors cursor-pointer"
                    >
                      식물 이름 검색하기
                    </button>
                    <button
                      type="button"
                      onClick={() => navigateToPage('catalog')}
                      className="px-4 py-2 text-xs font-medium text-[#FBF9F5] bg-[#1B4332] hover:bg-[#143325] rounded-md transition-colors cursor-pointer"
                    >
                      식물 도감 열기
                    </button>
                  </div>
                </div>
              ) : (
                <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                  {savedPlants.map((plant) => {
                    const thumbUrl =
                      PLANT_SPECIES_PHOTOS[plant.id] ||
                      plant.imageUrl ||
                      CATEGORY_VISUALS[plant.category]?.imageUrl ||
                      '';
                    return (
                      <div
                        key={plant.id}
                        className="bg-white border border-[#E5DFD3] rounded-lg p-4 flex items-start justify-between gap-3.5"
                      >
                        <button
                          type="button"
                          onClick={() => {
                            setPreviewRec(null);
                            setSearchError(null);
                            setActivePlant(plant);
                          }}
                          className="text-left flex items-start gap-3.5 flex-1 min-w-0 cursor-pointer group"
                        >
                          <div className="w-20 h-20 rounded-md overflow-hidden border border-[#E5DFD3] bg-[#F3EFE6] shrink-0">
                            <SafeImage
                              src={thumbUrl}
                              alt={`${plant.nameKo} 표본 사진`}
                              fallbackLabel={plant.nameKo}
                              className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-300"
                            />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="text-xs text-[#78716C] mb-1">
                              {plant.category} · {plant.difficulty}
                            </div>
                            <h3 className="font-editorial text-lg font-semibold text-[#1C1917] group-hover:text-[#1B4332] truncate">
                              {plant.nameKo}
                            </h3>
                            <p className="font-binomial italic text-xs text-[#57534E] truncate">
                              {plant.scientificName}
                            </p>
                            <p className="mt-1.5 text-xs text-[#44403C] line-clamp-1">
                              {plant.careGuide.wateringCycle}
                            </p>
                          </div>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleToggleSave(plant)}
                          aria-label={`${plant.nameKo} 저장 해제`}
                          title="저장 해제"
                          className="p-2 text-[#78716C] hover:text-[#991B1B] rounded-md transition-colors cursor-pointer shrink-0"
                        >
                          <BookmarkX className="w-4 h-4" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </section>
        )}

        {/* Page 06: Admin Accounts Directory (yjw201008@gmail.com only) */}
        {effectivePage === 'accounts' && isPrimaryAdmin && (
          <AdminAccountsSection />
        )}

        {/* Editorial Page-Turner Navigation Bar */}
        <div className="border-t border-[#E5DFD3] bg-[#F5F1E8]/70">
          <div className="max-w-7xl mx-auto px-6 lg:px-10 py-4 flex flex-col sm:flex-row items-center justify-between gap-3">
            <button
              type="button"
              disabled={!prevPage}
              onClick={() => prevPage && navigateToPage(prevPage.id)}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-3.5 py-2 text-xs font-medium text-[#1C1917] bg-white border border-[#D6CEBE] hover:border-[#1B4332] disabled:opacity-40 disabled:cursor-not-allowed rounded-md transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>
                {prevPage ? `이전: ${prevPage.num} ${prevPage.label}` : '첫 페이지'}
              </span>
            </button>

            <div className="flex flex-wrap items-center justify-center gap-1.5 tabular-nums">
              {visiblePageOrder.map((pageItem) => {
                const isCurrent = pageItem.id === effectivePage;
                return (
                  <button
                    key={pageItem.id}
                    type="button"
                    onClick={() => navigateToPage(pageItem.id)}
                    className={`inline-flex items-center gap-1 px-2.5 py-1 text-xs rounded border transition-colors cursor-pointer ${
                      isCurrent
                        ? 'bg-[#1B4332] text-[#FBF9F5] border-[#1B4332] font-medium'
                        : 'bg-white text-[#57534E] border-[#E5DFD3] hover:border-[#1B4332] hover:text-[#1C1917]'
                    }`}
                  >
                    {pageItem.id === 'accounts' && <ShieldCheck className="w-3 h-3" />}
                    <span>
                      {pageItem.num} {pageItem.label}
                    </span>
                  </button>
                );
              })}
            </div>

            <button
              type="button"
              disabled={!nextPage}
              onClick={() => nextPage && navigateToPage(nextPage.id)}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-3.5 py-2 text-xs font-medium text-[#1C1917] bg-white border border-[#D6CEBE] hover:border-[#1B4332] disabled:opacity-40 disabled:cursor-not-allowed rounded-md transition-colors cursor-pointer"
            >
              <span>
                {nextPage ? `다음: ${nextPage.num} ${nextPage.label}` : '마지막 페이지'}
              </span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </main>

      <footer className="border-t border-[#E5DFD3] bg-[#FBF9F5] py-8">
        <div className="max-w-7xl mx-auto px-6 lg:px-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-[#78716C]">
          <div>
            <span className="font-editorial text-sm font-semibold text-[#1C1917] mr-3">
              올플랜트
            </span>
            <span>구글 검색 기반 식물 도감 및 가드너 커뮤니티 아카이브</span>
          </div>
          <div className="flex flex-wrap items-center gap-5">
            {visiblePageOrder.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => navigateToPage(item.id)}
                className={`cursor-pointer hover:text-[#1C1917] ${
                  effectivePage === item.id ? 'text-[#1B4332] font-medium' : ''
                }`}
              >
                {item.label}
              </button>
            ))}
            <a
              href="/api/project/download-zip"
              download="allplant.zip"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#1B4332] bg-white border border-[#D6CEBE] hover:border-[#1B4332] rounded-md transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>ZIP 다운로드</span>
            </a>
          </div>
        </div>
      </footer>

      {/* Specimen Detail Care Monograph Modal */}
      <SpecimenDetailModal
        plant={activePlant}
        previewRecommendation={previewRec}
        searchingQuery={searchingQuery}
        isLoading={isSearchingPlant}
        error={searchError}
        isSaved={isPlantSaved(activePlant)}
        onClose={() => {
          clearSearchTimer();
          setIsSearchingPlant(false);
          setSearchingQuery(null);
          setActivePlant(null);
          setPreviewRec(null);
          setSearchError(null);
        }}
        onToggleSave={handleToggleSave}
        onRefreshFromGoogle={(plantName) => {
          void fetchPlantFromGoogle(plantName, { forceRefresh: true });
        }}
      />
    </div>
  );
}
